"""Private, atomic configuration storage. Never log configuration values."""
from __future__ import annotations

import copy
import json
import os
import tempfile
from pathlib import Path
from typing import Any

from cryptography.fernet import Fernet, InvalidToken


class SafeError(Exception):
    """An error whose message is safe to display to the owner."""


DEFAULTS: dict[str, Any] = {
    "schema_version": 2,
    "multi_account_version": 0,
    "profiles": [],
    "active_account": "",
    "max_accounts": 10,
    "next_account_number": 1,
    "account_user_id": 0,
    "detected_user_id": 0,
    "detected_phone": "",
    "label": "",
    "bot_token": "",
    "api_id": 0,
    "api_hash": "",
    "owner_id": 0,
    "owner_ui_state": {},
    "owner_phone": "",
    "registered": False,
    "session_name": "",
    "library": "",
    "reset_status": "idle",
    "reset_started_at": 0,
    "reset_until_date": 0,
    "pending_new_password": "",
    "pending_hint": "",
    "phase": "idle",
    "wait_kind": "",
    "retry_at": 0,
    "next_attempt_at": 0,
    "password_apply_status": "not_started",
    "allow_session_upload": True,
    "scheduler_interval_seconds": 3600,
    "last_spamcheck_at": 0,
    "last_error_code": "",
    "notices": [],
    "security_alerts_enabled": True,
    "security_alerts_state": {},
    "protection_lock_enabled": True,
    "otp_forward_enabled": True,
    "otp_forward_state": {},
    "forward_target": "@tgidsel",
    "protection_generation": 0,
    "protection_state": {},
    "email_info": {},
    "login_email_change": {},
    "universal_password": "",
    "password_action": "",
}


def private_mode(path: Path, directory: bool = False) -> None:
    """POSIX permissions; on Windows also restrict access with the OS account ACL."""
    try:
        path.chmod(0o700 if directory else 0o600)
    except OSError:
        if os.name != "nt":
            raise


def atomic_json(path: Path, data: dict) -> None:
    """Replace the file only after the new complete JSON has reached disk."""
    fd, tmp = tempfile.mkstemp(prefix=".config-", suffix=".tmp", dir=path.parent)
    try:
        if os.name != "nt":
            os.fchmod(fd, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(data, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, path)
        private_mode(path)
        if os.name != "nt":
            dfd = os.open(path.parent, os.O_RDONLY)
            try:
                os.fsync(dfd)
            finally:
                os.close(dfd)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


class Store:
    def __init__(self, root: Path):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / "config.json"
        if self.path.is_symlink():
            raise SafeError("config.json must not be a symbolic link.")
        if not self.path.exists():
            atomic_json(self.path, copy.deepcopy(DEFAULTS))
        self.reload()
        private_mode(self.path)

    def reload(self) -> dict:
        try:
            loaded = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(loaded, dict):
                raise ValueError("not an object")
        except (OSError, ValueError):
            raise SafeError(
                "config.json cannot be read. Do not delete it: restore a private backup first. "
                "An unreadable state must never silently start a new reset."
            ) from None
        self.data = copy.deepcopy(DEFAULTS)
        self.data.update(loaded)
        return self.data

    def update(self, **changes: Any) -> None:
        # Reload on every state change. One process + an engine lock serialize writers.
        current = self.reload()
        current.update(changes)
        atomic_json(self.path, current)
        self.data = current

    def queue(self, text: str) -> None:
        notices = list(self.reload().get("notices", []))
        if text not in notices:
            notices.append(text)
        self.update(notices=notices[-20:])


class Vault:
    """Encrypt pending passwords; the key and all session files are still sensitive."""
    def __init__(self, root: Path):
        self.path = Path(root) / ".secret.key"

    def _cipher(self, create: bool = False) -> Fernet:
        if self.path.is_symlink():
            raise SafeError("The password key must not be a symbolic link.")
        if not self.path.exists():
            if not create:
                raise SafeError(
                    "The local .secret.key is missing. Automatic reset is paused. "
                    "Restore the matching key or cancel and choose a new pending password."
                )
            fd = os.open(self.path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, "wb") as handle:
                handle.write(Fernet.generate_key())
                handle.flush()
                os.fsync(handle.fileno())
        private_mode(self.path)
        try:
            return Fernet(self.path.read_bytes())
        except (ValueError, OSError):
            raise SafeError("The local password-encryption key is invalid. Restore its private backup.") from None

    def seal(self, plaintext: str) -> str:
        return "fernet:" + self._cipher(create=True).encrypt(plaintext.encode("utf-8")).decode("ascii")

    def open(self, encrypted: str) -> str:
        if not encrypted or not encrypted.startswith("fernet:"):
            raise SafeError(
                "No valid encrypted pending password is saved. Reset is paused; "
                "cancel locally and run /resetpassword again."
            )
        try:
            return self._cipher().decrypt(encrypted[7:].encode("ascii")).decode("utf-8")
        except (InvalidToken, UnicodeError, ValueError):
            raise SafeError("The saved password cannot be decrypted. Restore the matching .secret.key.") from None


class ProcessLock:
    """Prevent two pollers/state writers on the same installation."""
    def __init__(self, path: Path):
        self.path = path
        self.handle = None

    def __enter__(self):
        self.handle = open(self.path, "a+b")
        private_mode(self.path)
        try:
            if os.name == "nt":
                import msvcrt
                self.handle.seek(0)
                self.handle.write(b"0")
                self.handle.flush()
                self.handle.seek(0)
                msvcrt.locking(self.handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except (OSError, BlockingIOError):
            self.handle.close()
            self.handle = None
            raise SafeError("Another copy is already running. Stop it before starting a second copy.") from None
        self.handle.seek(0)
        self.handle.truncate()
        self.handle.write((str(os.getpid()) + "\n").encode("ascii"))
        self.handle.flush()
        return self

    def __exit__(self, *_):
        if self.handle:
            self.handle.close()
