"""Auto-route a controller-supplied SQLite session to its own account profile.

Preview uses only connect/get_me, never password reset or messaging. Upload
permission is checked by the bot UI before this module is called.
"""
from __future__ import annotations

import asyncio
import contextlib
import secrets
import shutil
import sqlite3
import tempfile
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import quote

from accounts import AccountContext, AccountRegistry
from sessions import MAX_SESSION_BYTES, SessionManager, identity_from_user
from storage import SafeError, Store, private_mode


@dataclass
class ImportResult:
    account: AccountContext
    created: bool
    kept_active_job: bool


def snapshot(source: Path, target: Path):
    source = Path(source)
    if source.is_symlink() or not source.is_file() or not 16 <= source.stat().st_size <= MAX_SESSION_BYTES:
        raise SafeError("Send a valid SQLite .session file up to 5 MB.")
    with source.open("rb") as handle:
        if handle.read(16) != b"SQLite format 3\x00":
            raise SafeError("This is not a SQLite .session file. Session strings and ZIPs are not supported.")
    src = sqlite3.connect("file:" + quote(str(source.resolve())) + "?mode=ro", uri=True)
    dst = sqlite3.connect(target)
    try:
        src.backup(dst)
    except sqlite3.DatabaseError:
        raise SafeError("This session database is damaged or unreadable.") from None
    finally:
        dst.close()
        src.close()
    private_mode(target)
    if target.stat().st_size > MAX_SESSION_BYTES:
        raise SafeError("The complete session database exceeds the 5 MB limit.")


class SessionRouter:
    def __init__(self, registry: AccountRegistry):
        self.registry = registry
        self.root = registry.root
        self.lock = asyncio.Lock()
        self.incoming = self.root / ".imports"
        if self.incoming.is_symlink():
            raise SafeError("The temporary import directory must not be a symbolic link.")
        self.incoming.mkdir(exist_ok=True)
        private_mode(self.incoming, directory=True)

    def _find(self, uid: int):
        matches = []
        for key in self.registry.keys():
            account = self.registry.get(key)
            data = account.store.reload()
            known = int(data["account_user_id"] or data["detected_user_id"] or 0)
            if known == uid:
                matches.append(account)
        if len(matches) > 1:
            raise SafeError("This account already has duplicate local profiles. Resolve them before importing another session; no timer was changed.")
        return matches[0] if matches else None

    def _empty_profile(self):
        for key in self.registry.keys():
            account = self.registry.get(key)
            data = account.store.reload()
            if (not data["session_name"] and not data["registered"]
                    and not data["account_user_id"] and not data["detected_user_id"]
                    and data["reset_status"] == "idle"):
                return account
        return None

    async def import_file(self, source: Path) -> ImportResult:
        async with self.lock:
            previous_active = self.registry.active_key
            temp = Path(tempfile.mkdtemp(prefix="session-", dir=self.incoming))
            private_mode(temp, directory=True)
            preview = None
            account = None
            created = False
            new_path = None
            previous_fields = None
            try:
                source_copy = temp / "source.session"
                snapshot(Path(source), source_copy)
                state = Store(temp)
                common = self.registry.controller.reload()
                state.update(api_id=common["api_id"], api_hash=common["api_hash"], session_name="source.session")
                preview = SessionManager(state)
                await preview.ensure()  # Telethon first; Pyrogram only on format mismatch.
                me = preview.me
                uid, phone = identity_from_user(me)
                library = state.data["library"]
                await preview.close()
                account = self._find(uid)
                if account is None:
                    account = self._empty_profile()
                    if account is None:
                        account = self.registry.create()
                        created = True
                async with account.engine.lock:
                    data = account.store.reload()
                    # Never replace the authentication key of a running recovery
                    # as a side effect of uploading a duplicate session.
                    if data["reset_status"] == "waiting":
                        self.registry.select(account.key)
                        return ImportResult(account, created=False, kept_active_job=True)
                    pinned = int(data["account_user_id"] or 0)
                    if pinned and pinned != uid:
                        raise SafeError("This verified profile belongs to a different account. No existing account was overwritten.")
                    previous_fields = {key: data[key] for key in
                                       ("session_name", "library", "detected_user_id", "detected_phone", "registered", "owner_phone", "account_user_id")}
                    name = "sessions/auto_" + secrets.token_hex(10) + ".session"
                    new_path = account.store.root / name
                    shutil.copyfile(source_copy, new_path)
                    private_mode(new_path)
                    await account.sessions.close()
                    account.store.update(
                        session_name=name, library=library, detected_user_id=uid, account_user_id=uid,
                        detected_phone=phone, owner_phone=phone, registered=True,
                    )
                    self.registry.select(account.key)
                    self.registry.assert_unique(account.key)
                    return ImportResult(account, created=created, kept_active_job=False)
            except Exception:
                rollback_ok = True
                if created and account is not None:
                    # A failed import must not consume a profile slot or affect
                    # an existing account's job. No reset is ever started here.
                    with contextlib.suppress(Exception):
                        await self.registry.remove(account.key)
                elif account is not None and previous_fields is not None:
                    try:
                        account.store.update(**previous_fields)
                    except Exception:
                        rollback_ok = False  # Keep the copied session if state cannot be restored.
                with contextlib.suppress(Exception):
                    if previous_active in self.registry.keys():
                        self.registry.select(previous_active)
                if new_path is not None and rollback_ok:
                    new_path.unlink(missing_ok=True)
                raise
            finally:
                if preview:
                    with contextlib.suppress(Exception):
                        await preview.close()
                shutil.rmtree(temp, ignore_errors=True)
