"""Code-free alerts for the official Telegram service chat (777000) only.

Bodies exist only transiently inside the adapter for a local category check.
Only message IDs, dates, two category counters and controlled error classes can
enter this module's durable state. No OTP, text, URL, hash of text, read receipt,
login request, phone change or user-session outgoing message is produced here.
"""
from __future__ import annotations

import asyncio
import copy
import logging
import re
import time
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

from storage import SafeError

SERVICE_USER_ID = 777000
STATE_KEY = "security_alerts_state"
ENABLED_KEY = "security_alerts_enabled"
PAGE_SIZE = 50
PAGES_PER_TICK = 4
RPC_TIMEOUT = 25
INTERVAL = 30
DISCOVERY_INTERVAL = 5
log = logging.getLogger(__name__)
IST = timezone(timedelta(hours=5, minutes=30), name="IST")

# A deliberately local heuristic. Its output is an enum, never a substring.
CODE_WORDS = re.compile(
    r"login\s*code|log[ -]?in\s*code|verification\s*code|confirmation\s*code|"
    r"sign[ -]?in\s*code|your\s+(?:telegram\s+)?code|password\s*reset\s*code|\botp\b|"
    r"код\s*(?:для\s*)?(?:входа|подтверждения)|c[oó]digo\s*(?:de\s*)?(?:inicio|acceso|verificaci[oó]n)|"
    r"code\s*(?:de\s*)?(?:connexion|v[eé]rification)|anmeldecode|登录验证码|登錄驗證碼|"
    r"लॉगिन\s*कोड|सत्यापन\s*कोड|رمز\s*(?:الدخول|التحقق)", re.IGNORECASE,
)
CODE_DIGITS = re.compile(r"(?<!\d)\d{4,8}(?!\d)")


def classify_service_text(text: str | None) -> str:
    text = str(text or "")[:8192]
    return "otp" if CODE_WORDS.search(text) and CODE_DIGITS.search(text) else "message"


@dataclass(frozen=True)
class ServiceEvent:
    message_id: int
    date: int
    kind: str
    outgoing: bool = False


def _number(value) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or not 0 <= value < 2**63:
        raise SafeError("Security-alert metadata is invalid. Other account jobs were not changed.")
    return value


def _bucket(value, scan=False) -> dict:
    if not isinstance(value, dict):
        raise SafeError("Security-alert state is invalid. Restore its private backup.")
    allowed = {"otp", "message", "latest_at", "high"} | ({"offset"} if scan else set())
    if set(value) - allowed:
        raise SafeError("Unexpected security-alert data was rejected; message bodies cannot be stored.")
    return {k: _number(v) for k, v in value.items()}


def alert_state(data: dict) -> dict:
    raw = data.get(STATE_KEY, {})
    allowed = {"initialized", "cursor", "scan", "pending", "last_check", "retry_at", "notify_retry_at", "error", "error_notified", "delivery_error"}
    if not isinstance(raw, dict) or set(raw) - allowed:
        raise SafeError("Security-alert state is invalid. Other saved jobs remain separate.")
    result = {"initialized": False, "cursor": 0, "scan": {}, "pending": {}, "last_check": 0,
              "retry_at": 0, "notify_retry_at": 0, "error": "", "error_notified": "", "delivery_error": ""}
    result.update(copy.deepcopy(raw))
    if not isinstance(result["initialized"], bool):
        raise SafeError("Invalid security-alert initialization flag.")
    for key in ("cursor", "last_check", "retry_at", "notify_retry_at"):
        result[key] = _number(result[key])
    result["scan"] = _bucket(result["scan"], scan=True)
    result["pending"] = _bucket(result["pending"])
    for key in ("error", "error_notified", "delivery_error"):
        value = result[key]
        if not isinstance(value, str) or (value and not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,79}", value)):
            raise SafeError("Invalid security-alert error metadata.")
    return result


def stamp(value: int) -> str:
    try:
        return datetime.fromtimestamp(int(value), IST).strftime("%d %b %Y, %H:%M:%S IST") if value else "Not checked yet"
    except (OverflowError, OSError, ValueError):
        return "Time unavailable"


def alert_status(data: dict, master=True) -> str:
    if not master or not data.get(ENABLED_KEY, True):
        return "OFF"
    try:
        state = alert_state(data)
    except SafeError:
        return "ON — state needs attention"
    if state["delivery_error"]:
        return "ON — delivery retry pending"
    if state["error"]:
        return "ON — read retry pending"
    return "ON" if state["initialized"] else "ON — starting"


def render_alert(account, pending: dict) -> str:
    pending = _bucket(pending)
    otp, other = pending.get("otp", 0), pending.get("message", 0)
    data = account.store.reload()
    phone = re.sub(r"\D", "", str(data.get("owner_phone") or data.get("detected_phone") or ""))
    lines = ["TELEGRAM SECURITY ALERT", account.label()]
    if 7 <= len(phone) <= 15:
        lines.append("Phone: +" + phone)
    if otp:
        lines.append("OTP message received" + (f": {otp}" if otp > 1 else ""))
    if other:
        lines.append("Telegram message received" + (f": {other}" if other > 1 else ""))
    lines += ["Time: " + stamp(pending.get("latest_at", 0)), "Message text, codes and login links are not included."]
    return "\n".join(lines)


def retry_delay(error: Exception) -> int:
    for key in ("seconds", "value", "retry_after"):
        value = getattr(error, key, None)
        if isinstance(value, timedelta):
            value = value.total_seconds()
        try:
            if value is not None and 0 < float(value) < 366 * 86400:
                return max(INTERVAL, int(float(value)) + 1)
        except (ValueError, TypeError):
            pass
    name = type(error).__name__.lower()
    return 3600 if any(x in name for x in ("authkey", "sessionrevoked", "sessionexpired", "unauthorized")) else 60


class SecurityMonitor:
    def __init__(self, registry, controller, clock=time.time):
        self.registry, self.controller, self.clock = registry, controller, clock
        self.idle = True  # Official messages are read by the forwarder. This timer only delivers saved alerts.

    def enabled(self, data=None) -> bool:
        return bool(self.controller.reload().get(ENABLED_KEY, True) and
                    (data is None or data.get(ENABLED_KEY, True)))

    def _save(self, account, state):
        account.store.update(**{STATE_KEY: alert_state({STATE_KEY: state})})

    def _defer(self, account, error, *, delivery=False):
        state = alert_state(account.store.reload())
        state["notify_retry_at" if delivery else "retry_at"] = int(self.clock()) + retry_delay(error)
        state["delivery_error" if delivery else "error"] = type(error).__name__[:80]
        if not delivery:
            state["last_check"] = int(self.clock())
        self._save(account, state)
        log.warning("Security-alert %s deferred (%s); no text or values logged",
                    "delivery" if delivery else "check", type(error).__name__)

    async def set_enabled(self, key: str, enabled: bool):
        if enabled and not self.enabled():
            raise SafeError("All security alerts are paused. Open /alerts and enable alerts for all first.")
        account = self.registry.get(key)
        async with account.engine.lock:
            data = account.store.reload()
            if bool(data.get(ENABLED_KEY, True)) == enabled:
                return  # Idempotent: never discard an existing cursor/outbox.
            account.store.update(**{ENABLED_KEY: enabled, STATE_KEY: {}})

    async def set_all(self, enabled: bool):
        self.controller.update(**{ENABLED_KEY: enabled})
        for key in self.registry.keys():
            try:
                account = self.registry.get(key)
                async with account.engine.lock:
                    data = account.store.reload()
                    if bool(data.get(ENABLED_KEY, True)) != enabled or not enabled:
                        account.store.update(**{ENABLED_KEY: enabled, STATE_KEY: {}})
            except asyncio.CancelledError:
                raise
            except Exception as error:
                log.warning("Security-alert toggle isolated (%s)", type(error).__name__)

    async def poll_account(self, account):
        async with account.engine.lock:
            data = account.store.reload()
            target = int(data.get("account_user_id") or data.get("detected_user_id") or 0)
            if not self.enabled(data) or not target or not data.get("session_name"):
                return
            state = alert_state(data)
            now = int(self.clock())
            if state["retry_at"] > now:
                return
            try:
                adapter = await account.sessions.ensure()
                if not account.sessions.me or int(account.sessions.me.id) != target:
                    raise SafeError("Security monitor session ID does not match this account.")
                if not state["initialized"]:
                    page = await asyncio.wait_for(adapter.service_messages(limit=1), RPC_TIMEOUT)
                    state.update(initialized=True, cursor=max((e.message_id for e in page), default=0),
                                 scan={}, pending={}, last_check=now, retry_at=0, error="", error_notified="")
                    self._save(account, state)
                    return  # Baseline only; never replay pre-enable history.
                scan = state["scan"]
                for _ in range(PAGES_PER_TICK):
                    offset = scan.get("offset", 0)
                    page = await asyncio.wait_for(adapter.service_messages(offset_id=offset, limit=PAGE_SIZE), RPC_TIMEOUT)
                    unique = {e.message_id: e for e in page if e.message_id > 0 and (not offset or e.message_id < offset)}
                    if page and not unique:
                        raise SafeError("Security-alert history did not advance. No cursor was guessed.")
                    events = list(unique.values())
                    if not scan.get("high"):
                        scan["high"] = max((e.message_id for e in events), default=state["cursor"])
                    for e in events:
                        if state["cursor"] < e.message_id <= scan["high"] and not e.outgoing:
                            kind = "otp" if e.kind == "otp" else "message"
                            scan[kind] = scan.get(kind, 0) + 1
                            scan["latest_at"] = max(scan.get("latest_at", 0), max(0, int(e.date)))
                    done = not page or len(page) < PAGE_SIZE or any(e.message_id <= state["cursor"] for e in events)
                    if done:
                        pending = state["pending"]
                        for kind in ("otp", "message"):
                            pending[kind] = pending.get(kind, 0) + scan.get(kind, 0)
                        pending["latest_at"] = max(pending.get("latest_at", 0), scan.get("latest_at", 0))
                        pending["high"] = max(pending.get("high", 0), scan.get("high", 0))
                        state.update(cursor=max(state["cursor"], scan.get("high", 0)), scan={}, pending=pending,
                                     last_check=now, retry_at=0, error="", error_notified="")
                        self._save(account, state)  # Cursor AND outbox durable before delivery.
                        return
                    scan["offset"] = min(e.message_id for e in events)
                    state.update(scan=scan, last_check=now, retry_at=0, error="", error_notified="")
                    self._save(account, state)  # Restart resumes a long backlog page-by-page.
            except asyncio.CancelledError:
                raise
            except Exception as error:
                self._defer(account, error)

    async def _poll_key(self, key):
        try:
            await self.poll_account(self.registry.get(key))
        except asyncio.CancelledError:
            raise
        except Exception as error:
            log.warning("Security-alert account isolated (%s); no values logged", type(error).__name__)

    async def poll_all(self):
        if self.enabled():
            await asyncio.gather(*(self._poll_key(key) for key in self.registry.keys()))

    def has_pending(self) -> bool:
        if not self.enabled():
            return False
        for key in self.registry.keys():
            try:
                data = self.registry.get(key).store.reload()
                state = alert_state(data)
                if self.enabled(data) and (sum(state["pending"].get(k, 0) for k in ("otp", "message")) or
                                           state["error"] and state["error"] != state["error_notified"]):
                    return True
            except Exception:
                continue
        return False

    async def flush_account(self, account, app):
        from telegram import InlineKeyboardButton as Button, InlineKeyboardMarkup as Markup
        async with account.engine.lock:
            data = account.store.reload()
            if not self.enabled(data):
                return
            state = alert_state(data)
            if state["notify_retry_at"] > int(self.clock()):
                return
            keyboard = Markup([[Button("Open this account", callback_data="account:" + account.key),
                                Button("My IDs", callback_data="myids")]])
            pending = state["pending"]
            try:
                if sum(pending.get(k, 0) for k in ("otp", "message")):
                    await app.bot.send_message(int(self.controller.data["owner_id"]), render_alert(account, pending),
                                               reply_markup=keyboard, disable_web_page_preview=True)
                    state["pending"] = {}
                    state["notify_retry_at"] = 0
                    state["delivery_error"] = ""
                    self._save(account, state)
                if state["error"] and state["error"] != state["error_notified"]:
                    text = ("SECURITY ALERTS NEED ATTENTION\n" + account.label() +
                            "\nCheck temporarily paused (" + state["error"] + ")." +
                            "\nNext read attempt: " + stamp(state["retry_at"]) +
                            "\nNo code/text was forwarded. Saved reset jobs are separate.")
                    await app.bot.send_message(int(self.controller.data["owner_id"]), text, reply_markup=keyboard,
                                               disable_web_page_preview=True)
                    state["error_notified"] = state["error"]
                    state["notify_retry_at"] = 0
                    state["delivery_error"] = ""
                    self._save(account, state)
            except asyncio.CancelledError:
                raise
            except Exception as error:
                self._defer(account, error, delivery=True)

    async def flush_all(self, app):
        for key in self.registry.keys():
            try:
                await self.flush_account(self.registry.get(key), app)
            except asyncio.CancelledError:
                raise
            except Exception as error:
                log.warning("Security-alert delivery isolated (%s)", type(error).__name__)

    async def _account_worker(self, key, app):
        while key in self.registry.keys():
            started = asyncio.get_running_loop().time()
            try:
                account = self.registry.get(key)
                if not self.idle:
                    await self.poll_account(account)
                await self.flush_account(account, app)
            except asyncio.CancelledError:
                raise
            except Exception as error:
                log.warning("Security-alert account worker deferred (%s); no values logged", type(error).__name__)
            # A slow/revoked account cannot delay another account's loop.
            elapsed = asyncio.get_running_loop().time() - started
            await asyncio.sleep(max(1, INTERVAL - elapsed))

    async def worker(self, app):
        tasks = {}
        try:
            while True:
                try:
                    keys = set(self.registry.keys())
                    removed = [tasks.pop(key) for key in set(tasks) - keys]
                    for task in removed:
                        task.cancel()
                    if removed:
                        await asyncio.gather(*removed, return_exceptions=True)
                    for key in keys:
                        if key not in tasks or tasks[key].done():
                            if key in tasks and not tasks[key].cancelled():
                                tasks[key].exception()  # Retrieve an isolated failure, never its text.
                            tasks[key] = asyncio.create_task(self._account_worker(key, app), name="security-alert-account")
                except asyncio.CancelledError:
                    raise
                except Exception as error:
                    log.warning("Security-alert supervisor deferred (%s); no values logged", type(error).__name__)
                await asyncio.sleep(DISCOVERY_INTERVAL)  # Discover new imports without changing recovery scheduling.
        finally:
            for task in tasks.values():
                task.cancel()
            await asyncio.gather(*tasks.values(), return_exceptions=True)


def alerts_screen(registry, controller, *, key=None, page=0):
    """Metadata-only settings. Rendering never connects to a user session."""
    from telegram import InlineKeyboardButton as Button, InlineKeyboardMarkup as Markup
    master = bool(controller.reload().get(ENABLED_KEY, True))
    keys = [registry.get(key).key] if key is not None else registry.keys()
    pages = max(1, (len(keys) + 4) // 5)
    page = max(0, min(int(page), pages - 1))
    lines = ["TELEGRAM SECURITY ALERTS", "All-account switch: " + ("ON" if master else "OFF"),
             "Official Telegram service-chat and new-login notices. Category, account and time only; no codes, message text, media or login links.",
             "About every 30 seconds while online. First enable/re-enable skips old service-chat history. Recovery checks remain hourly. Alert switches do NOT disable the protection lock.", ""]
    rows = []
    for account_key in keys[page * 5:page * 5 + 5]:
        try:
            account = registry.get(account_key)
            data = account.store.reload()
            try:
                last = stamp(alert_state(data)["last_check"])
            except SafeError:
                last = "State needs attention"
            lines += [account.label(), "Alerts: " + alert_status(data, master), "Last check: " + last, ""]
            on = bool(data.get(ENABLED_KEY, True))
            rows.append([Button(("Turn OFF: " if on else "Turn ON: ") + str(data.get("label") or "Account")[:35],
                                callback_data=f"acct:{account_key}:alerts_{'off' if on else 'on'}")])
        except SafeError:
            lines += ["Profile unavailable — its other saved jobs were not changed.", ""]
    nav = []
    if page:
        nav.append(Button("Previous", callback_data=f"alerts:page:{page - 1}"))
    if page + 1 < pages:
        nav.append(Button("Next", callback_data=f"alerts:page:{page + 1}"))
    if nav:
        rows.append(nav)
    rows += [[Button("Enable all", callback_data="alerts:all_on"), Button("Disable all", callback_data="alerts:all_off")],
             [Button("Refresh alerts", callback_data=(f"acct:{key}:alerts" if key else f"alerts:page:{page}")),
              Button("My IDs", callback_data="myids")], [Button("Protection lock", callback_data="protection")]]
    return "\n".join(lines), Markup(rows)
