"""One bot controller, separate verified profiles for the controller's OWN accounts.

Every profile has its own state machine, session runtime, lock, and notices.
The root encryption key is shared only to permit lossless legacy migration.
No network operation or password reset is performed by the registry itself.
"""
from __future__ import annotations

import asyncio
import logging
import re
import secrets
import shutil
from dataclasses import dataclass
from pathlib import Path

from recovery import RecoveryEngine
from sessions import SessionManager
from storage import DEFAULTS, SafeError, Store, Vault, private_mode

log = logging.getLogger(__name__)
PROFILE_KEY = re.compile(r"(?:main|[a-f0-9]{12})\Z")


def scheduler_delay(now: int, interval: int, due: int = 0) -> int:
    """Wake at a saved deadline without adding Telegram calls before it is due."""
    gap = max(60, int(interval or 3600))
    if not due or int(due) <= 0:
        return gap
    return min(gap, max(60, int(due) - int(now) + 15))
ACCOUNT_FIELDS = (
    "owner_phone", "registered", "session_name", "library", "reset_status",
    "reset_started_at", "reset_until_date", "pending_new_password", "pending_hint",
    "phase", "wait_kind", "retry_at", "next_attempt_at", "password_apply_status",
    "last_spamcheck_at", "last_error_code", "notices", "account_user_id", "detected_user_id", "detected_phone",
    "security_alerts_enabled", "security_alerts_state",
    "otp_forward_enabled", "otp_forward_state",
    "protection_lock_enabled", "protection_generation", "protection_state",
    "email_info", "login_email_change", "password_action",
)


@dataclass
class AccountContext:
    key: str
    store: Store
    sessions: SessionManager
    engine: RecoveryEngine

    def label(self) -> str:
        data = self.store.reload()
        base = data["label"] or "Account"
        uid = int(data.get("account_user_id") or data.get("detected_user_id") or 0)
        if uid:
            return f"{base} | ID {uid}" + ("" if data["registered"] else " (phone unverified)")
        return f"{base} | no session verified"


class AccountRegistry:
    def __init__(self, controller: Store):
        self.controller = controller
        self.root = controller.root
        self.folder = self.root / "accounts"
        if self.folder.is_symlink():
            raise SafeError("The accounts folder must not be a symbolic link.")
        self.folder.mkdir(exist_ok=True)
        private_mode(self.folder, directory=True)
        self.vault = Vault(self.root)
        self.cache: dict[str, AccountContext] = {}
        self._migrate_legacy()
        if not self.keys():
            self.create()
        if controller.data["active_account"] not in self.keys():
            controller.update(active_account=self.keys()[0])

    def _path(self, key: str) -> Path:
        if not PROFILE_KEY.fullmatch(key):
            raise SafeError("Invalid account profile. Use /accounts to select a saved profile.")
        path = self.folder / key
        if path.is_symlink() or path.resolve().parent != self.folder.resolve():
            raise SafeError("An account profile path is unsafe. No files were changed.")
        return path

    def keys(self) -> list[str]:
        values = self.controller.reload().get("profiles", [])
        if not isinstance(values, list):
            raise SafeError("The account registry is invalid. Restore a private backup; no timers were changed.")
        for key in values:
            if not isinstance(key, str) or not PROFILE_KEY.fullmatch(key):
                raise SafeError("The account registry contains an invalid key. Restore a private backup.")
        if len(values) != len(set(values)):
            raise SafeError("The account registry contains duplicate profile keys. Restore a private backup.")
        return list(values)

    def _migrate_legacy(self):
        data = self.controller.reload()
        if int(data.get("multi_account_version", 0)) >= 2:
            # Validate the index, but isolate unreadable/missing child states.
            # get() refuses to recreate them; tick_all still reaches healthy jobs.
            self.keys()
            return
        if data.get("profiles"):
            raise SafeError("An unfinished registry upgrade was detected. Restore a private backup before continuing.")
        key = "main"
        folder = self._path(key)
        folder.mkdir(exist_ok=True)
        private_mode(folder, directory=True)
        target = Store(folder)
        copied = {field: data[field] for field in ACCOUNT_FIELDS}
        if copied["session_name"] and not copied["session_name"].startswith("@local/"):
            copied["session_name"] = "@local/" + copied["session_name"]
        # V1 required session UID == controller UID. Pin only a verified legacy
        # profile; otherwise let its own phone verification establish the target.
        if copied["registered"] and not copied["account_user_id"]:
            copied["account_user_id"] = int(data["owner_id"] or 0)
        copied.update(api_id=data["api_id"], api_hash=data["api_hash"], owner_id=0,
                      bot_token="", label="Account 1", multi_account_version=2)
        target.update(**copied)
        # Child is durable first. One atomic controller write both registers it
        # and clears the old single-account fields, avoiding duplicate jobs.
        cleared = {field: DEFAULTS[field] for field in ACCOUNT_FIELDS}
        self.controller.update(
            **cleared, profiles=[key], active_account=key,
            multi_account_version=2, schema_version=2, next_account_number=2,
        )
        log.info("Migrated legacy account state without making a Telegram request")

    @property
    def active_key(self) -> str:
        key = self.controller.reload()["active_account"]
        if key not in self.keys():
            raise SafeError("No active account. Use /accounts.")
        return key

    def get(self, key: str | None = None) -> AccountContext:
        key = key or self.active_key
        if key not in self.keys():
            raise SafeError("That account no longer exists. Use /accounts again.")
        if key in self.cache:
            return self.cache[key]
        folder = self._path(key)
        if not (folder / "config.json").is_file():
            raise SafeError("This account's saved state is missing. Restore its private backup; do not recreate a timer.")
        store = Store(folder)
        # Keep common application credentials synchronized, never a bot token.
        store.update(api_id=self.controller.data["api_id"], api_hash=self.controller.data["api_hash"], owner_id=0, bot_token="")
        manager = SessionManager(store, shared_root=self.root)
        engine = RecoveryEngine(store, manager, self.vault)
        account = AccountContext(key, store, manager, engine)
        self.cache[key] = account
        return account

    def create(self) -> AccountContext:
        keys = self.keys()
        limit = max(1, min(20, int(self.controller.data.get("max_accounts", 10))))
        if len(keys) >= limit:
            raise SafeError(f"The local limit is {limit} account profiles. Remove an unused idle profile with /removeaccount before adding another.")
        key = secrets.token_hex(6)
        while self._path(key).exists():
            key = secrets.token_hex(6)
        folder = self._path(key)
        folder.mkdir(mode=0o700)
        store = Store(folder)
        number = int(self.controller.data.get("next_account_number", len(keys) + 1))
        store.update(label=f"Account {number}", api_id=self.controller.data["api_id"],
                     api_hash=self.controller.data["api_hash"], multi_account_version=2,
                     owner_id=0, bot_token="")
        self.controller.update(profiles=keys + [key], active_account=key, next_account_number=number + 1)
        return self.get(key)

    def select(self, key: str) -> AccountContext:
        account = self.get(key)
        self.controller.update(active_account=key)
        return account

    def assert_unique(self, key: str | None = None):
        account = self.get(key)
        data = account.store.reload()
        uid = int(data["account_user_id"] or data["detected_user_id"] or 0)
        if not uid:
            return
        for other_key in self.keys():
            if other_key == account.key:
                continue
            other = self.get(other_key)
            entry = other.store.reload()
            other_uid = int(entry["account_user_id"] or entry["detected_user_id"] or 0)
            if other_uid == uid:
                raise SafeError(f"That Telegram account is already added as {entry['label']}. Select it in /accounts instead. A duplicate timer was not created.")

    async def remove(self, key: str):
        account = self.get(key)
        async with account.engine.lock:
            if account.store.reload()["reset_status"] == "waiting":
                raise SafeError("This profile has an active saved job. Use /cancel for this account first. Other accounts are unaffected.")
            await account.sessions.close()
            keys = [value for value in self.keys() if value != key]
            active = self.controller.data["active_account"]
            if active == key:
                active = keys[0] if keys else ""
            # Remove from the durable registry first. A leftover folder after a
            # crash is harmless; the reverse order could lose a registered job.
            self.controller.update(profiles=keys, active_account=active)
            self.cache.pop(key, None)
            shutil.rmtree(self._path(key))
        if not keys:
            self.create()

    def next_due(self) -> int:
        """Earliest saved retry time. Disk only; no session is opened."""
        soon = 0
        for key in self.keys():
            try:
                data = self.get(key).store.reload()
            except Exception:
                continue
            if data.get("reset_status") != "waiting":
                continue
            when = int(data.get("next_attempt_at") or 0)
            if when > 0 and (soon == 0 or when < soon):
                soon = when
        return soon

    async def tick_all(self) -> dict[str, str]:
        outcomes = {}
        for key in self.keys():
            try:
                account = self.get(key)
                outcomes[key] = await account.engine.tick()
            except asyncio.CancelledError:
                raise
            except Exception as error:
                # No raw exception values. One corrupt/expired account cannot
                # prevent the scheduler from reaching another due account.
                log.warning("Account scheduler isolated failure (%s)", type(error).__name__)
                outcomes[key] = "Account check paused: " + type(error).__name__
        return outcomes

    def has_notices(self) -> bool:
        if self.controller.reload()["notices"]:
            return True
        for key in self.keys():
            try:
                if self.get(key).store.reload()["notices"]:
                    return True
            except Exception:
                continue
        return False

    async def close(self):
        for account in list(self.cache.values()):
            try:
                await account.sessions.close()
            except Exception as error:
                log.warning("Account disconnect failed (%s)", type(error).__name__)
