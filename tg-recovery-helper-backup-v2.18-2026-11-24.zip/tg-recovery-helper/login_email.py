"""Explicit owner-driven LOGIN-email change; never 2FA recovery-email change.

Only GetPassword, SendVerifyEmailCode(LoginChange) and VerifyEmail(LoginChange)
are used. No sign-in, phone/SMS-code request, login-email reset helper, password update,
logout, session revocation or account-deletion method exists in this feature.
Codes exist only transiently in the caller/RPC; never journaled or echoed.
"""
from __future__ import annotations

import asyncio
import copy
import hmac
import logging
import re
import secrets
import time
from dataclasses import dataclass

from security_alerts import retry_delay, stamp
from storage import SafeError

CACHE_KEY = "email_info"
STATE_KEY = "login_email_change"
TTL = 600
RPC_TIMEOUT = 25
SEND_COOLDOWN = 120
MAX_SENDS_PER_HOUR = 3
MAX_CODE_ATTEMPTS = 3
log = logging.getLogger(__name__)


@dataclass(frozen=True)
class LoginEmailCode:
    pattern: str
    length: int


@dataclass(frozen=True)
class LoginEmailReceipt:
    confirmed: bool
    pattern: str = ""


def normalize_email(value):
    if not isinstance(value, str): raise SafeError("Enter one email address, not a link or message.")
    value = value.strip()
    if not 5 <= len(value) <= 254 or value.count("@") != 1 or any(c.isspace() or ord(c) < 32 for c in value):
        raise SafeError("Enter one valid email address without spaces, line breaks or links.")
    local, domain = value.rsplit("@", 1)
    if not re.fullmatch(r"[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]{1,64}", local) or local.startswith(".") or local.endswith(".") or ".." in local:
        raise SafeError("Use a valid, common ASCII email address; quoted/Unicode local parts are not supported.")
    try: domain = domain.encode("idna").decode("ascii").lower()
    except (UnicodeError, ValueError): raise SafeError("The email domain is invalid.") from None
    labels = domain.split(".")
    if len(labels) < 2 or any(not re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", label) for label in labels) or len(labels[-1]) < 2:
        raise SafeError("Enter a valid email domain, such as example.com.")
    result = (local + "@" + domain).lower()
    if len(result) > 254: raise SafeError("The email address is too long.")
    return result


def masked_email(value):
    """Always conceal the local part AND most of the domain, even for raw/full input."""
    if not isinstance(value, str) or not value or len(value) > 254 or "@" not in value:
        return "Configured (hidden)" if value else ""
    local, domain = value.rsplit("@", 1)
    first = local[:1] if local[:1].isascii() and local[:1].isalnum() else "*"
    domain_first = domain[:1] if domain[:1].isascii() and domain[:1].isalnum() else "*"
    suffix = domain.rsplit(".", 1)[-1]
    suffix = suffix if re.fullmatch(r"[A-Za-z]{2,12}", suffix) else "hidden"
    return (first + "***@" + domain_first + "***." + suffix).lower()


def _number(value):
    if type(value) is not int or not 0 <= value < 2**63: raise SafeError("Invalid email-operation metadata; no request was sent.")
    return value


def _error(value):
    if not isinstance(value, str) or value and not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,79}", value):
        raise SafeError("Email errors may contain a class name only, not private values.")


def _pattern(value):
    if value not in ("", "Configured (hidden)") and (not isinstance(value, str) or not re.fullmatch(r"[a-z0-9*]\*{3}@[a-z0-9*]\*{3}\.[a-z]{2,12}", value)):
        raise SafeError("An unmasked email pattern was rejected.")


def email_cache(data):
    result = {"checked_at": 0, "login_status": "unknown", "login_pattern": "", "recovery_status": "unknown",
              "two_factor": "unknown", "error": "", "retry_at": 0}
    raw = data.get(CACHE_KEY, {})
    if not isinstance(raw, dict) or set(raw) - set(result): raise SafeError("Email-status cache needs private backup repair.")
    result.update(copy.deepcopy(raw))
    _number(result["checked_at"]); _number(result["retry_at"]); _error(result["error"]); _pattern(result["login_pattern"])
    if result["login_status"] not in ("unknown", "set", "not_set", "unsupported") or result["recovery_status"] not in ("unknown", "set", "not_set", "unconfirmed", "set_pending") or result["two_factor"] not in ("unknown", "on", "off"):
        raise SafeError("Invalid email-status category.")
    return result


def info_cache(info, now):
    supported = bool(getattr(info, "login_email_supported", False))
    pattern = getattr(info, "login_email_pattern", "") or ""
    recovery = bool(info.has_recovery)
    pending = bool(getattr(info, "recovery_email_unconfirmed", False))
    result = email_cache({})
    result.update(checked_at=int(now), login_status=("set" if pattern else "not_set") if supported else "unsupported",
                  login_pattern=masked_email(pattern) if supported and pattern else "",
                  recovery_status=("set_pending" if recovery else "unconfirmed") if pending else ("set" if recovery else "not_set"),
                  two_factor="on" if info.has_password else "off")
    return email_cache({CACHE_KEY: result})


def email_lines(data):
    try: cache = email_cache(data)
    except SafeError: return ["Login email: UNKNOWN — status needs attention", "2FA recovery email: UNKNOWN"]
    login = {"unknown": "UNKNOWN — use Email status", "unsupported": "UNKNOWN — adapter unavailable", "set": "SET", "not_set": "NOT SET"}[cache["login_status"]]
    recovery = {"unknown": "UNKNOWN", "set": "SET", "not_set": "NOT SET", "unconfirmed": "UNCONFIRMED", "set_pending": "SET (update unconfirmed)"}[cache["recovery_status"]]
    if cache["login_pattern"]: login += " (" + cache["login_pattern"] + ")"
    stale = bool(cache["checked_at"]) and int(time.time()) - cache["checked_at"] > TTL
    suffix = " — last known; refresh needed" if (cache["error"] or stale) else ""
    return ["Login email: " + login + suffix, "2FA recovery email: " + recovery + suffix]


def change_state(data):
    state = {"stage": "idle", "target_user_id": 0, "nonce": "", "created_at": 0, "expires_at": 0,
             "encrypted_email": "", "new_pattern": "", "before_pattern": "", "code_length": 0,
             "code_attempts": 0, "verify_retry_at": 0, "last_request_at": 0, "window_at": 0,
             "window_count": 0, "retry_at": 0, "error": "", "last_success_at": 0}
    raw = data.get(STATE_KEY, {})
    if not isinstance(raw, dict) or set(raw) - set(state): raise SafeError("Login-email journal is invalid; no change was guessed.")
    state.update(copy.deepcopy(raw))
    if state["stage"] not in ("idle", "confirm_send", "sending", "send_uncertain", "awaiting_code", "verifying", "verify_uncertain", "completed", "expired", "cancelled", "failed"):
        raise SafeError("Invalid login-email stage.")
    for key in ("target_user_id", "created_at", "expires_at", "code_length", "code_attempts", "verify_retry_at", "last_request_at", "window_at", "window_count", "retry_at", "last_success_at"): _number(state[key])
    if not isinstance(state["nonce"], str) or state["nonce"] and not re.fullmatch(r"[a-f0-9]{16}", state["nonce"]): raise SafeError("Invalid email confirmation token.")
    encrypted = state["encrypted_email"]
    if not isinstance(encrypted, str) or encrypted and (not encrypted.startswith("fernet:") or len(encrypted) > 3000): raise SafeError("Only an encrypted destination may enter the email journal.")
    _pattern(state["new_pattern"]); _pattern(state["before_pattern"]); _error(state["error"])
    if state["code_length"] > 16: raise SafeError("Unsupported email verification-code length.")
    return state


def normalize_code(value, length=0):
    if not isinstance(value, str) or "\n" in value or "\r" in value: raise SafeError("Enter only the code EMAILED for this request, not a login code or link.")
    code = value.strip().replace(" ", "").replace("-", "")
    if not re.fullmatch(r"[A-Za-z0-9]{3,16}", code) or length and len(code) != length:
        raise SafeError("Enter only the emailed verification code" + (f" ({length} characters)" if length else "") + ". No code was submitted.")
    return code


class LoginEmailService:
    def __init__(self, registry, controller, clock=time.time):
        self.registry, self.controller, self.clock = registry, controller, clock
        self.vault = registry.vault

    def _save(self, account, state): account.store.update(**{STATE_KEY: change_state({STATE_KEY: state})})

    async def _adapter(self, account):
        data = account.store.reload()
        uid = int(data.get("account_user_id") or data.get("detected_user_id") or 0)
        if not uid or not data.get("session_name"): raise SafeError("Add/select your own valid session first. No login code will be requested.")
        adapter = await account.sessions.ensure()
        if not account.sessions.me or int(account.sessions.me.id) != uid: raise SafeError("Email action stopped: the session ID does not match this account.")
        return adapter, uid

    def _prune(self, account):
        state = change_state(account.store.reload())
        if state["expires_at"] and int(self.clock()) > state["expires_at"] and state["stage"] not in ("completed", "cancelled", "expired"):
            state.update(stage="expired", encrypted_email="", nonce="", expires_at=0)
            self._save(account, state)
        return state

    async def _info_locked(self, account):
        cache = email_cache(account.store.reload())
        if cache["retry_at"] > int(self.clock()): raise SafeError("Email status is rate-limited/delayed until " + stamp(cache["retry_at"]) + ".")
        try:
            adapter, _ = await self._adapter(account)
            info = await asyncio.wait_for(adapter.info(), RPC_TIMEOUT)
            cache = info_cache(info, int(self.clock()))
            account.store.update(**{CACHE_KEY: cache})
            return cache
        except asyncio.CancelledError: raise
        except SafeError:
            raise  # Controlled local identity/session problems stay explicit, no cache guess.
        except Exception as error:
            cache.update(error=type(error).__name__[:80], retry_at=int(self.clock()) + retry_delay(error))
            account.store.update(**{CACHE_KEY: cache})
            log.warning("Email-status read deferred (%s); no private values logged", type(error).__name__)
            raise SafeError("Email status could not be refreshed. Last known information is preserved; try later.") from None

    async def refresh(self, key):
        account = self.registry.get(key)
        async with account.engine.lock:
            self._prune(account)
            return await self._info_locked(account)

    async def refresh_all(self):
        async def one(key):
            try:
                account = self.registry.get(key); data = account.store.reload()
                if (data.get("account_user_id") or data.get("detected_user_id")) and data.get("session_name"): await self.refresh(key)
            except asyncio.CancelledError: raise
            except Exception as error: log.warning("Email-status account isolated (%s); no values logged", type(error).__name__)
        await asyncio.gather(*(one(key) for key in self.registry.keys()))

    def _mutable(self, data):
        if data.get("reset_status") == "waiting" and data.get("phase") in ("requesting", "old_removed", "applying"):
            raise SafeError("Password recovery is in a sensitive application phase. Finish/check it before changing login email. Read-only email status is still available.")

    def _eligible(self, cache):
        if cache["login_status"] == "not_set": raise SafeError("Telegram reports NO login email configured. This is a change-only flow. Set up login email in the official app if Telegram offers it; no sign-in/SMS flow is started here.")
        if cache["login_status"] != "set" or cache["error"]: raise SafeError("A fresh supported login-email status is required before changing it.")

    async def begin(self, key):
        account = self.registry.get(key)
        async with account.engine.lock:
            state = self._prune(account)
            if state["stage"] in ("sending", "send_uncertain", "awaiting_code", "verifying", "verify_uncertain"):
                return state  # Resume; never implicitly resend or replace a live request.
            self._mutable(account.store.reload())
            self._eligible(await self._info_locked(account))
            return state

    async def prepare(self, key, email):
        email = normalize_email(email)
        account = self.registry.get(key)
        async with account.engine.lock:
            old = self._prune(account)
            if old["stage"] in ("sending", "send_uncertain", "awaiting_code", "verifying", "verify_uncertain"): raise SafeError("An email request already exists for this account. Resume it or stop local input first.")
            self._mutable(account.store.reload())
            cache = await self._info_locked(account); self._eligible(cache)
            _, uid = await self._adapter(account)
            now = int(self.clock())
            old.update(stage="confirm_send", target_user_id=uid, nonce=secrets.token_hex(8), created_at=now,
                       expires_at=now + TTL, encrypted_email=self.vault.seal(email), new_pattern=masked_email(email),
                       before_pattern=cache["login_pattern"], code_length=0, code_attempts=0, verify_retry_at=0, error="")
            self._save(account, old)
            return old

    def _bound(self, account, nonce, allowed):
        state = self._prune(account)
        uid = int(account.store.data.get("account_user_id") or account.store.data.get("detected_user_id") or 0)
        if state["stage"] not in allowed or not state["nonce"] or not hmac.compare_digest(state["nonce"], str(nonce)) or state["target_user_id"] != uid or not state["expires_at"]:
            raise SafeError("This login-email step expired or belongs to another account. Open /email on the intended account.")
        if state["retry_at"] > int(self.clock()): raise SafeError("Telegram/email retry delay is active until " + stamp(state["retry_at"]) + ".")
        return state

    def _destination(self, state): return normalize_email(self.vault.open(state["encrypted_email"]))

    def _failed(self, account, state, error, stage):
        state.update(stage=stage, error=type(error).__name__[:80], retry_at=int(self.clock()) + retry_delay(error))
        self._save(account, state)
        log.warning("Login-email operation deferred (%s); no address/code/exception values logged", type(error).__name__)

    async def send(self, key, nonce, *, resend=False):
        account = self.registry.get(key)
        async with account.engine.lock:
            allowed = {"confirm_send"} | ({"sending", "send_uncertain", "awaiting_code"} if resend else set())
            state = self._bound(account, nonce, allowed)
            self._mutable(account.store.reload())
            now = int(self.clock())
            if state["last_request_at"] and now - state["last_request_at"] < SEND_COOLDOWN: raise SafeError("Wait at least two minutes between email-code requests for this account. Check the mailbox first.")
            if now - state["window_at"] >= 3600: state.update(window_at=now, window_count=0)
            if state["window_count"] >= MAX_SENDS_PER_HOUR: raise SafeError("This account reached the local limit of three email-code requests per hour. Try later.")
            cache = await self._info_locked(account); self._eligible(cache)
            if cache["login_pattern"] != state["before_pattern"]: raise SafeError("The login-email status changed elsewhere. Refresh/review it before starting a different request.")
            adapter, uid = await self._adapter(account)
            if uid != state["target_user_id"]: raise SafeError("Email action identity changed; request stopped.")
            destination = self._destination(state)
            state.update(stage="sending", last_request_at=now, window_count=state["window_count"] + 1,
                         expires_at=now + TTL, code_attempts=0, verify_retry_at=0, error="")
            self._save(account, state)  # Intent durable BEFORE the email-request RPC.
            try:
                result = await asyncio.wait_for(adapter.request_login_email_code(destination), RPC_TIMEOUT)
                if not isinstance(result, LoginEmailCode) or type(result.length) is not int or not 0 <= result.length <= 16:
                    raise SafeError("The email request response could not be verified.")
                state.update(stage="awaiting_code", code_length=result.length, retry_at=0, error="")
                self._save(account, state)
                return state
            except asyncio.CancelledError: raise
            except SafeError as error:
                self._failed(account, state, error, "send_uncertain")
                raise  # A controlled response-shape failure is never success.
            except Exception as error:
                name = type(error).__name__.lower()
                definite = any(x in name for x in ("emailinvalid", "emailnotallowed", "emailnotsetup", "flood", "slowmode"))
                self._failed(account, state, error, "confirm_send" if definite else "send_uncertain")
                if "emailnotsetup" in name: raise SafeError("Telegram refused change: no existing login email is set. No setup/sign-in fallback was attempted.") from None
                if "emailinvalid" in name or "emailnotallowed" in name: raise SafeError("Telegram rejected that email address. Stop local input, then choose another address; no code value was logged.") from None
                if "flood" in name or "slowmode" in name: raise SafeError("Telegram rate-limited the email request. Its retry time is saved; no automatic resend will occur.") from None
                raise SafeError("Email-request outcome is uncertain. Check the new mailbox; resume with its code if received. The bot will NOT automatically resend.") from None
            finally: destination = ""

    async def verify(self, key, nonce, code):
        account = self.registry.get(key)
        async with account.engine.lock:
            state = self._bound(account, nonce, {"sending", "send_uncertain", "awaiting_code"})
            self._mutable(account.store.reload())
            if state["code_attempts"] >= MAX_CODE_ATTEMPTS: raise SafeError("Three code attempts were used. Stop local input and review the email status; no automatic retry is made.")
            if state["verify_retry_at"] > int(self.clock()): raise SafeError("Wait a few seconds before submitting another emailed code.")
            code = normalize_code(code, state["code_length"])
            adapter, uid = await self._adapter(account)
            if uid != state["target_user_id"]: raise SafeError("Email verification belongs to another account.")
            destination = self._destination(state)
            state.update(stage="verifying", code_attempts=state["code_attempts"] + 1, verify_retry_at=int(self.clock()) + 5)
            self._save(account, state)  # Never store the code, even for restart recovery.
            try:
                receipt = await asyncio.wait_for(adapter.confirm_login_email_code(code, destination), RPC_TIMEOUT)
                if not isinstance(receipt, LoginEmailReceipt) or receipt.confirmed is not True:
                    raise SafeError("Telegram did not return a matching login-email confirmation.")
                cache = email_cache(account.store.reload())
                cache.update(checked_at=int(self.clock()), login_status="set", login_pattern=masked_email(destination), error="", retry_at=0)
                state.update(stage="completed", encrypted_email="", nonce="", expires_at=0, retry_at=0, error="", last_success_at=int(self.clock()))
                account.store.update(**{CACHE_KEY: cache, STATE_KEY: change_state({STATE_KEY: state})})
                return state
            except asyncio.CancelledError: raise
            except SafeError as error:
                self._failed(account, state, error, "verify_uncertain")
                raise  # No automatic replay and no success claim for a rejected receipt.
            except Exception as error:
                name = type(error).__name__.lower()
                invalid = "codeinvalid" in name or "emailcodeinvalid" in name
                expired = "verifyexpired" in name or "codeexpired" in name
                flood = "flood" in name or "slowmode" in name
                stage = "awaiting_code" if invalid or flood else "expired" if expired else "verify_uncertain"
                self._failed(account, state, error, stage)
                if expired:
                    state.update(encrypted_email="", nonce="", expires_at=0); self._save(account, state)
                    raise SafeError("Telegram reports that this email verification expired. Check the current status before explicitly starting another request.") from None
                if invalid:
                    state["retry_at"] = int(self.clock()) + 5; self._save(account, state)
                    raise SafeError("Telegram did not accept the emailed code. It was not echoed/saved; check the same mailbox and request.") from None
                if flood: raise SafeError("Telegram rate-limited verification. Retry time is saved; no code is automatically replayed.") from None
                raise SafeError("Verification outcome is uncertain. Check login-email status in the official app. The bot will not automatically replay the code or claim success.") from None
            finally:
                code = ""; destination = ""  # Best effort: Python/cloud chats are not secure erasure.

    async def cancel_local(self, key):
        account = self.registry.get(key)
        async with account.engine.lock:
            state = change_state(account.store.reload())
            state.update(stage="cancelled", encrypted_email="", nonce="", expires_at=0)
            self._save(account, state)  # Rate-limit counters/retry time deliberately retained.


def email_screen(account):
    from telegram import InlineKeyboardButton as Button, InlineKeyboardMarkup as Markup
    data = account.store.reload(); cache = email_cache(data); state = change_state(data)
    lines = ["LOGIN EMAIL", account.label(), *email_lines(data), "Checked: " + stamp(cache["checked_at"]), "",
             "Login email receives sign-in codes; it is NOT your 2FA recovery email. Changing it does not bypass password recovery."]
    if cache["retry_at"] > int(time.time()):
        lines.append("Status retry allowed after: " + stamp(cache["retry_at"]))
    if state["retry_at"] > int(time.time()):
        lines.append("Email-change retry allowed after: " + stamp(state["retry_at"]))
    if state["stage"] == "completed" and state["last_success_at"]:
        lines.append("Last confirmed change: " + stamp(state["last_success_at"]))
    rows = [[Button("Refresh email status", callback_data=f"acct:{account.key}:emailrefresh")]]
    active = state["stage"] in ("confirm_send", "sending", "send_uncertain", "awaiting_code", "verifying", "verify_uncertain")
    if active:
        lines += ["", "Saved email step: " + state["stage"].replace("_", " "), "Destination: " + state["new_pattern"],
                  "Local input expires: " + stamp(state["expires_at"])]
        if state["stage"] in ("verifying", "verify_uncertain"):
            lines.append("Previous verification may have completed. Review the official app; no automatic replay occurs.")
        else: rows.append([Button("Resume email step", callback_data=f"acct:{account.key}:emailresume")])
        rows.append([Button("Stop LOCAL email input", callback_data=f"acct:{account.key}:emailcancel")])
    elif cache["login_status"] == "set" and not cache["error"]:
        rows.append([Button("Change LOGIN email", callback_data=f"acct:{account.key}:emailchange")])
    else:
        lines.append("Only an existing login email can be changed here. If NOT SET, use the official app's setup when Telegram offers it; this bot never creates a login/SMS flow.")
    rows += [[Button("Open account", callback_data="account:" + account.key), Button("My IDs", callback_data="myids")]]
    lines.append("New address and code pass through this private Telegram bot chat. Codes are deleted best-effort, never echoed or saved by the helper. Enter only the verification code emailed for YOUR explicit request.")
    return "\n".join(lines), Markup(rows)
