"""Offline, synthetic OTP-forward tests. No login codes are requested.

The account's own session performs forwards; the bot controller only queues
metadata and notifies the owner about limits. Bodies never enter state.
"""
from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock

import bot
from otp_forward import (
    ENABLED_KEY, STATE_KEY, TARGET_KEY, INTERVAL, OtpForwarder,
    forward_state, forward_target,
)
from security_alerts import SERVICE_USER_ID, ServiceEvent
from storage import SafeError, Store

SENTINEL = "SYNTHETIC-PRIVATE-BODY Login code: 983761 https://example.invalid/secret-login"


class FloodWaitError(Exception):
    def __init__(self, seconds=120):
        super().__init__("flood")
        self.seconds = seconds


class MessageIdInvalidError(Exception):
    pass


class PeerFloodError(Exception):
    """Like Telegram's PEER_FLOOD: no timer attribute at all."""

    def __init__(self, reason="flood"):
        super().__init__(reason)


class History:
    def __init__(self, events=()):
        self.events = list(events)
        self.forwarded = []
        self.forward_error = None
        self.invalid_ids = set()
        self.error = None

    async def service_messages(self, offset_id=0, limit=50):
        if self.error:
            raise self.error
        return sorted((e for e in self.events if not offset_id or e.message_id < offset_id),
                      key=lambda e: e.message_id, reverse=True)[:limit]

    async def forward_service_messages(self, target, message_ids):
        if self.forward_error:
            raise self.forward_error
        if self.invalid_ids and set(message_ids) & self.invalid_ids:
            raise MessageIdInvalidError("gone")
        self.forwarded.append((target, list(message_ids)))
        return len(message_ids)


class ForwardTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.controller = Store(self.root)
        self.controller.update(owner_id=1234, api_id=12345, api_hash="a" * 32)
        self.rt = bot.Runtime(self.controller)
        self.a = self.rt.current
        self.now = [1800000000]
        self.history = self.attach(self.a, 7777)
        self.history.events = [ServiceEvent(50, self.now[0] - 600, "message")]
        self.forwarder = OtpForwarder(self.rt.registry, self.controller, clock=lambda: self.now[0])
        self.app = NS(bot=NS(send_message=AsyncMock()))

    def attach(self, account, uid):
        account.store.update(account_user_id=uid, detected_user_id=uid, registered=True,
                             owner_phone="+911234567890", library="telethon",
                             session_name="sessions/fake.session")
        history = History()
        account.sessions.me = NS(id=uid)
        account.sessions.ensure = AsyncMock(return_value=history)
        return history

    async def asyncTearDown(self):
        await self.rt.registry.close()
        self.temp.cleanup()

    def state(self, account=None):
        return forward_state((account or self.a).store.reload())

    async def baseline(self):
        await self.forwarder.poll_account(self.a)

    async def new_message(self, number=51, outgoing=False):
        self.history.events.append(ServiceEvent(number, self.now[0], "otp", outgoing))
        await self.forwarder.poll_account(self.a)

    # ---- configuration and state validation ----

    async def test_defaults_enable_existing_and_future_profiles(self):
        self.assertTrue(self.controller.reload()[ENABLED_KEY])
        self.assertTrue(self.a.store.reload()[ENABLED_KEY])
        self.assertTrue(self.rt.registry.create().store.reload()[ENABLED_KEY])
        self.assertEqual(self.controller.reload()[TARGET_KEY], "@tgidsel")

    async def test_state_rejects_body_or_text_fields(self):
        for field in ("body", "text", "code", "url", "media", "text_hash"):
            with self.subTest(field=field), self.assertRaises(SafeError):
                forward_state({STATE_KEY: {field: SENTINEL}})

    async def test_state_rejects_non_numeric_or_bad_class(self):
        for bad in ({"cursor": "1"}, {"pending": ["abc"]}, {"error": "flood: 983761"},
                    {"forwarded": -1}, {"pending": [0]}, {"fwd_retry_at": "soon"},
                    {"flood_strikes": -1}):
            with self.subTest(bad=bad), self.assertRaises(SafeError):
                forward_state({STATE_KEY: bad})

    async def test_target_requires_valid_username(self):
        self.assertEqual(forward_target({TARGET_KEY: "@tgidsel"}), "@tgidsel")
        for bad in ("tgidsel", "@ab", "https://t.me/tgidsel", ""):
            with self.subTest(bad=bad), self.assertRaises(SafeError):
                forward_target({TARGET_KEY: bad})

    # ---- baseline, queueing and forwarding ----

    async def test_baseline_does_not_replay_old_messages(self):
        await self.baseline()
        self.assertTrue(self.state()["initialized"])
        self.assertEqual(self.state()["cursor"], 50)
        self.assertEqual(self.state()["pending"], [])
        await self.forwarder.flush_account(self.a, self.app)
        self.assertEqual(self.history.forwarded, [])
        self.app.bot.send_message.assert_not_awaited()

    async def test_new_message_is_forwarded_by_session_not_bot(self):
        await self.baseline()
        await self.new_message(51)
        self.assertEqual(self.state()["pending"], [51])
        await self.forwarder.flush_account(self.a, self.app)
        self.assertEqual(self.history.forwarded, [("@tgidsel", [51])])
        self.assertEqual(self.state()["pending"], [])
        self.assertEqual(self.state()["forwarded"], 1)
        self.app.bot.send_message.assert_not_awaited()  # Success path never pings the bot.

    async def test_lock_off_does_not_queue_or_forward(self):
        await self.baseline()
        self.a.store.update(protection_lock_enabled=False)
        await self.new_message(51)
        self.assertEqual(self.state()["pending"], [])
        self.assertEqual(self.state()["cursor"], 51)  # advance without forwarding
        await self.forwarder.flush_account(self.a, self.app)
        self.assertEqual(self.history.forwarded, [])

    async def test_pending_kept_while_lock_turns_off_before_flush(self):
        await self.baseline()
        await self.new_message(51)
        self.a.store.update(protection_lock_enabled=False)
        await self.forwarder.flush_account(self.a, self.app)
        self.assertEqual(self.history.forwarded, [])
        self.assertEqual(self.state()["pending"], [51])
        self.a.store.update(protection_lock_enabled=True)
        await self.forwarder.flush_account(self.a, self.app)
        self.assertEqual(self.history.forwarded, [("@tgidsel", [51])])

    async def test_outgoing_message_is_not_forwarded(self):
        await self.baseline()
        await self.new_message(51, outgoing=True)
        self.assertEqual(self.state()["pending"], [])

    async def test_duplicate_poll_does_not_double_queue(self):
        await self.baseline()
        await self.new_message(51)
        await self.forwarder.poll_account(self.a)
        self.assertEqual(self.state()["pending"], [51])

    async def test_restart_retains_cursor_and_pending(self):
        await self.baseline()
        await self.new_message(51)
        rt2 = bot.Runtime(self.controller)
        try:
            forwarder2 = OtpForwarder(rt2.registry, self.controller, clock=lambda: self.now[0])
            history2 = History(events=list(self.history.events))
            account2 = rt2.registry.get(self.a.key)
            account2.sessions.me = NS(id=7777)
            account2.sessions.ensure = AsyncMock(return_value=history2)
            await forwarder2.poll_account(account2)
            self.assertEqual(forward_state(account2.store.reload())["pending"], [51])
            await forwarder2.flush_account(account2, self.app)
            self.assertEqual(history2.forwarded, [("@tgidsel", [51])])
        finally:
            await rt2.registry.close()

    # ---- limits and owner notification ----

    async def test_flood_defers_retains_queue_and_notifies_owner_once(self):
        await self.baseline()
        await self.new_message(51)
        self.history.forward_error = FloodWaitError(120)
        await self.forwarder.flush_account(self.a, self.app)
        self.assertEqual(self.state()["pending"], [51])  # retained, never dropped
        self.assertEqual(self.state()["error"], "FloodWaitError")
        self.assertEqual(self.state()["fwd_retry_at"], self.now[0] + 121)
        self.app.bot.send_message.assert_awaited_once()
        text = self.app.bot.send_message.await_args.args[1]
        self.assertIn("FloodWaitError", text)
        self.assertNotIn(SENTINEL, text)
        self.assertNotIn("983761", text)
        # Second flush while paused must not re-notify or re-attempt.
        await self.forwarder.flush_account(self.a, self.app)
        self.app.bot.send_message.assert_awaited_once()
        self.assertEqual(len(self.history.forwarded), 0)
        # After the wait it retries and succeeds.
        self.now[0] += 200
        self.history.forward_error = None
        await self.forwarder.flush_account(self.a, self.app)
        self.assertEqual(self.history.forwarded, [("@tgidsel", [51])])
        self.assertEqual(self.state()["pending"], [])

    async def test_peer_flood_leaves_the_id_alone_and_notifies_only_once(self):
        await self.baseline()
        await self.new_message(51)
        self.history.forward_error = PeerFloodError()
        await self.forwarder.flush_account(self.a, self.app)
        self.assertEqual(self.app.bot.send_message.await_count, 1)
        state = self.state()
        self.assertEqual(state["error"], "PeerFloodError")
        self.assertEqual(state["flood_strikes"], 1)
        self.assertGreaterEqual(state["fwd_retry_at"] - self.now[0], 900)  # no hammering
        # Polling keeps running during the pause (guard/security stay active)
        # and clears the reported error without erasing the notified class.
        await self.forwarder.poll_account(self.a)
        self.assertEqual(self.state()["error"], "")
        self.assertEqual(self.state()["error_notified"], "PeerFloodError")
        # A paused flush neither retries nor re-notifies.
        await self.forwarder.flush_account(self.a, self.app)
        self.assertEqual(self.app.bot.send_message.await_count, 1)
        self.assertEqual(self.state()["pending"], [51])
        # The next failure waits twice as long — the limited ID is left alone.
        self.now[0] = state["fwd_retry_at"] + 1
        await self.forwarder.flush_account(self.a, self.app)
        self.assertEqual(self.app.bot.send_message.await_count, 1)
        after = self.state()
        self.assertEqual(after["error"], "PeerFloodError")
        self.assertEqual(after["flood_strikes"], 2)
        self.assertGreaterEqual(after["fwd_retry_at"] - self.now[0], 1800)
        self.assertEqual(after["pending"], [51])  # nothing lost while paused

    async def test_second_message_ten_seconds_later_is_forwarded_too(self):
        await self.baseline()
        self.history.events.append(ServiceEvent(51, self.now[0], "otp", False))
        await self.forwarder.poll_account(self.a)
        await self.forwarder.flush_account(self.a, self.app)
        self.assertEqual(self.history.forwarded, [("@tgidsel", [51])])
        # Ten seconds later another OTP lands in the same chat — it must go too.
        self.now[0] += 10
        self.history.events.append(ServiceEvent(52, self.now[0], "otp", False))
        await self.forwarder.poll_account(self.a)
        await self.forwarder.flush_account(self.a, self.app)
        self.assertEqual(self.history.forwarded, [("@tgidsel", [51]), ("@tgidsel", [52])])
        self.assertEqual(self.state()["pending"], [])
        self.assertEqual(self.state()["forwarded"], 2)

    async def test_delivery_failure_retries_notification_without_losing_state(self):
        await self.baseline()
        await self.new_message(51)
        self.history.forward_error = FloodWaitError(60)
        self.app.bot.send_message.side_effect = RuntimeError("bot down")
        await self.forwarder.flush_account(self.a, self.app)
        self.assertEqual(self.state()["pending"], [51])
        self.assertEqual(self.state()["error_notified"], "")
        self.assertTrue(self.state()["notify_retry_at"] > self.now[0])
        self.app.bot.send_message.side_effect = None
        self.now[0] = self.state()["notify_retry_at"] + 1
        self.history.forward_error = None
        await self.forwarder.flush_account(self.a, self.app)
        # The limit report is retried after the outage: failed attempt + success.
        self.assertEqual(self.app.bot.send_message.await_count, 2)
        self.assertEqual(self.state()["error_notified"], "FloodWaitError")
        self.assertEqual(self.state()["pending"], [])
        self.assertEqual(self.history.forwarded, [("@tgidsel", [51])])

    async def test_invalid_message_ids_are_dropped_not_stuck(self):
        await self.baseline()
        await self.new_message(51)
        self.history.forward_error = MessageIdInvalidError("gone")
        await self.forwarder.flush_account(self.a, self.app)
        self.assertEqual(self.state()["pending"], [])
        self.assertEqual(self.state()["dropped"], 1)
        self.app.bot.send_message.assert_awaited_once()
        self.assertIn("dropped", self.app.bot.send_message.await_args.args[1].lower())
        self.assertEqual(self.history.forwarded, [])

    async def test_notification_never_contains_message_text(self):
        await self.baseline()
        # Craft state that would be notified with a body if ever leaked.
        self.a.store.update(**{STATE_KEY: {"initialized": True, "cursor": 50, "error": "FloodWaitError",
                                           "error_notified": "", "retry_at": self.now[0] + 50,
                                           "pending": [51], "forwarded": 3}})
        await self.forwarder.flush_account(self.a, self.app)
        self.app.bot.send_message.assert_awaited_once()
        text = self.app.bot.send_message.await_args.args[1]
        self.assertNotIn(SENTINEL, text)
        self.assertNotIn("983761", text)
        saved = json.dumps(self.a.store.reload())
        self.assertNotIn(SENTINEL, saved)

    async def test_has_pending_reflects_queue_and_unotified_error(self):
        self.assertFalse(self.forwarder.has_pending())
        await self.baseline()
        self.assertFalse(self.forwarder.has_pending())
        await self.new_message(51)
        self.assertTrue(self.forwarder.has_pending())

    async def test_master_switch_off_skips_poll_and_delivery(self):
        self.controller.update(**{ENABLED_KEY: False})
        await self.forwarder.poll_account(self.a)
        await self.new_message(51)
        self.assertEqual(self.state().get("initialized"), False)
        await self.forwarder.flush_account(self.a, self.app)
        self.assertEqual(self.history.forwarded, [])

    # ---- adapter contract (own session, correct peers) ----

    async def test_telethon_adapter_forwards_from_service_peer(self):
        from sessions import TelethonAdapter
        adapter = TelethonAdapter()
        adapter.client = NS(forward_messages=AsyncMock(return_value=[object(), object()]))
        count = await adapter.forward_service_messages("@tgidsel", [51, 52])
        self.assertEqual(count, 2)
        adapter.client.forward_messages.assert_awaited_once_with("@tgidsel", [51, 52],
                                                                 from_peer=SERVICE_USER_ID)

    async def test_telethon_adapter_falls_back_to_explicit_peer_when_uncached(self):
        from telethon.tl.types import InputPeerUser
        from sessions import TelethonAdapter
        adapter = TelethonAdapter()
        adapter.client = NS(forward_messages=AsyncMock(side_effect=[ValueError("no cache"),
                                                                    [object()]]))
        count = await adapter.forward_service_messages("@tgidsel", [51])
        self.assertEqual(count, 1)
        self.assertEqual(adapter.client.forward_messages.await_count, 2)
        peer = adapter.client.forward_messages.await_args.kwargs["from_peer"]
        self.assertIsInstance(peer, InputPeerUser)
        self.assertEqual(peer.user_id, SERVICE_USER_ID)

    async def test_pyrogram_adapter_forwards_from_service_chat(self):
        from sessions import PyrogramAdapter
        adapter = PyrogramAdapter()
        adapter.client = NS(forward_messages=AsyncMock(return_value=[object()]))
        count = await adapter.forward_service_messages("@tgidsel", [51])
        self.assertEqual(count, 1)
        adapter.client.forward_messages.assert_awaited_once_with("@tgidsel", SERVICE_USER_ID, [51])

    async def test_adapters_refuse_empty_id_list(self):
        from sessions import PyrogramAdapter, TelethonAdapter
        tele = TelethonAdapter()
        tele.client = NS(forward_messages=AsyncMock())
        self.assertEqual(await tele.forward_service_messages("@tgidsel", []), 0)
        tele.client.forward_messages.assert_not_awaited()
        pyro = PyrogramAdapter()
        pyro.client = NS(forward_messages=AsyncMock())
        self.assertEqual(await pyro.forward_service_messages("@tgidsel", []), 0)
        pyro.client.forward_messages.assert_not_awaited()

    async def test_interval_is_near_instant_but_not_spammy(self):
        self.assertGreaterEqual(INTERVAL, 1)
        self.assertLessEqual(INTERVAL, 5)

    async def test_multiple_messages_forward_together_in_one_flush(self):
        await self.baseline()
        for mid in (51, 52, 53):
            self.history.events.append(ServiceEvent(mid, self.now[0], "otp", False))
        await self.forwarder.poll_account(self.a)
        self.assertEqual(self.state()["pending"], [51, 52, 53])
        await self.forwarder.flush_account(self.a, self.app)
        # Single forward call, order preserved, nothing left waiting.
        self.assertEqual(self.history.forwarded, [("@tgidsel", [51, 52, 53])])
        self.assertEqual(self.state()["pending"], [])
        self.assertEqual(self.state()["forwarded"], 3)

    async def test_one_deleted_id_does_not_block_the_rest(self):
        await self.baseline()
        for mid in (51, 52, 53):
            self.history.events.append(ServiceEvent(mid, self.now[0], "otp", False))
        await self.forwarder.poll_account(self.a)
        self.history.invalid_ids = {52}
        await self.forwarder.flush_account(self.a, self.app)
        self.assertEqual(self.state()["pending"], [])
        self.assertEqual(self.state()["forwarded"], 2)
        self.assertEqual(self.state()["dropped"], 1)
        # Whole-batch call failed, then 51 ok, 52 dropped, 53 ok — nothing lost.
        self.assertEqual(self.history.forwarded, [("@tgidsel", [51]), ("@tgidsel", [53])])


if __name__ == "__main__":
    unittest.main()
