"""Offline regressions: direct import is a receipt, not a forced reset wizard."""
import sqlite3
import tempfile
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

import bot
from dashboard import import_screen
from ingest import ImportResult
from sessions import MAX_SESSION_BYTES
from storage import SafeError, Store
from ui_state import restore, save


def database(path, table="sessions"):
    db = sqlite3.connect(path)
    db.execute("CREATE TABLE " + table + " (dc_id INTEGER)")
    db.commit(); db.close()


def event(doc=None, uid=1234):
    return SimpleNamespace(effective_user=SimpleNamespace(id=uid), effective_chat=SimpleNamespace(type="private"),
                           callback_query=None, effective_message=SimpleNamespace(document=doc, reply_text=AsyncMock(), delete=AsyncMock()))


def ctx(rt, data=None):
    return SimpleNamespace(application=SimpleNamespace(bot_data={"runtime": rt}, bot=SimpleNamespace(send_message=AsyncMock())),
                           user_data={} if data is None else data)


def document(name="own.session", size=8192, metadata=8192, writer=database):
    async def download(path): writer(path)
    remote = SimpleNamespace(file_size=metadata, download_to_drive=AsyncMock(side_effect=download))
    doc = SimpleNamespace(file_name=name, file_size=size, get_file=AsyncMock(return_value=remote))
    return doc, remote


class ImportOnlyTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.store = Store(self.root)
        self.store.update(owner_id=1234, api_id=12345, api_hash="a" * 32)
        self.rt = bot.Runtime(self.store)
        self.a = self.rt.current
        self.a.store.update(account_user_id=7777, detected_user_id=7777, registered=True,
                            owner_phone="+911234567890", library="telethon")
        self.result = ImportResult(self.a, created=False, kept_active_job=False)

    async def asyncTearDown(self):
        await self.rt.registry.close()
        self.temp.cleanup()

    async def route_document(self, doc):
        self.rt.router.import_file = AsyncMock(return_value=self.result)
        with patch("bot.after_import", AsyncMock()) as after:
            await bot.document_input(event(doc), ctx(self.rt))
            return after

    def intent(self, *, age=0, key=None):
        return {"after_session": "reset", "session_account": key or self.a.key,
                "session_intent_at": int(time.time()) - age}

    async def test_plain_import_does_not_open_reset_or_password_wizard(self):
        update = event()
        with patch("bot.begin_reset", AsyncMock()) as begin:
            await bot.after_import(update, ctx(self.rt), self.result)
        begin.assert_not_awaited()
        self.assertIn("SESSION SAVED", update.effective_message.reply_text.await_args.args[0])

    async def test_unverified_import_is_saved_without_asking_phone(self):
        self.a.store.update(registered=False, owner_phone="", detected_phone="+911234567890")
        context = ctx(self.rt)
        update = event()
        with patch("bot.ask_phone", AsyncMock()) as phone, patch("bot.ask_password", AsyncMock()) as password:
            await bot.after_import(update, context, self.result)
        phone.assert_not_awaited(); password.assert_not_awaited()
        self.assertNotIn("flow", context.user_data)
        self.assertIn("+911234567890", update.effective_message.reply_text.await_args.args[0])
        self.assertFalse(self.a.store.reload()["registered"])

    async def test_compact_receipt_has_no_repeated_wait_footer(self):
        update = event()
        await bot.after_import(update, ctx(self.rt), self.result)
        text = update.effective_message.reply_text.await_args.args[0]
        self.assertLess(len(text), 500)
        self.assertNotIn(bot.FOOTER, text)
        self.assertNotIn("Enter", text)
        self.assertIn("No reset started", text)

    async def test_waiting_job_receipt_preserves_session_timer_and_password(self):
        self.a.store.update(reset_status="waiting", phase="waiting", wait_kind="reset",
                            reset_until_date=int(time.time()) + 86400, session_name="sessions/keep.session",
                            pending_new_password="cipher-to-keep")
        before = self.a.store.path.read_bytes()
        result = ImportResult(self.a, created=False, kept_active_job=True)
        with patch("bot.begin_reset", AsyncMock()) as begin:
            await bot.after_import(event(), ctx(self.rt), result)
        begin.assert_not_awaited()
        self.assertEqual(before, self.a.store.path.read_bytes())
        self.assertIn("Remaining:", import_screen(result, int(time.time()))[0])

    async def test_add_button_does_not_create_blank_profile(self):
        self.store.update(max_accounts=1)
        keys = self.rt.registry.keys()
        context = ctx(self.rt)
        await bot.addaccount_action(event(), context)
        self.assertEqual(keys, self.rt.registry.keys())
        self.assertNotIn("after_session", context.user_data)

    async def test_repeated_add_button_does_not_consume_slots_or_switch(self):
        key = self.rt.registry.active_key
        for _ in range(3): await bot.addaccount_action(event(), ctx(self.rt))
        self.assertEqual(self.rt.registry.keys(), [key])
        self.assertEqual(self.rt.registry.active_key, key)

    async def test_document_with_db_extension_is_accepted(self):
        doc, remote = document("own.db")
        after = await self.route_document(doc)
        remote.download_to_drive.assert_awaited_once(); after.assert_awaited_once()

    async def test_document_without_extension_is_accepted(self):
        doc, remote = document("my saved id")
        await self.route_document(doc)
        remote.download_to_drive.assert_awaited_once()

    async def test_document_without_filename_is_accepted(self):
        doc, remote = document(None)
        await self.route_document(doc)
        remote.download_to_drive.assert_awaited_once()

    async def test_document_filename_never_becomes_a_disk_path(self):
        doc, remote = document("../../outside.sqlite")
        await self.route_document(doc)
        target = Path(remote.download_to_drive.await_args.args[0])
        self.assertEqual(target.parent, self.rt.router.incoming)
        self.assertTrue(target.name.startswith("incoming_"))
        self.assertFalse((self.root.parent / "outside.sqlite").exists())

    async def test_missing_document_size_uses_file_metadata_once(self):
        doc, remote = document(size=None, metadata=8192)
        await self.route_document(doc)
        doc.get_file.assert_awaited_once(); remote.download_to_drive.assert_awaited_once()

    async def test_unbounded_unknown_size_is_not_downloaded(self):
        doc, remote = document(size=None, metadata=None)
        await bot.document_input(event(doc), ctx(self.rt))
        remote.download_to_drive.assert_not_awaited()

    async def test_known_oversized_document_is_not_downloaded(self):
        doc, remote = document(size=MAX_SESSION_BYTES + 1)
        await bot.document_input(event(doc), ctx(self.rt))
        doc.get_file.assert_not_awaited(); remote.download_to_drive.assert_not_awaited()

    async def test_conflicting_oversized_remote_metadata_is_rejected(self):
        doc, remote = document(metadata=MAX_SESSION_BYTES + 1)
        with self.assertRaises(SafeError): await bot.document_input(event(doc), ctx(self.rt))
        remote.download_to_drive.assert_not_awaited()
        self.assertFalse(list(self.rt.router.incoming.iterdir()))

    async def test_actual_download_size_is_checked_before_import(self):
        def sparse(path):
            with path.open("wb") as f: f.truncate(MAX_SESSION_BYTES + 1)
        doc, _ = document(writer=sparse)
        self.rt.router.import_file = AsyncMock()
        with self.assertRaises(SafeError): await bot.document_input(event(doc), ctx(self.rt))
        self.rt.router.import_file.assert_not_awaited()
        self.assertFalse(list(self.rt.router.incoming.iterdir()))

    async def test_bad_content_with_session_name_is_not_silently_accepted(self):
        doc, _ = document(writer=lambda p:p.write_bytes(b"not a session database" * 5))
        with self.assertRaises(SafeError): await bot.document_input(event(doc), ctx(self.rt))
        self.assertEqual(self.rt.registry.keys(), [self.a.key])
        self.assertFalse(list(self.rt.router.incoming.iterdir()))

    async def test_recent_explicit_reset_intent_resumes_for_same_profile_only(self):
        with patch("bot.begin_reset", AsyncMock()) as begin:
            await bot.after_import(event(), ctx(self.rt, self.intent()), self.result)
        begin.assert_awaited_once()
        self.assertEqual(begin.await_args.kwargs["mode"], "reset")

    async def test_expired_reset_intent_does_not_turn_upload_into_wizard(self):
        with patch("bot.begin_reset", AsyncMock()) as begin:
            await bot.after_import(event(), ctx(self.rt, self.intent(age=601)), self.result)
        begin.assert_not_awaited()

    async def test_old_saved_intent_without_timestamp_is_not_assumed_current(self):
        data = self.intent();data.pop("session_intent_at")
        with patch("bot.begin_reset", AsyncMock()) as begin:
            await bot.after_import(event(), ctx(self.rt, data), self.result)
        begin.assert_not_awaited()

    async def test_different_routed_account_does_not_inherit_reset_intent(self):
        b = self.rt.registry.create()
        with patch("bot.begin_reset", AsyncMock()) as begin:
            await bot.after_import(event(), ctx(self.rt, self.intent(key=self.a.key)), ImportResult(b, True, False))
        begin.assert_not_awaited()

    async def test_future_dated_reset_intent_is_not_valid(self):
        with patch("bot.begin_reset", AsyncMock()) as begin:
            await bot.after_import(event(), ctx(self.rt, self.intent(age=-100)), self.result)
        begin.assert_not_awaited()

    async def test_existing_waiting_job_never_continues_an_upload_intent(self):
        with patch("bot.begin_reset", AsyncMock()) as begin:
            await bot.after_import(event(), ctx(self.rt, self.intent()), ImportResult(self.a, False, True))
        begin.assert_not_awaited()

    async def test_explicit_session_intent_survives_restart(self):
        save(ctx(self.rt, self.intent()))
        fresh = bot.Runtime(Store(self.root))
        context = ctx(fresh);restore(context)
        with patch("bot.begin_reset", AsyncMock()) as begin:
            await bot.after_import(event(), context, ImportResult(fresh.current, False, False))
        begin.assert_awaited_once()
        await fresh.registry.close()

    async def test_non_owner_cannot_upload_any_filename(self):
        doc, remote = document("own.db")
        update = event(doc, uid=7777)
        await bot.document_input(update, ctx(self.rt))
        doc.get_file.assert_not_awaited();remote.download_to_drive.assert_not_awaited()
        self.assertEqual(update.effective_message.reply_text.await_args.args[0], "Access denied.")

    async def test_local_db_and_extensionless_sessions_are_detected(self):
        database(self.a.store.root / "own.db")
        database(self.a.store.root / "no extension")
        self.assertEqual(set(self.a.sessions.candidates()), {"own.db", "no extension"})
        self.assertEqual(self.a.sessions.checked_path("own.db"), self.a.store.root / "own.db")

    async def test_non_session_sqlite_is_not_in_local_picker(self):
        database(self.a.store.root / "other.sqlite", table="other")
        (self.a.store.root / "fake.session").write_bytes(b"not sqlite")
        self.assertEqual(self.a.sessions.candidates(), [])

    async def test_local_path_traversal_remains_rejected_for_db_files(self):
        with self.assertRaises(SafeError): self.a.sessions.checked_path("../other.db")

    async def test_local_symlinks_are_not_treated_as_sessions(self):
        real = self.a.store.root / "own.db";database(real)
        link = self.a.store.root / "alias.db"
        try:link.symlink_to(real)
        except (OSError,NotImplementedError):self.skipTest("Symlinks not supported")
        with self.assertRaises(SafeError):self.a.sessions.checked_path("alias.db")
        self.assertNotIn("alias.db", self.a.sessions.candidates())


if __name__ == "__main__":
    unittest.main()
