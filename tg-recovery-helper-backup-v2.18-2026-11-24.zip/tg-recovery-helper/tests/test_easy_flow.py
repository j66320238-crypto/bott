"""Offline tests for reply/resume, direct session routing, and safe detachment."""
import asyncio
import contextlib
import io
import json
import os
import sqlite3
import tempfile
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

import bot
import manage
from ingest import ImportResult
from storage import ProcessLock, SafeError, Store
from ui_state import restore, save


def message_update(text="", uid=1234, document=None):
    return SimpleNamespace(
        effective_user=SimpleNamespace(id=uid), effective_chat=SimpleNamespace(type="private"), callback_query=None,
        effective_message=SimpleNamespace(text=text, document=document, reply_text=AsyncMock(), delete=AsyncMock()),
    )


def context(runtime, data=None):
    return SimpleNamespace(application=SimpleNamespace(bot_data={"runtime": runtime}, bot=SimpleNamespace(send_message=AsyncMock())),
                           user_data={} if data is None else data)


def sqlite_session(path):
    db = sqlite3.connect(path)
    db.execute("CREATE TABLE sessions (dc_id INTEGER)")
    db.commit(); db.close()


class EasyFlowTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.store = Store(self.root)
        self.store.update(owner_id=1234, api_id=12345, api_hash="a" * 32)
        self.rt = bot.Runtime(self.store)
        self.account = self.rt.current
        self.account.store.update(registered=True, account_user_id=7777, detected_user_id=7777, owner_phone="+911234567890")

    async def asyncTearDown(self):
        await self.rt.registry.close()
        self.temp.cleanup()

    async def test_password_input_immediately_advances_and_replies(self):
        ctx = context(self.rt)
        await bot.ask_password(message_update(), ctx)
        update = message_update("New-password-for-tests")
        await bot.text_input(update, ctx)
        self.assertEqual(ctx.user_data["flow"], "password_confirm")
        update.effective_message.reply_text.assert_awaited_once()
        self.assertIn("Re-enter", update.effective_message.reply_text.await_args.args[0])
        saved = self.store.reload()["owner_ui_state"]
        self.assertTrue(saved["draft"]["encrypted"].startswith("fernet:"))
        self.assertNotIn("New-password-for-tests", self.store.path.read_text())

    async def test_password_confirmation_resumes_after_complete_restart(self):
        ctx = context(self.rt)
        await bot.ask_password(message_update(), ctx)
        await bot.text_input(message_update("New-password-for-tests"), ctx)
        fresh = bot.Runtime(Store(self.root))
        new_context = context(fresh)
        update = message_update("New-password-for-tests")
        await bot.text_input(update, new_context)
        self.assertEqual(new_context.user_data["flow"], "confirm")
        text = update.effective_message.reply_text.await_args.args[0]
        self.assertIn("No email", text)
        self.assertIn("Password saved", text)
        self.assertNotIn("New-password-for-tests", text)
        await fresh.registry.close()

    async def test_short_password_gets_visible_validation(self):
        ctx = context(self.rt)
        await bot.ask_password(message_update(), ctx)
        update = message_update("short")
        await bot.text_input(update, ctx)
        self.assertEqual(ctx.user_data["flow"], "password")
        self.assertIn("10-128", update.effective_message.reply_text.await_args.args[0])
        self.assertNotIn('"encrypted"', json.dumps(self.store.data["owner_ui_state"]))

    async def test_slash_prefixed_password_is_not_lost_as_unknown_command(self):
        ctx = context(self.rt)
        await bot.ask_password(message_update(), ctx)
        update = message_update("/unique-pass-for-tests")
        await bot.unknown_command(update, ctx)
        self.assertEqual(ctx.user_data["flow"], "password_confirm")
        self.assertNotIn("/unique-pass-for-tests", self.store.path.read_text())

    async def test_password_prompt_is_short_without_repeated_warning(self):
        update = message_update()
        await bot.ask_password(update, context(self.rt))
        text = update.effective_message.reply_text.await_args.args[0]
        self.assertLess(len(text), 500)
        self.assertNotIn("encrypted", text)
        self.assertNotIn("Bot chats are cloud", text)

    async def test_delete_timeout_cannot_stall_the_reply_forever(self):
        update = message_update()
        async def blocked(): await asyncio.sleep(60)
        update.effective_message.delete.side_effect = blocked
        started = time.monotonic()
        with patch("bot.INPUT_DELETE_TIMEOUT", 0.01):
            await bot.erase_input(update)
        self.assertLess(time.monotonic() - started, 0.5)

    async def test_cancel_clears_durable_input_state(self):
        ctx = context(self.rt)
        await bot.ask_password(message_update(), ctx)
        await bot.text_input(message_update("New-password-for-tests"), ctx)
        await bot.cancel_command(message_update(), ctx)
        self.assertEqual(self.store.reload()["owner_ui_state"], {})

    async def test_unencrypted_draft_is_never_persisted(self):
        ctx = context(self.rt, {"draft": {"encrypted": "not-ciphertext"}})
        with self.assertRaises(SafeError): save(ctx)
        self.assertNotIn("not-ciphertext", self.store.path.read_text())

    async def test_unauthorized_user_cannot_replace_saved_owner_step(self):
        self.store.update(owner_ui_state={"flow": "password", "draft": {"account_key": self.account.key}})
        await bot.text_input(message_update("not-for-owner", uid=9999), context(self.rt))
        self.assertEqual(self.store.reload()["owner_ui_state"]["flow"], "password")

    async def test_owner_document_accepted_without_prior_accept_or_command(self):
        downloaded = SimpleNamespace(download_to_drive=AsyncMock())
        async def write_file(path): sqlite_session(path)
        downloaded.download_to_drive.side_effect = write_file
        doc = SimpleNamespace(file_name="my.session", file_size=4096, get_file=AsyncMock(return_value=downloaded))
        result = ImportResult(self.account, created=False, kept_active_job=False)
        self.rt.router.import_file = AsyncMock(return_value=result)
        with patch("bot.after_import", AsyncMock()) as after:
            await bot.document_input(message_update(document=doc), context(self.rt))
            doc.get_file.assert_awaited_once()
            self.rt.router.import_file.assert_awaited_once()
            after.assert_awaited_once()

    async def test_unauthorized_document_is_still_not_downloaded(self):
        doc = SimpleNamespace(get_file=AsyncMock())
        await bot.document_input(message_update(uid=9999, document=doc), context(self.rt))
        doc.get_file.assert_not_awaited()


class AutoRoutingTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.store = Store(self.root)
        self.store.update(owner_id=1234, api_id=12345, api_hash="a" * 32)
        self.rt = bot.Runtime(self.store)
        self.a = self.rt.current
        self.source = self.root / "upload.session"
        sqlite_session(self.source)

    async def asyncTearDown(self):
        await self.rt.registry.close()
        self.temp.cleanup()

    def adapter(self, uid, phone="911234567890"):
        class Preview:
            async def connect(_self, *args): return SimpleNamespace(id=uid, phone=phone, bot=False)
            async def close(_self): pass
        return Preview

    async def route(self, uid, phone="911234567890"):
        with patch("sessions.TelethonAdapter", self.adapter(uid, phone)):
            return await self.rt.router.import_file(self.source)

    async def test_new_account_auto_uses_blank_profile_without_reset(self):
        result = await self.route(7777)
        self.assertEqual(result.account.key, self.a.key)
        self.assertEqual(self.a.store.data["detected_user_id"], 7777)
        self.assertEqual(self.a.store.data["account_user_id"], 7777)
        self.assertTrue(self.a.store.data["registered"])
        self.assertEqual(self.a.store.data["owner_phone"], "+911234567890")
        self.assertEqual(self.a.store.data["reset_status"], "idle")
        self.assertEqual(self.store.data["owner_id"], 1234)
        self.assertEqual(list(self.rt.router.incoming.iterdir()), [])

    async def test_different_account_auto_creates_another_profile(self):
        await self.route(7777)
        self.a.store.update(account_user_id=7777, registered=True, owner_phone="+911234567890")
        saved_a = self.a.store.path.read_text()
        result = await self.route(8888, "919876543210")
        self.assertNotEqual(result.account.key, self.a.key)
        self.assertEqual(len(self.rt.registry.keys()), 2)
        self.assertEqual(result.account.store.data["detected_user_id"], 8888)
        self.assertEqual(self.a.store.path.read_text(), saved_a)

    async def test_existing_account_is_selected_not_duplicated(self):
        await self.route(7777)
        self.a.store.update(account_user_id=7777, registered=True, owner_phone="+911234567890")
        b = self.rt.registry.create()
        result = await self.route(7777)
        self.assertEqual(result.account.key, self.a.key)
        self.assertEqual(len(self.rt.registry.keys()), 2)
        self.assertTrue(self.a.store.data["registered"])
        self.assertEqual(self.rt.registry.active_key, self.a.key)

    async def test_waiting_account_keeps_original_session_timer_and_password(self):
        self.a.store.update(account_user_id=7777, registered=True, owner_phone="+911234567890",
                            session_name="sessions/keep.session", reset_status="waiting", reset_until_date=123456,
                            pending_new_password="cipher-to-preserve")
        before = self.a.store.path.read_text()
        result = await self.route(7777)
        self.assertTrue(result.kept_active_job)
        self.assertEqual(before, self.a.store.path.read_text())

    async def test_live_phone_change_is_verified_without_typing(self):
        self.a.store.update(account_user_id=7777, registered=True, owner_phone="+911234567890")
        await self.route(7777, "919999999999")
        self.assertTrue(self.a.store.data["registered"])
        self.assertEqual(self.a.store.data["owner_phone"], "+919999999999")
        self.assertEqual(self.a.store.data["account_user_id"], 7777)
        self.assertEqual(self.a.store.data["reset_status"], "idle")

    async def test_invalid_file_does_not_consume_account_slot(self):
        bad = self.root / "bad.session"
        bad.write_text("not a database")
        with self.assertRaises(SafeError): await self.rt.router.import_file(bad)
        self.assertEqual(len(self.rt.registry.keys()), 1)
        self.assertEqual(list(self.rt.router.incoming.iterdir()), [])

    async def test_expired_session_does_not_modify_existing_account(self):
        class Expired:
            async def connect(_self, *args): raise SafeError("Session expired")
            async def close(_self): pass
        before = self.a.store.path.read_text()
        with patch("sessions.TelethonAdapter", Expired):
            with self.assertRaises(SafeError): await self.rt.router.import_file(self.source)
        self.assertEqual(self.a.store.path.read_text(), before)

    async def test_pyrogram_format_fallback_saved_per_account(self):
        class WrongFormat:
            async def connect(_self, *args): raise sqlite3.OperationalError("no such column: version")
            async def close(_self): pass
        with patch("sessions.TelethonAdapter", WrongFormat), patch("sessions.PyrogramAdapter", self.adapter(7777)):
            result = await self.rt.router.import_file(self.source)
        self.assertEqual(result.account.store.data["library"], "pyrogram")

    async def test_new_file_obeys_account_limit_without_overwriting(self):
        self.a.store.update(account_user_id=7777, registered=True, owner_phone="+911234567890")
        self.store.update(max_accounts=1)
        with self.assertRaisesRegex(SafeError, "limit is 1"):
            await self.route(8888)
        self.assertEqual(len(self.rt.registry.keys()), 1)
        self.assertEqual(self.a.store.data["account_user_id"], 7777)

    async def test_copy_failure_rolls_back_new_profile(self):
        self.a.store.update(account_user_id=7777, registered=True, owner_phone="+911234567890")
        with patch("ingest.shutil.copyfile", side_effect=OSError("simulated")):
            with self.assertRaises(OSError): await self.route(8888)
        self.assertEqual(self.rt.registry.keys(), [self.a.key])
        self.assertEqual(self.rt.registry.active_key, self.a.key)


class LauncherTests(unittest.TestCase):
    def test_process_lock_records_pid_for_safe_management(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "bot.lock"
            with ProcessLock(path):
                self.assertEqual(int(path.read_text()), os.getpid())

    def test_launch_is_detached_and_uses_private_log_not_ssh_streams(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            with patch("manage.lock_held", return_value=False), patch("manage.subprocess.Popen", return_value=SimpleNamespace(pid=42)) as launch:
                with contextlib.redirect_stdout(io.StringIO()): manage.start(root)
            kwargs = launch.call_args.kwargs
            if os.name == "posix": self.assertTrue(kwargs["start_new_session"])
            self.assertEqual(kwargs["stdin"], __import__('subprocess').DEVNULL)
            self.assertTrue(kwargs["close_fds"])
            self.assertTrue((root / "bot.log").exists())

    def test_already_running_process_does_not_start_second_poller(self):
        with tempfile.TemporaryDirectory() as tmp:
            with patch("manage.lock_held", return_value=True), patch("manage.subprocess.Popen") as launch:
                with contextlib.redirect_stdout(io.StringIO()): manage.start(Path(tmp))
            launch.assert_not_called()

    def test_unknown_pid_is_never_killed(self):
        with tempfile.TemporaryDirectory() as tmp:
            with patch("manage.lock_held", return_value=True), patch("manage.running_pid", return_value=None), patch("manage.os.kill") as kill:
                with contextlib.redirect_stdout(io.StringIO()): self.assertEqual(manage.stop(Path(tmp)), 1)
            kill.assert_not_called()


if __name__ == "__main__":
    unittest.main()
