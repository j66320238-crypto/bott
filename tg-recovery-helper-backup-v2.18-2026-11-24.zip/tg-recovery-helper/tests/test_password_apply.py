"""Password setup must skip recovery email and only report a confirmed 2FA state."""
import unittest
from types import SimpleNamespace
from unittest.mock import patch

from storage import SafeError
from sessions import PyrogramAdapter, TelethonAdapter


class NS(SimpleNamespace):
    def __getattr__(self, name):
        raise AttributeError(name)


class Recording:
    def __init__(self, outcomes):
        self.calls = []
        self.outcomes = list(outcomes)

    async def __call__(self, request):
        self.calls.append(request)
        outcome = self.outcomes.pop(0)
        if isinstance(outcome, Exception):
            raise outcome
        return outcome

    async def invoke(self, request):
        return await self(request)


def names(client):
    return [type(item).__name__ for item in client.calls]


class PasswordApplyTests(unittest.IsolatedAsyncioTestCase):
    async def test_telethon_omits_email_and_confirms_password_is_on(self):
        from telethon import password as pwd_mod
        algo = NS(salt1=b"salt-one-two-three")
        client = Recording([
            NS(has_password=False, new_algo=algo),
            True,
            NS(has_password=True, new_algo=algo),
        ])
        adapter = TelethonAdapter()
        adapter.client = client
        with patch.object(pwd_mod, "compute_digest", return_value=b"digest"):
            self.assertTrue(await adapter.set_password("saved-password", ""))
        self.assertEqual(names(client), ["GetPasswordRequest", "UpdatePasswordSettingsRequest", "GetPasswordRequest"])
        settings = client.calls[1].new_settings
        self.assertIsNone(settings.email)
        self.assertEqual(settings.hint, "")
        self.assertNotIn("ConfirmPasswordEmailRequest", names(client))
        self.assertNotIn("SendVerifyEmailCodeRequest", names(client))

    async def test_telethon_cancels_pending_email_code_then_sets_password_only(self):
        from telethon import password as pwd_mod
        from telethon.errors import EmailUnconfirmedError
        algo = NS(salt1=b"salt-one-two-three")
        client = Recording([
            NS(has_password=False, new_algo=algo),
            EmailUnconfirmedError(None, 6),
            True,
            NS(has_password=False, new_algo=algo),
            True,
            NS(has_password=True, new_algo=algo),
        ])
        adapter = TelethonAdapter()
        adapter.client = client
        with patch.object(pwd_mod, "compute_digest", return_value=b"digest"):
            self.assertTrue(await adapter.set_password("saved-password", None))
        self.assertEqual(names(client), [
            "GetPasswordRequest", "UpdatePasswordSettingsRequest", "CancelPasswordEmailRequest",
            "GetPasswordRequest", "UpdatePasswordSettingsRequest", "GetPasswordRequest",
        ])
        self.assertIsNone(client.calls[1].new_settings.email)
        self.assertIsNone(client.calls[4].new_settings.email)

    async def test_unconfirmed_email_is_never_reported_as_password_success(self):
        from telethon import password as pwd_mod
        from telethon.errors import EmailUnconfirmedError
        algo = NS(salt1=b"salt-one-two-three")
        client = Recording([
            NS(has_password=False, new_algo=algo),
            EmailUnconfirmedError(None, 6),
            True,
            NS(has_password=False, new_algo=algo),
            EmailUnconfirmedError(None, 6),
        ])
        adapter = TelethonAdapter()
        adapter.client = client
        with patch.object(pwd_mod, "compute_digest", return_value=b"digest"):
            with self.assertRaisesRegex(SafeError, "NOT applied"):
                await adapter.set_password("saved-password", "")
        self.assertNotIn("ConfirmPasswordEmailRequest", names(client))

    async def test_pyrogram_omits_email_and_confirms_password_is_on(self):
        algo = NS(salt1=b"salt-one-two-three", g=3, p=b"\x05")
        client = Recording([
            NS(has_password=False, new_algo=algo),
            True,
            NS(has_password=True, new_algo=algo),
        ])
        adapter = PyrogramAdapter()
        adapter.client = client
        with patch("pyrogram.utils.compute_password_hash", return_value=b"\x02"):
            self.assertTrue(await adapter.set_password("saved-password", ""))
        self.assertEqual(names(client), ["GetPassword", "UpdatePasswordSettings", "GetPassword"])
        self.assertIsNone(client.calls[1].new_settings.email)
        self.assertNotIn("ConfirmPasswordEmail", names(client))

    async def test_success_requires_a_followup_password_read(self):
        from telethon import password as pwd_mod
        algo = NS(salt1=b"salt-one-two-three")
        client = Recording([
            NS(has_password=False, new_algo=algo),
            True,
            NS(has_password=False, new_algo=algo),
        ])
        adapter = TelethonAdapter()
        adapter.client = client
        with patch.object(pwd_mod, "compute_digest", return_value=b"digest"):
            with self.assertRaisesRegex(SafeError, "did not confirm"):
                await adapter.set_password("saved-password", "")
