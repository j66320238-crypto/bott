"""Synthetic/offline login-email tests. No real email, code or login is created.

Only GetPassword, SendVerifyEmailCode(LoginChange) and VerifyEmail(LoginChange)
are represented. Every RPC below is a local mock.
"""
import asyncio
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock

import bot
import login_email
from login_email import (CACHE_KEY, MAX_CODE_ATTEMPTS, SEND_COOLDOWN, STATE_KEY, TTL, LoginEmailCode,
                         LoginEmailReceipt, LoginEmailService, change_state, email_cache, email_lines,
                         email_screen, info_cache, masked_email, normalize_code, normalize_email)
from dashboard import account_screen
from sessions import PasswordInfo, PyrogramAdapter, TelethonAdapter
from storage import SafeError, Store

PRIVATE_EMAIL = "new.person@example.com"
OLD_PATTERN = "j***@g***.com"
CODE = "A1B2C3"
PRIVATE = "PRIVATE-CONTENT " + CODE + " " + PRIVATE_EMAIL


class EmailNotSetupError(Exception):
    pass


class EmailInvalidError(Exception):
    pass


class EmailNotAllowedError(Exception):
    pass


class EmailCodeInvalidError(Exception):
    pass


class CodeExpiredError(Exception):
    pass


class FloodWaitError(Exception):
    def __init__(self, seconds=90):
        super().__init__(PRIVATE)  # An upstream body must never be surfaced.
        self.seconds = seconds


class EmailAdapter:
    """Local stand-in for a logged-in session adapter."""

    def __init__(self):
        self.info_result = PasswordInfo(True, True, "", 0, OLD_PATTERN, True, False)
        self.info_error = None
        self.request_error = None
        self.verify_error = None
        self.code_length = 6
        self.receipt = LoginEmailReceipt(True)
        self.on_request = None
        self.infos = 0
        self.requested = []
        self.confirmed = []

    async def info(self):
        self.infos += 1
        if self.info_error:
            raise self.info_error
        return self.info_result

    async def request_login_email_code(self, email):
        if self.on_request:
            await self.on_request()
        self.requested.append(email)
        if self.request_error:
            raise self.request_error
        return LoginEmailCode("n***@e***.com", self.code_length)

    async def confirm_login_email_code(self, code, email):
        self.confirmed.append((code, email))
        if self.verify_error:
            raise self.verify_error
        return self.receipt


def update(uid=1234, kind="private", action=None):
    return NS(effective_user=NS(id=uid), effective_chat=NS(type=kind),
              effective_message=NS(reply_text=AsyncMock(), delete=AsyncMock()),
              callback_query=NS(data=action, answer=AsyncMock(), edit_message_text=AsyncMock()) if action else None)


def context(rt):
    return NS(application=NS(bot_data={"runtime": rt}, bot=NS(send_message=AsyncMock())), user_data={})


def buttons(keyboard):
    return [b for row in keyboard.inline_keyboard for b in row]


def text_of(update):
    return update.effective_message.reply_text.await_args.args[0]


def edits_of(update):
    return [c.args[0] for c in update.callback_query.edit_message_text.await_args_list]


class FormatTests(unittest.TestCase):
    def test_normal_email_accepted_and_normalized(self):
        self.assertEqual(normalize_email("  New.Person@Example.COM "), "new.person@example.com")

    def test_links_spaces_unicode_and_multiple_at_rejected(self):
        for value in ("", "no-at-sign", "a@@b.com", "a b@example.com", "name@example", "x@y..com",
                      "a@-bad.com", "https://example.com/a@b.com", "üser@example.com", ".dot@example.com",
                      "a" * 70 + "@example.com", None, 1234):
            with self.subTest(value=value), self.assertRaises(SafeError):
                normalize_email(value)

    def test_masking_never_reveals_local_part_or_full_domain(self):
        for value in ("newperson@example.com", "someone@mycompany.co.in"):
            masked = masked_email(value)
            local, domain = value.split("@")
            self.assertNotIn(local, masked)
            self.assertNotIn(domain, masked)
            self.assertIn("***", masked)
            self.assertTrue(masked.endswith(domain.rsplit(".", 1)[-1]))
        self.assertEqual(masked_email(""), "")
        self.assertEqual(masked_email("x" * 300), "Configured (hidden)")
        self.assertNotIn(PRIVATE_EMAIL, masked_email(PRIVATE))

    def test_code_normalization_rejects_extra_text_and_wrong_length(self):
        self.assertEqual(normalize_code(" a1b 2-c3 ", 6), "a1b2c3")
        for value in ("ab cd extra words", "123", "A\nB2C3", "a$b2c3"):
            with self.subTest(value=value), self.assertRaises(SafeError):
                normalize_code(value, 6)

    def test_cache_and_journal_reject_plaintext_email_and_raw_rpc_values(self):
        with self.assertRaises(SafeError):
            email_cache({CACHE_KEY: {"login_pattern": PRIVATE_EMAIL}})
        with self.assertRaises(SafeError):
            email_cache({CACHE_KEY: {"login_status": "maybe"}})
        with self.assertRaises(SafeError):
            change_state({STATE_KEY: {"encrypted_email": PRIVATE_EMAIL}})
        with self.assertRaises(SafeError):
            change_state({STATE_KEY: {"stage": "unknown"}})
        with self.assertRaises(SafeError):
            change_state({STATE_KEY: {"error": PRIVATE}})

    def test_info_cache_separates_login_and_recovery_email(self):
        cache = info_cache(PasswordInfo(True, True, "", 0, OLD_PATTERN, True, True), 1000)
        self.assertEqual(cache["login_status"], "set")
        self.assertEqual(cache["recovery_status"], "set_pending")
        self.assertEqual(info_cache(PasswordInfo(True, False), 1000)["recovery_status"], "not_set")
        self.assertEqual(info_cache(PasswordInfo(True, True), 1000)["recovery_status"], "set")
        self.assertEqual(info_cache(PasswordInfo(True, False, "", 0, "", True, False), 1000)["login_status"], "not_set")
        self.assertEqual(info_cache(NS(has_password=True, has_recovery=False), 1000)["login_status"], "unsupported")

    def test_unknown_status_is_distinct_from_not_set(self):
        unknown = "\n".join(email_lines({}))
        self.assertIn("Login email: UNKNOWN", unknown)
        self.assertIn("2FA recovery email: UNKNOWN", unknown)
        known = email_lines({CACHE_KEY: {"checked_at": 10, "login_status": "not_set", "recovery_status": "set"}})
        self.assertIn("Login email: NOT SET", known[0])
        self.assertIn("2FA recovery email: SET", known[1])


class ServiceTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.controller = Store(self.root)
        self.controller.update(owner_id=1234, api_id=12345, api_hash="a" * 32)
        self.rt = bot.Runtime(self.controller)
        self.a = self.rt.current
        self.now = [1800000000]
        self.api = self.attach(self.a, 7777)
        self.service = LoginEmailService(self.rt.registry, self.controller, clock=lambda: self.now[0])

    def attach(self, account, uid):
        account.store.update(account_user_id=uid, detected_user_id=uid, registered=True,
                             owner_phone="+911234567890", detected_phone="+911234567890",
                             session_name="sessions/fake.session", library="telethon")
        api = EmailAdapter()
        account.sessions.me = NS(id=uid)
        account.sessions.ensure = AsyncMock(return_value=api)
        return api

    async def asyncTearDown(self):
        await self.rt.registry.close()
        self.temp.cleanup()

    def state(self, account=None):
        return change_state((account or self.a).store.reload())

    def raw(self, account=None):
        return (account or self.a).store.path.read_text()

    async def ready(self, *, status="set"):
        if status == "not_set":
            self.api.info_result = PasswordInfo(True, True, "", 0, "", True, False)
        elif status == "unsupported":
            self.api.info_result = PasswordInfo(True, True, "", 0, OLD_PATTERN, False, False)
        return await self.service.refresh(self.a.key)

    async def prepared(self):
        await self.ready()
        return await self.service.prepare(self.a.key, PRIVATE_EMAIL)

    async def test_status_refresh_caches_masked_pattern_only(self):
        cache = await self.service.refresh(self.a.key)
        self.assertEqual(cache["login_status"], "set")
        self.assertNotIn(PRIVATE_EMAIL, self.raw())
        self.assertIn("checked_at", cache)

    async def test_not_set_refuses_change_without_any_request_rpc(self):
        await self.ready(status="not_set")
        with self.assertRaisesRegex(SafeError, "NO login email"):
            await self.service.begin(self.a.key)
        with self.assertRaisesRegex(SafeError, "NO login email"):
            await self.service.prepare(self.a.key, PRIVATE_EMAIL)
        self.assertEqual(self.api.requested, [])
        self.assertEqual(self.api.confirmed, [])

    async def test_unsupported_adapter_is_unknown_not_not_set(self):
        await self.ready(status="unsupported")
        with self.assertRaisesRegex(SafeError, "fresh supported"):
            await self.service.prepare(self.a.key, PRIVATE_EMAIL)
        self.assertEqual(self.api.requested, [])

    async def test_prepare_stores_only_encrypted_destination_and_masked_pattern(self):
        state = await self.prepared()
        self.assertEqual(state["stage"], "confirm_send")
        self.assertEqual(state["new_pattern"], masked_email(PRIVATE_EMAIL))
        self.assertTrue(state["encrypted_email"].startswith("fernet:"))
        self.assertNotIn(PRIVATE_EMAIL, self.raw())
        self.assertNotIn("example.com", self.raw())
        self.assertEqual(self.api.requested, [])  # Nothing sent before explicit confirmation.

    async def test_send_saves_durable_intent_before_the_rpc(self):
        state = await self.prepared()
        seen = {}
        async def inspect():
            saved = json.loads(self.raw())[STATE_KEY]
            seen.update(saved)
        self.api.on_request = inspect
        sent = await self.service.send(self.a.key, state["nonce"])
        self.assertEqual(seen["stage"], "sending")
        self.assertEqual(seen["window_count"], 1)
        self.assertEqual(sent["stage"], "awaiting_code")
        self.assertEqual(self.api.requested, [PRIVATE_EMAIL])
        self.assertNotIn(CODE, self.raw())
        self.assertNotIn(PRIVATE_EMAIL, self.raw())

    async def test_send_requires_matching_profile_nonce(self):
        state = await self.prepared()
        with self.assertRaisesRegex(SafeError, "expired or belongs"):
            await self.service.send(self.a.key, "0" * 16)
        b = self.rt.registry.create()
        self.attach(b, 8888)
        with self.assertRaisesRegex(SafeError, "expired or belongs"):
            await self.service.send(b.key, state["nonce"])
        self.assertEqual(self.api.requested, [])

    async def test_expired_local_step_clears_destination(self):
        state = await self.prepared()
        self.now[0] += TTL + 5
        with self.assertRaises(SafeError):
            await self.service.send(self.a.key, state["nonce"])
        self.assertEqual(self.state()["stage"], "expired")
        self.assertEqual(self.state()["encrypted_email"], "")
        self.assertEqual(self.api.requested, [])

    async def test_email_not_setup_error_never_falls_back_to_setup(self):
        state = await self.prepared()
        self.api.request_error = EmailNotSetupError()
        with self.assertRaisesRegex(SafeError, "no existing login email"):
            await self.service.send(self.a.key, state["nonce"])
        self.assertEqual(self.state()["stage"], "confirm_send")
        self.assertEqual(len(self.api.requested), 1)
        self.assertEqual(self.api.confirmed, [])

    async def test_invalid_email_is_definite_and_stops(self):
        state = await self.prepared()
        self.api.request_error = EmailInvalidError()
        with self.assertRaisesRegex(SafeError, "rejected that email"):
            await self.service.send(self.a.key, state["nonce"])
        self.assertEqual(self.state()["stage"], "confirm_send")
        self.assertEqual(len(self.api.requested), 1)
        self.assertEqual(self.api.confirmed, [])

    async def test_not_allowed_email_is_definite_and_stops_on_second_account(self):
        b = self.rt.registry.create()
        api = self.attach(b, 8888)
        await self.service.prepare(b.key, PRIVATE_EMAIL)
        api.request_error = EmailNotAllowedError()
        nonce = self.state(b)["nonce"]
        with self.assertRaisesRegex(SafeError, "rejected that email"):
            await self.service.send(b.key, nonce)
        self.assertEqual(self.state(b)["stage"], "confirm_send")
        self.assertEqual(len(api.requested), 1)
        self.assertEqual(api.confirmed, [])

    async def test_flood_wait_is_saved_and_never_auto_resent(self):
        state = await self.prepared()
        self.api.request_error = FloodWaitError(90)
        with self.assertRaisesRegex(SafeError, "rate-limited"):
            await self.service.send(self.a.key, state["nonce"])
        saved = self.state()
        self.assertGreaterEqual(saved["retry_at"], self.now[0] + 90)
        self.assertEqual(len(self.api.requested), 1)
        self.api.request_error = None
        with self.assertRaisesRegex(SafeError, "retry delay is active"):
            await self.service.send(self.a.key, state["nonce"])

    async def test_uncertain_send_is_not_reported_as_success(self):
        state = await self.prepared()
        self.api.request_error = TimeoutError(PRIVATE)
        with self.assertRaisesRegex(SafeError, "outcome is uncertain"):
            await self.service.send(self.a.key, state["nonce"])
        self.assertEqual(self.state()["stage"], "send_uncertain")
        self.assertEqual(self.state()["new_pattern"], masked_email(PRIVATE_EMAIL))
        self.assertNotIn(CODE, self.raw())

    async def test_send_cooldown_and_hourly_cap(self):
        state = await self.prepared()
        await self.service.send(self.a.key, state["nonce"])
        with self.assertRaisesRegex(SafeError, "two minutes"):
            await self.service.send(self.a.key, state["nonce"], resend=True)
        for _ in range(2):
            self.now[0] += SEND_COOLDOWN + 1
            await self.service.send(self.a.key, state["nonce"], resend=True)
        self.assertEqual(self.state()["window_count"], 3)
        self.now[0] += SEND_COOLDOWN + 1
        with self.assertRaisesRegex(SafeError, "three email-code requests per hour"):
            await self.service.send(self.a.key, state["nonce"], resend=True)
        self.assertEqual(len(self.api.requested), 3)

    async def test_verify_success_confirms_only_on_matching_receipt(self):
        state = await self.prepared()
        await self.service.send(self.a.key, state["nonce"])
        done = await self.service.verify(self.a.key, state["nonce"], CODE)
        self.assertEqual(done["stage"], "completed")
        self.assertEqual(done["encrypted_email"], "")
        self.assertEqual(self.api.confirmed, [(CODE, PRIVATE_EMAIL)])
        data = self.a.store.reload()
        self.assertEqual(email_cache(data)["login_status"], "set")
        self.assertEqual(email_cache(data)["login_pattern"], masked_email(PRIVATE_EMAIL))
        self.assertNotIn(CODE, self.raw())
        self.assertNotIn(PRIVATE_EMAIL, self.raw())

    async def test_unconfirmed_receipt_is_not_success(self):
        state = await self.prepared()
        await self.service.send(self.a.key, state["nonce"])
        self.api.receipt = LoginEmailReceipt(False)
        with self.assertRaisesRegex(SafeError, "matching login-email confirmation"):
            await self.service.verify(self.a.key, state["nonce"], CODE)
        self.assertNotEqual(self.state()["stage"], "completed")

    async def test_wrong_code_keeps_step_with_no_replay_and_attempt_cap(self):
        state = await self.prepared()
        await self.service.send(self.a.key, state["nonce"])
        self.api.verify_error = EmailCodeInvalidError()
        for attempt in range(1, MAX_CODE_ATTEMPTS + 1):
            self.now[0] += 6
            with self.assertRaisesRegex(SafeError, "did not accept the emailed code|retry delay|Wait a few"):
                await self.service.verify(self.a.key, state["nonce"], "BAD" + str(attempt).zfill(3))
            self.assertNotIn("BAD", self.raw())
        self.assertEqual(self.state()["code_attempts"], MAX_CODE_ATTEMPTS)
        self.now[0] += 6
        with self.assertRaisesRegex(SafeError, "Three code attempts"):
            await self.service.verify(self.a.key, state["nonce"], CODE)
        self.assertEqual(len(self.api.confirmed), MAX_CODE_ATTEMPTS)
        self.api.verify_error = None
        with self.assertRaisesRegex(SafeError, "Three code attempts"):
            await self.service.verify(self.a.key, state["nonce"], CODE)

    async def test_expired_verification_clears_destination(self):
        state = await self.prepared()
        await self.service.send(self.a.key, state["nonce"])
        self.api.verify_error = CodeExpiredError()
        with self.assertRaisesRegex(SafeError, "verification expired"):
            await self.service.verify(self.a.key, state["nonce"], CODE)
        self.assertEqual(self.state()["stage"], "expired")
        self.assertEqual(self.state()["encrypted_email"], "")

    async def test_uncertain_verification_is_never_success(self):
        state = await self.prepared()
        await self.service.send(self.a.key, state["nonce"])
        self.api.verify_error = TimeoutError(PRIVATE)
        with self.assertRaisesRegex(SafeError, "outcome is uncertain"):
            await self.service.verify(self.a.key, state["nonce"], CODE)
        self.assertEqual(self.state()["stage"], "verify_uncertain")
        self.assertNotIn(CODE, self.raw())

    async def test_sensitive_password_phase_blocks_mutation_but_not_read(self):
        self.a.store.update(reset_status="waiting", phase="old_removed")
        await self.service.refresh(self.a.key)  # Read-only status stays available.
        with self.assertRaisesRegex(SafeError, "sensitive application phase"):
            await self.service.begin(self.a.key)
        with self.assertRaisesRegex(SafeError, "sensitive application phase"):
            await self.service.prepare(self.a.key, PRIVATE_EMAIL)
        self.assertEqual(self.api.requested, [])
        self.a.store.update(phase="requesting")
        with self.assertRaises(SafeError):
            await self.service.prepare(self.a.key, PRIVATE_EMAIL)

    async def test_cancel_local_keeps_rate_limit_counters_and_clears_destination(self):
        state = await self.prepared()
        await self.service.send(self.a.key, state["nonce"])
        await self.service.cancel_local(self.a.key)
        saved = self.state()
        self.assertEqual(saved["stage"], "cancelled")
        self.assertEqual(saved["encrypted_email"], "")
        self.assertEqual(saved["nonce"], "")
        self.assertEqual(saved["window_count"], 1)
        with self.assertRaises(SafeError):
            await self.service.verify(self.a.key, state["nonce"], CODE)

    async def test_status_failure_is_class_only_and_keeps_last_known(self):
        await self.service.refresh(self.a.key)
        self.api.info_error = TimeoutError(PRIVATE)
        self.now[0] += 10
        with self.assertRaisesRegex(SafeError, "could not be refreshed"):
            await self.service.refresh(self.a.key)
        data = self.a.store.reload()
        cache = email_cache(data)
        self.assertEqual(cache["error"], "TimeoutError")
        self.assertEqual(cache["login_pattern"], masked_email(OLD_PATTERN))
        self.assertGreater(cache["retry_at"], self.now[0])
        self.assertIn("last known", "\n".join(email_lines(data)))
        self.assertNotIn(PRIVATE, self.raw())

    async def test_missing_session_or_mismatched_uid_blocks_email_actions(self):
        self.a.store.update(account_user_id=999999)
        with self.assertRaisesRegex(SafeError, "session ID does not match"):
            await self.service.begin(self.a.key)
        self.a.store.update(account_user_id=7777, session_name="")
        with self.assertRaisesRegex(SafeError, "valid session first"):
            await self.service.begin(self.a.key)
        self.assertEqual(self.api.requested, [])

    async def test_accounts_keep_separate_email_journals(self):
        b = self.rt.registry.create()
        self.attach(b, 8888)
        state_a = await self.prepared()
        saved_a = self.a.store.path.read_text()
        self.assertEqual(change_state(b.store.reload())["stage"], "idle")
        self.assertEqual(change_state(self.controller.reload())["stage"], "idle")
        self.assertEqual(saved_a, self.a.store.path.read_text())
        await self.service.refresh(b.key)
        self.assertEqual(self.a.store.path.read_text(), saved_a)

    async def test_restart_resumes_saved_step_without_resend(self):
        state = await self.prepared()
        await self.service.send(self.a.key, state["nonce"])
        restarted = LoginEmailService(self.rt.registry, self.controller, clock=lambda: self.now[0])
        resumed = await restarted.begin(self.a.key)
        self.assertEqual(resumed["stage"], "awaiting_code")
        self.assertEqual(len(self.api.requested), 1)
        done = await restarted.verify(self.a.key, state["nonce"], CODE)
        self.assertEqual(done["stage"], "completed")

    async def test_screen_shows_masked_status_and_safe_buttons(self):
        cache = await self.service.refresh(self.a.key)
        text, keyboard = email_screen(self.a)
        self.assertIn("Login email: SET", text)
        self.assertIn("2FA recovery email: SET", text)
        self.assertNotIn(PRIVATE_EMAIL, text)
        labels = [b.text for b in buttons(keyboard)]
        self.assertIn("Refresh email status", labels)
        self.assertIn("Change LOGIN email", labels)
        self.assertNotIn("Setup login email", labels)

    async def test_screen_after_not_set_offers_no_change_button(self):
        await self.ready(status="not_set")
        text, keyboard = email_screen(self.a)
        self.assertIn("Login email: NOT SET", text)
        self.assertNotIn("Change LOGIN email", [b.text for b in buttons(keyboard)])
        self.assertIn("official app", text)

    async def test_dashboard_shows_email_status_near_the_top(self):
        await self.service.refresh(self.a.key)
        text, _ = account_screen(self.a, self.now[0])
        lines = text.splitlines()
        joined = "\n".join(lines)
        self.assertIn("Login email: SET", joined)
        self.assertIn("2FA recovery email: SET", joined)
        self.assertLess(joined.index("Login email:"), joined.index("Security alerts:"))
        self.assertNotIn(PRIVATE_EMAIL, joined)

    async def test_screen_shows_retry_and_rate_limit_times(self):
        state = await self.prepared()
        await self.service.send(self.a.key, state["nonce"])
        self.now[0] += SEND_COOLDOWN + 1
        self.api.request_error = FloodWaitError(120)
        with self.assertRaises(SafeError):
            await self.service.send(self.a.key, state["nonce"], resend=True)
        text, _ = email_screen(self.a)
        self.assertIn("Email-change retry allowed after:", text)


class BotFlowTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.controller = Store(self.root)
        self.controller.update(owner_id=1234, api_id=12345, api_hash="a" * 32)
        self.rt = bot.Runtime(self.controller)
        self.a = self.rt.current
        self.ctx = context(self.rt)
        self.api = EmailAdapter()
        self.a.store.update(account_user_id=7777, detected_user_id=7777, registered=True,
                            owner_phone="+911234567890", owner_ui_state={},
                            session_name="sessions/fake.session", library="telethon")
        self.a.sessions.me = NS(id=7777)
        self.a.sessions.ensure = AsyncMock(return_value=self.api)

    async def asyncTearDown(self):
        await self.rt.registry.close()
        self.temp.cleanup()

    async def test_email_screen_callback_is_profile_bound(self):
        upd = update(action=f"acct:{self.a.key}:email")
        await bot.callback(upd, self.ctx)
        self.assertIn("LOGIN EMAIL", edits_of(upd)[0])
        upd = update(action="acct:doesnotexist:email")
        with self.assertRaises(SafeError):
            await bot.callback(upd, self.ctx)

    async def test_unauthorized_user_cannot_open_email(self):
        upd = update(uid=999, action=f"acct:{self.a.key}:email")
        await bot.callback(upd, self.ctx)
        upd.callback_query.answer.assert_awaited()
        self.assertEqual(upd.callback_query.answer.await_args.args[0], "Access denied.")
        self.assertFalse(upd.callback_query.edit_message_text.await_args_list)

    async def test_not_set_account_gets_no_guided_input_prompt(self):
        self.api.info_result = PasswordInfo(True, True, "", 0, "", True, False)
        upd = update(action=f"acct:{self.a.key}:emailchange")
        with self.assertRaisesRegex(SafeError, "NO login email"):
            await bot.callback(upd, self.ctx)
        self.assertEqual(self.api.requested, [])
        self.assertNotIn("flow", self.ctx.user_data)

    async def test_guided_email_then_confirmation_then_code(self):
        upd = update(action=f"acct:{self.a.key}:emailchange")
        await bot.callback(upd, self.ctx)
        self.assertEqual(self.ctx.user_data["flow"], "email_new")
        self.assertIn("NEW login email", text_of(upd))
        self.assertEqual(self.api.requested, [])

        typed = update()
        typed.effective_message.text = PRIVATE_EMAIL
        await bot.text_input(typed, self.ctx)
        self.assertEqual(self.ctx.user_data["flow"], "email_confirm")
        card = text_of(typed)
        self.assertIn("CONFIRM LOGIN-EMAIL CHANGE", card)
        self.assertNotIn(PRIVATE_EMAIL, card)
        nonce = self.ctx.user_data["email_nonce"]
        self.assertEqual(self.api.requested, [])  # Still nothing sent.

        await bot.callback(update(action="emailsend:" + nonce), self.ctx)
        self.assertEqual(self.ctx.user_data["flow"], "email_code")
        self.assertEqual(self.api.requested, [PRIVATE_EMAIL])
        self.assertEqual(len(self.api.confirmed), 0)

        coded = update()
        coded.effective_message.text = CODE
        await bot.text_input(coded, self.ctx)
        self.assertIn("LOGIN EMAIL UPDATED", text_of(coded))
        self.assertNotIn("flow", self.ctx.user_data)
        self.assertEqual(self.api.confirmed, [(CODE, PRIVATE_EMAIL)])
        self.assertNotIn(CODE, (self.root / "accounts").joinpath(self.a.key).joinpath("profile.json").read_text()
                         if (self.root / "accounts" / self.a.key / "profile.json").exists() else self.a.store.path.read_text())

    async def test_wrong_nonce_callback_is_rejected_before_any_rpc(self):
        await bot.callback(update(action=f"acct:{self.a.key}:emailchange"), self.ctx)
        typed = update()
        typed.effective_message.text = PRIVATE_EMAIL
        await bot.text_input(typed, self.ctx)
        with self.assertRaisesRegex(SafeError, "expired or belongs"):
            await bot.callback(update(action="emailsend:" + "f" * 16), self.ctx)
        self.assertEqual(self.api.requested, [])

    async def test_stale_or_switched_profile_input_is_rejected(self):
        await bot.callback(update(action=f"acct:{self.a.key}:emailchange"), self.ctx)
        b = self.rt.registry.create()
        self.rt.registry.select(b.key)
        typed = update()
        typed.effective_message.text = PRIVATE_EMAIL
        await bot.text_input(typed, self.ctx)
        self.assertIn("Email input expired or the selected account changed", text_of(typed))
        self.assertEqual(self.api.requested, [])

    async def test_email_flow_ignores_session_documents(self):
        await bot.callback(update(action=f"acct:{self.a.key}:emailchange"), self.ctx)
        doc = update()
        doc.effective_message.document = NS(file_size=1024, get_file=AsyncMock())
        await bot.document_input(doc, self.ctx)
        self.assertIn("email step is open", text_of(doc))
        doc.effective_message.document.get_file.assert_not_awaited()

    async def test_email_command_is_registered_and_help_mentions_separation(self):
        app = NS(bot=NS(get_webhook_info=AsyncMock(return_value=NS(url="")),
                       set_my_commands=AsyncMock()))
        async def forever(*args, **kwargs):
            await asyncio.sleep(3600)
        import contextlib
        with contextlib.suppress(Exception):
            with unittest.mock.patch.object(self.rt, "worker", side_effect=forever), \
                 unittest.mock.patch.object(self.rt.security, "worker", side_effect=forever), \
                 unittest.mock.patch.object(self.rt.guard, "worker", side_effect=forever), \
                 unittest.mock.patch.object(self.rt.email, "refresh_all", side_effect=forever):
                await bot.on_startup(app)
                await asyncio.sleep(0)
                commands = [c.command for c in app.bot.set_my_commands.await_args.args[0]]
                self.assertIn("email", commands)
                await bot.on_stop(app)
        self.assertIn("NOT the 2FA recovery email", bot.HELP)
        self.assertIn("/email", bot.HELP)
        self.assertLessEqual(len(bot.HELP), 3500)  # Must fit one guided English screen.
        self.assertEqual(bot.VERSION, "2.18")


class AdapterTests(unittest.IsolatedAsyncioTestCase):
    async def test_telethon_info_exposes_masked_pattern_and_recovery_flag(self):
        adapter = TelethonAdapter()
        adapter.client = AsyncMock(return_value=NS(has_password=True, has_recovery=False, hint="",
                                                   pending_reset_date=0, login_email_pattern=OLD_PATTERN,
                                                   email_unconfirmed_pattern=None))
        info = await adapter.info()
        self.assertEqual(type(adapter.client.await_args.args[0]).__name__, "GetPasswordRequest")
        self.assertEqual(info.login_email_pattern, OLD_PATTERN)
        self.assertTrue(info.login_email_supported)
        self.assertFalse(info.recovery_email_unconfirmed)

    async def test_telethon_send_and_verify_use_login_change_purpose_only(self):
        from telethon.tl import types
        adapter = TelethonAdapter()
        adapter.client = AsyncMock(return_value=types.account.SentEmailCode(email_pattern="n***@e***.com", length=6))
        code = await adapter.request_login_email_code(PRIVATE_EMAIL)
        request = adapter.client.await_args.args[0]
        self.assertEqual(type(request).__name__, "SendVerifyEmailCodeRequest")
        self.assertEqual(type(request.purpose).__name__, "EmailVerifyPurposeLoginChange")
        self.assertEqual(request.email, PRIVATE_EMAIL)
        self.assertEqual((code.pattern, code.length), ("n***@e***.com", 6))
        adapter.client = AsyncMock(return_value=types.account.EmailVerified(email=PRIVATE_EMAIL))
        receipt = await adapter.confirm_login_email_code(CODE, PRIVATE_EMAIL)
        request = adapter.client.await_args.args[0]
        self.assertEqual(type(request).__name__, "VerifyEmailRequest")
        self.assertEqual(type(request.purpose).__name__, "EmailVerifyPurposeLoginChange")
        self.assertEqual(type(request.verification).__name__, "EmailVerificationCode")
        self.assertEqual(request.verification.code, CODE)
        self.assertTrue(receipt.confirmed)

    async def test_pyrogram_send_and_verify_use_login_change_purpose_only(self):
        from pyrogram import raw
        adapter = PyrogramAdapter()
        adapter.client = NS(invoke=AsyncMock(return_value=raw.types.account.SentEmailCode(email_pattern="n***@e***.com", length=6)))
        await adapter.request_login_email_code(PRIVATE_EMAIL)
        request = adapter.client.invoke.await_args.args[0]
        self.assertEqual(type(request).__name__, "SendVerifyEmailCode")
        self.assertEqual(type(request.purpose).__name__, "EmailVerifyPurposeLoginChange")
        adapter.client = NS(invoke=AsyncMock(return_value=raw.types.account.EmailVerified(email=PRIVATE_EMAIL)))
        receipt = await adapter.confirm_login_email_code(CODE, PRIVATE_EMAIL)
        request = adapter.client.invoke.await_args.args[0]
        self.assertEqual(type(request).__name__, "VerifyEmail")
        self.assertEqual(type(request.purpose).__name__, "EmailVerifyPurposeLoginChange")
        self.assertEqual(type(request.verification).__name__, "EmailVerificationCode")
        self.assertTrue(receipt.confirmed)

    async def test_unexpected_rpc_shapes_are_never_treated_as_success(self):
        tele = TelethonAdapter()
        tele.client = AsyncMock(return_value=NS(length=6))
        with self.assertRaisesRegex(SafeError, "expected login-email code response"):
            await tele.request_login_email_code(PRIVATE_EMAIL)
        tele.client = AsyncMock(return_value=NS(email=PRIVATE_EMAIL))
        with self.assertRaisesRegex(SafeError, "expected login-email confirmation"):
            await tele.confirm_login_email_code(CODE, PRIVATE_EMAIL)
        pyro = PyrogramAdapter()
        pyro.client = NS(invoke=AsyncMock(return_value=NS(length=6)))
        with self.assertRaisesRegex(SafeError, "expected login-email code response"):
            await pyro.request_login_email_code(PRIVATE_EMAIL)

    def test_feature_exposes_no_destructive_telegram_methods(self):
        source = Path(login_email.__file__).read_text()
        for forbidden in ("reset_authorization", "ResetAuthorization", "resetLoginEmail", "log_out", "LogOut",
                          "edit_2fa", "Edit2FA", "enable_cloud_password", "reset_password", "ResetPassword",
                          "change_phone", "send_code_request", "SendCodeRequest", "DeleteAccount",
                          "emailVerifyPurposeLoginSetup"):
            self.assertNotIn(forbidden, source)

    def test_old_v25_profile_gains_email_keys_without_losing_state(self):
        import json as jsonlib
        from accounts import AccountRegistry
        from storage import Store
        tmp = Path(tempfile.mkdtemp())
        reg = AccountRegistry(Store(tmp))
        a = reg.get()
        a.store.update(account_user_id=7777, registered=True, owner_phone="+911234567890",
                       reset_status="waiting", reset_until_date=1800000000,
                       pending_new_password="fernet:cipher", protection_lock_enabled=True)
        data = jsonlib.loads(a.store.path.read_text())
        for key in ("email_info", "login_email_change"):
            data.pop(key, None)
        a.store.path.write_text(jsonlib.dumps(data))
        fresh = AccountRegistry(Store(tmp))
        b = fresh.get(a.key)
        self.assertEqual(b.store.data["account_user_id"], 7777)
        self.assertEqual(b.store.data["reset_until_date"], 1800000000)
        self.assertEqual(b.store.data["pending_new_password"], "fernet:cipher")
        self.assertTrue(b.store.data["protection_lock_enabled"])
        self.assertEqual(b.store.data["email_info"], {})
        self.assertEqual(change_state(b.store.reload())["stage"], "idle")

    def test_stale_cached_status_is_marked_last_known(self):
        lines = email_lines({CACHE_KEY: {"checked_at": 1, "login_status": "set", "login_pattern": OLD_PATTERN}})
        self.assertIn("last known; refresh needed", lines[0])

    def test_defaults_keep_email_keys_without_secrets(self):
        from storage import DEFAULTS
        self.assertEqual(DEFAULTS["email_info"], {})
        self.assertEqual(DEFAULTS["login_email_change"], {})


if __name__ == "__main__":
    unittest.main()
