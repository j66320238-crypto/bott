"""Synthetic/offline protection tests. Never create a real login or revoke one."""
import asyncio
import contextlib
import dataclasses
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock, patch

import bot
from accounts import ACCOUNT_FIELDS
from login_guard import (LOCK_KEY, GEN_KEY, STATE_KEY, LoginSession, LoginGuard,
                         checked_snapshot, guard_state, guard_status, hash_key, protection_screen)
from sessions import TelethonAdapter, PyrogramAdapter
from storage import SafeError, Store

PRIVATE = "PRIVATE-CONTENT 943816 https://example.invalid/login 203.0.113.42 device-secret"
OLD, NEW = 6044665349333333311, -6044665349333333312


class Authorizations:
    def __init__(self, now):
        self.sessions = [LoginSession(0, now - 200000, True), LoginSession(OLD, now - 100000)]
        self.read_error = None
        self.action_error = None
        self.result = True
        self.remove = True
        self.on_read = None
        self.reads = 0
        self.requests = []
        self.authorizations = AsyncMock(side_effect=self.read)
        self.terminate_session = AsyncMock(side_effect=self.terminate)

    async def read(self):
        self.reads += 1
        if self.on_read: await self.on_read(self.reads)
        if self.read_error: raise self.read_error
        return list(self.sessions)

    async def terminate(self, value):
        self.requests.append(value)
        if self.action_error: raise self.action_error
        if self.result is True and self.remove:
            self.sessions = [s for s in self.sessions if s.authorization_hash != value]
        return self.result


def event(uid=1234, kind="private", action=None):
    return NS(effective_user=NS(id=uid), effective_chat=NS(type=kind),
              effective_message=NS(reply_text=AsyncMock(), delete=AsyncMock()),
              callback_query=NS(data=action, answer=AsyncMock(), edit_message_text=AsyncMock()) if action else None)


def context(rt):
    return NS(application=NS(bot_data={"runtime": rt}, bot=NS(send_message=AsyncMock())), user_data={})


def buttons(keyboard):
    return [b for row in keyboard.inline_keyboard for b in row]


class GuardMetadataTests(unittest.TestCase):
    def test_zero_boolean_noncanonical_and_out_of_range_hashes_rejected(self):
        for value in (0, "0", True, "001", "+1", PRIVATE, 2**63, -(2**63)-1):
            with self.subTest(value=value), self.assertRaises(SafeError): hash_key(value)

    def test_negative_tl_long_is_supported(self):
        self.assertEqual(hash_key(NEW), str(NEW))

    def test_snapshot_requires_exactly_one_current_authorization(self):
        for value in ([], [LoginSession(OLD, 1)], [LoginSession(0, 1, True), LoginSession(OLD, 1, True)]):
            with self.subTest(value=value), self.assertRaises(SafeError): checked_snapshot(value)

    def test_snapshot_rejects_duplicate_other_hashes(self):
        with self.assertRaises(SafeError): checked_snapshot([LoginSession(0, 1, True), LoginSession(OLD, 1), LoginSession(OLD, 1)])

    def test_zero_is_allowed_only_for_current_session(self):
        with self.assertRaises(SafeError): checked_snapshot([LoginSession(OLD, 1, True), LoginSession(0, 1)])
        self.assertEqual(checked_snapshot([LoginSession(0, 1, True)])[0], {})

    def test_snapshot_rejects_boolean_hash_and_invalid_created_date(self):
        for session in (LoginSession(False, 1, True), LoginSession(OLD, -1), LoginSession(OLD, True)):
            with self.subTest(session=session), self.assertRaises(SafeError): checked_snapshot([LoginSession(0, 1, True), session])

    def test_event_discards_all_device_ip_and_text_fields(self):
        self.assertEqual({x.name for x in dataclasses.fields(LoginSession)}, {"authorization_hash", "created_at", "current"})

    def test_guard_state_rejects_raw_body_ip_and_links(self):
        for field in ("text", "body", "code", "url", "ip", "device", "auth_key"):
            with self.subTest(field=field), self.assertRaises(SafeError): guard_state({STATE_KEY: {field: PRIVATE}})

    def test_guard_outbox_accepts_only_numeric_fixed_counters(self):
        with self.assertRaises(SafeError): guard_state({STATE_KEY: {"outbox": {"new": PRIVATE}}})
        with self.assertRaises(SafeError): guard_state({STATE_KEY: {"outbox": {"body": PRIVATE}}})

    def test_error_text_cannot_enter_guard_state(self):
        with self.assertRaises(SafeError): guard_state({STATE_KEY: {"error": PRIVATE}})

    def test_invalid_lock_flag_never_shows_active(self):
        self.assertIn("PAUSED", guard_status({LOCK_KEY: "on"}))
        self.assertIn("not enforcing", guard_status({}))


class GuardTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.controller = Store(self.root)
        self.controller.update(owner_id=1234, api_id=12345, api_hash="a" * 32)
        self.rt = bot.Runtime(self.controller)
        self.a = self.rt.current
        self.now = [1800000000]
        self.api = self.attach(self.a, 7777)
        self.guard = LoginGuard(self.rt.registry, self.controller, clock=lambda: self.now[0])
        self.app = NS(bot=NS(send_message=AsyncMock()))

    def attach(self, account, uid):
        account.store.update(account_user_id=uid, detected_user_id=uid, registered=True,
                             owner_phone="+911234567890", detected_phone="+911234567890",
                             session_name="sessions/fake.session", library="telethon")
        api = Authorizations(self.now[0])
        account.sessions.me = NS(id=uid)
        account.sessions.ensure = AsyncMock(return_value=api)
        return api

    async def asyncTearDown(self):
        await self.rt.registry.close()
        self.temp.cleanup()

    def state(self, account=None): return guard_state((account or self.a).store.reload())

    async def baseline(self):
        await self.guard.poll_account(self.a)
        self.now[0] += 2

    def add(self, value=NEW, *, created=None, current=False):
        self.api.sessions.append(LoginSession(value, self.now[0] if created is None else created, current))

    async def test_existing_and_future_accounts_default_lock_on(self):
        self.assertTrue(self.a.store.reload()[LOCK_KEY])
        self.assertTrue(self.rt.registry.create().store.reload()[LOCK_KEY])
        self.assertTrue(self.controller.reload()["security_alerts_enabled"])

    async def test_first_baseline_trusts_every_existing_session_without_revocation(self):
        self.add()
        await self.baseline()
        self.assertTrue(self.state()["initialized"])
        self.assertEqual(set(self.state()["trusted"]), {str(OLD), str(NEW)})
        self.assertEqual(self.api.requests, [])
        self.assertEqual(self.state()["outbox"], {})

    async def test_current_session_is_never_terminated(self):
        await self.baseline()
        await self.guard.poll_account(self.a)
        self.assertNotIn(0, self.api.requests)
        self.assertEqual(self.state()["total_termination_attempts"], 0)

    async def test_current_nonzero_hash_is_also_protected(self):
        self.api.sessions = [LoginSession(OLD, self.now[0] - 200000, True)]
        await self.baseline()
        await self.guard.poll_account(self.a)
        self.assertEqual(self.api.requests, [])

    async def test_new_non_current_session_revoked_then_absence_confirmed(self):
        await self.baseline()
        self.add()
        await self.guard.poll_account(self.a)
        self.assertEqual(self.api.requests, [NEW])
        self.assertEqual(self.state()["outbox"]["new"], 1)
        self.assertEqual(self.state()["outbox"]["revoked"], 1)
        self.assertFalse(self.state()["candidates"])
        self.assertEqual(self.state()["total_terminations_confirmed"], 1)
        self.assertIn(LoginSession(OLD, self.now[0] - 100002), self.api.sessions)

    async def test_discovery_and_intent_saved_before_termination_rpc(self):
        await self.baseline()
        self.add()
        original = self.api.terminate
        async def inspect_intent(value):
            state = json.loads(self.a.store.path.read_text())[STATE_KEY]
            self.assertIn(str(NEW), state["candidates"])
            self.assertEqual(state["outbox"]["new"], 1)
            self.assertEqual(state["total_termination_attempts"], 1)
            return await original(value)
        self.api.terminate_session.side_effect = inspect_intent
        await self.guard.poll_account(self.a)
        self.assertEqual(self.api.requests, [NEW])

    async def test_old_unknown_session_alerted_but_not_revoked(self):
        await self.baseline()
        self.add(created=self.now[0] - 10000)
        await self.guard.poll_account(self.a)
        self.assertEqual(self.api.requests, [])
        self.assertEqual(self.state()["outbox"]["uncertain"], 1)

    async def test_missing_creation_date_never_auto_revoked(self):
        await self.baseline()
        self.add(created=0)
        await self.guard.poll_account(self.a)
        self.assertEqual(self.api.requests, [])

    async def test_lock_off_keeps_login_alerts_without_revoking(self):
        await self.baseline()
        await self.guard.set_lock(self.a.key, False)
        self.add()
        await self.guard.poll_account(self.a)
        self.assertEqual(self.api.requests, [])
        self.assertEqual(self.state()["outbox"]["new"], 1)
        self.assertEqual(self.state()["outbox"]["allowed"], 1)
        self.assertEqual(guard_status(self.a.store.reload()), "OFF")

    async def test_lock_off_is_immediate_even_while_account_operation_lock_is_busy(self):
        async with self.a.engine.lock:
            await asyncio.wait_for(self.guard.set_lock(self.a.key, False), 0.2)
        self.assertFalse(self.a.store.reload()[LOCK_KEY])

    async def test_lock_off_persists_over_full_runtime_restart(self):
        await self.guard.set_lock(self.a.key, False)
        restarted = bot.Runtime(Store(self.root))
        try: self.assertFalse(restarted.registry.get(self.a.key).store.reload()[LOCK_KEY])
        finally: await restarted.registry.close()

    async def test_reenable_trusts_currently_active_sessions_and_arms_for_future_ones(self):
        await self.baseline()
        await self.guard.set_lock(self.a.key, False)
        self.add()
        await self.guard.set_lock(self.a.key, True)
        self.assertIn(str(NEW), self.state()["trusted"])
        self.add(555)
        await self.guard.poll_account(self.a)
        self.assertEqual(self.api.requests, [555])

    async def test_repeated_on_does_not_rebaseline_an_intruder(self):
        await self.baseline()
        self.add()
        await self.guard.set_lock(self.a.key, True)
        self.assertNotIn(str(NEW), self.state()["trusted"])
        await self.guard.poll_account(self.a)
        self.assertEqual(self.api.requests, [NEW])

    async def test_off_during_arming_cannot_be_overwritten_by_slow_on(self):
        await self.guard.set_lock(self.a.key, False)
        async def off(_): await self.guard.set_lock(self.a.key, False)
        self.api.on_read = off
        with self.assertRaises(SafeError): await self.guard.set_lock(self.a.key, True)
        self.assertFalse(self.a.store.reload()[LOCK_KEY])
        self.assertEqual(self.api.requests, [])

    async def test_off_during_final_revalidation_prevents_rpc(self):
        await self.baseline()
        self.add()
        start = self.api.reads
        async def off_at_second(number):
            if number == start + 2: await self.guard.set_lock(self.a.key, False)
        self.api.on_read = off_at_second
        await self.guard.poll_account(self.a)
        self.assertEqual(self.api.requests, [])
        self.assertFalse(self.a.store.reload()[LOCK_KEY])

    async def test_alerts_off_does_not_disable_lock_or_relay_pending_notices(self):
        await self.baseline()
        self.controller.update(security_alerts_enabled=False)
        self.add()
        await self.guard.poll_account(self.a)
        await self.guard.flush_all(self.app)
        self.assertEqual(self.api.requests, [NEW])
        self.app.bot.send_message.assert_not_awaited()
        self.assertEqual(self.state()["total_new"], 1)

    async def test_new_login_while_offline_caught_on_resume(self):
        await self.baseline()
        self.now[0] += 86400
        self.add(created=self.now[0] - 3600)
        await self.guard.poll_account(self.a)
        self.assertEqual(self.api.requests, [NEW])

    async def test_lock_does_not_expire_after_seven_days(self):
        await self.baseline()
        self.now[0] += 10 * 86400
        self.add()
        await self.guard.poll_account(self.a)
        self.assertEqual(self.api.requests, [NEW])
        self.assertTrue(self.a.store.reload()[LOCK_KEY])

    async def test_normal_repeat_polls_do_not_revoke_or_notify_twice(self):
        await self.baseline()
        self.add()
        await self.guard.poll_account(self.a)
        await self.guard.flush_all(self.app)
        await self.guard.poll_account(self.a)
        await self.guard.flush_all(self.app)
        self.assertEqual(self.api.requests, [NEW])
        self.app.bot.send_message.assert_awaited_once()

    async def test_restart_keeps_pending_accepted_revocation_not_trusted_baseline(self):
        await self.baseline()
        self.api.remove = False
        self.add()
        await self.guard.poll_account(self.a)
        restarted = LoginGuard(self.rt.registry, self.controller, clock=lambda: self.now[0])
        self.api.sessions = [s for s in self.api.sessions if s.authorization_hash != NEW]
        await restarted.poll_account(self.a)
        self.assertEqual(self.state()["outbox"]["revoked"], 1)
        self.assertNotIn(str(NEW), self.state()["trusted"])
        self.assertEqual(self.api.requests, [NEW])

    async def test_false_result_never_claims_success(self):
        await self.baseline()
        self.api.result = False
        self.add()
        await self.guard.poll_account(self.a)
        self.assertFalse(self.state()["candidates"][str(NEW)]["accepted"])
        self.assertEqual(self.state()["outbox"].get("revoked", 0), 0)
        await self.guard.flush_all(self.app)
        self.assertNotIn("termination confirmed", self.app.bot.send_message.await_args.args[1])

    async def test_accepted_but_still_active_is_reported_as_pending_not_confirmed(self):
        await self.baseline()
        self.api.remove = False
        self.add()
        await self.guard.poll_account(self.a)
        self.assertEqual(self.state()["outbox"]["accepted"], 1)
        self.assertEqual(self.state()["outbox"].get("revoked", 0), 0)
        await self.guard.flush_all(self.app)
        self.assertIn("inactivity not yet confirmed", self.app.bot.send_message.await_args.args[1])

    async def test_ambiguous_timeout_then_absence_is_not_called_confirmed_revocation(self):
        await self.baseline()
        self.add()
        async def timeout_after_send(value):
            self.api.sessions = [s for s in self.api.sessions if s.authorization_hash != value]
            raise TimeoutError(PRIVATE)
        self.api.terminate_session.side_effect = timeout_after_send
        await self.guard.poll_account(self.a)
        self.now[0] += 61
        await self.guard.poll_account(self.a)
        self.assertEqual(self.state()["outbox"].get("revoked", 0), 0)
        self.assertEqual(self.state()["outbox"]["gone"], 1)

    async def test_flood_wait_pauses_this_account_without_bypassing(self):
        await self.baseline()
        self.add()
        FloodWaitError = type("FloodWaitError", (Exception,), {})
        error = FloodWaitError(PRIVATE); error.seconds = 500
        self.api.action_error = error
        await self.guard.poll_account(self.a)
        self.assertEqual(self.state()["retry_at"], self.now[0] + 501)
        count = self.api.reads
        await self.guard.poll_account(self.a)
        self.assertEqual(self.api.reads, count)

    async def test_fresh_authorization_restriction_waits_instead_of_bypassing(self):
        self.api.sessions[0] = LoginSession(0, self.now[0] - 1000, True)
        await self.baseline()
        self.add()
        self.api.action_error = type("FreshResetAuthorisationForbiddenError", (Exception,), {})(PRIVATE)
        await self.guard.poll_account(self.a)
        self.assertGreater(self.state()["retry_at"], self.now[0] + 80000)

    async def test_wrong_uid_never_reads_or_terminates_authorizations(self):
        self.a.sessions.me = NS(id=9999)
        await self.guard.poll_account(self.a)
        self.api.authorizations.assert_not_awaited()
        self.assertEqual(self.api.requests, [])

    async def test_changed_profile_uid_cannot_inherit_old_protection_baseline(self):
        await self.baseline()
        self.a.store.update(account_user_id=8888, detected_user_id=8888)
        self.a.sessions.me = NS(id=8888)
        self.add()
        await self.guard.poll_account(self.a)
        self.assertEqual(self.api.requests, [])
        self.assertEqual(self.state()["error"], "SafeError")

    async def test_unverified_valid_import_can_be_protected_without_questionnaire(self):
        self.a.store.update(account_user_id=0, registered=False, owner_phone="")
        await self.baseline()
        self.add()
        await self.guard.poll_account(self.a)
        self.assertEqual(self.api.requests, [NEW])
        self.assertFalse(self.a.store.reload()["registered"])

    async def test_empty_profile_never_connects(self):
        self.a.store.update(account_user_id=0, detected_user_id=0, session_name="")
        await self.guard.poll_account(self.a)
        self.a.sessions.ensure.assert_not_awaited()

    async def test_read_errors_log_and_store_class_only(self):
        self.api.read_error = RuntimeError(PRIVATE)
        with self.assertLogs("login_guard", level="WARNING") as logs: await self.guard.poll_account(self.a)
        combined = str(logs.output) + self.a.store.path.read_text()
        for secret in (PRIVATE, "943816", "203.0.113.42", "device-secret"): self.assertNotIn(secret, combined)
        self.assertEqual(self.state()["error"], "RuntimeError")

    async def test_owner_notice_contains_account_time_and_fixed_categories_only(self):
        await self.baseline()
        self.add()
        await self.guard.poll_account(self.a)
        await self.guard.flush_all(self.app)
        args = self.app.bot.send_message.await_args
        self.assertEqual(args.args[0], 1234)
        text = args.args[1]
        for wanted in ("New login/session detected", "termination confirmed", "ID 7777", "IST"): self.assertIn(wanted, text)
        for forbidden in (str(NEW), PRIVATE, "943816", "203.0.113.42", "device-secret"): self.assertNotIn(forbidden, text)
        self.assertIn(f"acct:{self.a.key}:guard", [b.callback_data for b in buttons(args.kwargs["reply_markup"])])

    async def test_delivery_failure_retains_outbox_and_does_not_pause_guard_actions(self):
        await self.baseline()
        self.add()
        await self.guard.poll_account(self.a)
        self.app.bot.send_message.side_effect = TimeoutError(PRIVATE)
        await self.guard.flush_all(self.app)
        self.assertTrue(self.state()["outbox"])
        self.add(444)
        await self.guard.poll_account(self.a)
        self.assertEqual(self.api.requests, [NEW, 444])
        self.now[0] += 61
        self.app.bot.send_message.side_effect = None
        await self.guard.flush_all(self.app)
        self.assertFalse(self.state()["outbox"])

    async def test_state_corruption_isolated_from_another_account(self):
        b = self.rt.registry.create(); self.attach(b, 8888)
        self.a.store.update(**{STATE_KEY: {"invalid": PRIVATE}})
        await self.guard.poll_all()
        self.assertTrue(self.state(b)["initialized"])

    async def test_recovery_job_password_deadlines_and_other_account_unchanged(self):
        self.a.store.update(reset_status="waiting", phase="waiting", reset_until_date=self.now[0] + 600000,
                             next_attempt_at=self.now[0] + 600000, pending_new_password="cipher-to-keep", pending_hint="hint-to-keep")
        b = self.rt.registry.create(); self.attach(b, 8888)
        other = b.store.path.read_bytes()
        fields = [k for k in ACCOUNT_FIELDS if k not in (LOCK_KEY, GEN_KEY, STATE_KEY)]
        before = {k: self.a.store.reload()[k] for k in fields}
        await self.baseline(); self.add()
        await self.guard.poll_account(self.a)
        await self.guard.set_lock(self.a.key, False)
        self.assertEqual({k: self.a.store.reload()[k] for k in fields}, before)
        self.assertEqual(b.store.path.read_bytes(), other)

    async def test_trusted_session_temporarily_missing_then_reappearing_not_revoked(self):
        await self.baseline()
        old = self.api.sessions.pop()
        await self.guard.poll_account(self.a)
        self.api.sessions.append(old)
        await self.guard.poll_account(self.a)
        self.assertEqual(self.api.requests, [])

    async def test_mismatched_creation_date_at_last_check_prevents_revocation(self):
        await self.baseline(); self.add()
        start = self.api.reads
        async def change(number):
            if number == start + 2:
                self.api.sessions = [LoginSession(s.authorization_hash, s.created_at - 1000, s.current) if s.authorization_hash == NEW else s for s in self.api.sessions]
        self.api.on_read = change
        await self.guard.poll_account(self.a)
        self.assertEqual(self.api.requests, [])

    async def test_current_session_flag_changed_at_last_check_is_protected(self):
        await self.baseline(); self.add()
        start = self.api.reads
        async def change(number):
            if number == start + 2: self.api.sessions = [LoginSession(NEW, self.now[0], True), LoginSession(OLD, self.now[0]-100000)]
        self.api.on_read = change
        await self.guard.poll_account(self.a)
        self.assertEqual(self.api.requests, [])

    async def test_max_three_new_sessions_terminated_per_tick_without_blanket_reset(self):
        await self.baseline()
        for value in range(100, 105): self.add(value)
        await self.guard.poll_account(self.a)
        self.assertEqual(len(self.api.requests), 3)
        self.assertEqual(len(self.state()["candidates"]), 2)
        self.assertNotIn(OLD, self.api.requests)

    async def test_already_gone_candidates_do_not_break_remaining_loop(self):
        await self.baseline()
        self.add(); self.add(555)
        start = self.api.reads
        async def disappear(number):
            if number == start + 2: self.api.sessions = self.api.sessions[:2]
        self.api.on_read = disappear
        await self.guard.poll_account(self.a)
        self.assertEqual(self.api.requests, [])
        self.assertFalse(self.state()["candidates"])
        self.assertEqual(self.state()["error"], "")

    async def test_cancellation_propagates_without_raw_error_persistence(self):
        self.api.read_error = asyncio.CancelledError()
        with self.assertRaises(asyncio.CancelledError): await self.guard.poll_account(self.a)
        self.assertEqual(self.state()["error"], "")

    async def test_slow_account_does_not_block_another_worker(self):
        b = self.rt.registry.create(); self.attach(b, 8888)
        healthy, blocked = asyncio.Event(), asyncio.Event()
        async def flush(account, app):
            if account.key == self.a.key: await blocked.wait()
            else: healthy.set()
        # Idle workers skip the timer poll; the always-on flush proves isolation.
        with patch.object(self.guard, "poll_account", AsyncMock()), \
             patch.object(self.guard, "flush_account", side_effect=flush):
            task = asyncio.create_task(self.guard.worker(self.app))
            try: await asyncio.wait_for(healthy.wait(), 1)
            finally:
                task.cancel()
                with contextlib.suppress(asyncio.CancelledError): await task
        self.assertFalse(any(t.get_name()=="login-protection-account" and not t.done() for t in asyncio.all_tasks()))

    async def test_protection_screen_is_read_only_and_buttons_account_bound(self):
        before = self.a.store.path.read_bytes()
        text, keyboard = protection_screen(self.rt.registry, self.controller, key=self.a.key)
        self.assertIn("NOT a pre-login block", text)
        self.assertIn("OWN new login", text)
        self.assertIn(f"acct:{self.a.key}:guard_off", [b.callback_data for b in buttons(keyboard)])
        self.a.sessions.ensure.assert_not_awaited()
        self.assertEqual(self.a.store.path.read_bytes(), before)

    async def test_owner_private_only_commands_and_callbacks(self):
        for command in (bot.protection_command, bot.lock_command, bot.unlock_command):
            for args in ({"uid":9999},{"kind":"group"}):
                update = event(**args); await command(update, context(self.rt))
                self.assertEqual(update.effective_message.reply_text.await_args.args[0], "Access denied.")
        update = event(uid=9999, action=f"acct:{self.a.key}:guard_off")
        await bot.callback(update, context(self.rt))
        self.assertTrue(self.a.store.reload()[LOCK_KEY])
        update.callback_query.answer.assert_awaited_once_with("Access denied.", show_alert=True)

    async def test_old_callback_unlocks_only_named_account_not_current_selection(self):
        b=self.rt.registry.create();self.attach(b,8888)
        await bot.callback(event(action=f"acct:{self.a.key}:guard_off"), context(self.rt))
        self.assertFalse(self.a.store.reload()[LOCK_KEY]);self.assertTrue(b.store.reload()[LOCK_KEY])
        self.assertEqual(self.rt.registry.active_key,b.key)

    async def test_removed_account_callback_fails_closed(self):
        b=self.rt.registry.create();key=b.key;await self.rt.registry.remove(key)
        with self.assertRaises(SafeError): await bot.callback(event(action=f"acct:{key}:guard_off"),context(self.rt))
        self.assertTrue(self.a.store.reload()[LOCK_KEY])

    async def test_protection_settings_are_paginated(self):
        for _ in range(6):self.rt.registry.create()
        text,keyboard=protection_screen(self.rt.registry,self.controller)
        self.assertLess(len(text),3500)
        self.assertIn('protection:page:1',[b.callback_data for b in buttons(keyboard)])

    async def test_unlock_command_requires_no_session_rpc_or_password(self):
        await bot.unlock_command(event(),context(self.rt))
        self.assertFalse(self.a.store.reload()[LOCK_KEY])
        self.a.sessions.ensure.assert_not_awaited()

    async def test_reenable_does_not_bypass_a_saved_flood_wait(self):
        await self.baseline()
        state=self.state();state['retry_at']=self.now[0]+1000;state['error']='FloodWaitError'
        self.a.store.update(**{STATE_KEY:state})
        await self.guard.set_lock(self.a.key,False)
        reads=self.api.reads
        with self.assertRaises(SafeError):await self.guard.set_lock(self.a.key,True)
        self.assertEqual(self.api.reads,reads)
        self.assertFalse(self.a.store.reload()[LOCK_KEY])

    async def test_missing_current_authorization_never_reaches_termination(self):
        await self.baseline();self.add()
        self.api.sessions=[s for s in self.api.sessions if not s.current]
        await self.guard.poll_account(self.a)
        self.assertEqual(self.api.requests,[])
        self.assertEqual(self.state()['error'],'SafeError')

    async def test_generation_mismatch_pauses_instead_of_retrusting_or_revoking(self):
        await self.baseline();self.add()
        self.a.store.update(**{GEN_KEY:55})
        await self.guard.poll_account(self.a)
        self.assertEqual(self.api.requests,[])
        self.assertEqual(self.state()['error'],'SafeError')

    async def test_corrupt_monitor_can_still_be_switched_off_without_network(self):
        self.a.store.update(**{STATE_KEY:{'bad':PRIVATE}})
        await self.guard.set_lock(self.a.key,False)
        self.assertFalse(self.a.store.reload()[LOCK_KEY])
        self.a.sessions.ensure.assert_not_awaited()

    async def test_known_history_pruning_retains_active_candidate_identifiers(self):
        await self.baseline();self.add()
        self.api.remove=False
        await self.guard.poll_account(self.a)
        state=self.state()
        state['known']=[str(NEW),str(OLD)]+[str(1000+i) for i in range(510)]
        self.a.store.update(**{STATE_KEY:state})
        self.add(555)
        await self.guard.poll_account(self.a)
        self.assertIn(str(NEW),self.state()['known'])
        self.assertIn(str(OLD),self.state()['known'])
        self.assertIn('555',self.state()['known'])
        self.assertLessEqual(len(self.state()['known']),512)
        self.assertEqual(self.state()['total_new'],2)

    async def test_all_three_workers_are_started_and_stopped_and_commands_registered(self):
        app=context(self.rt).application
        app.bot.get_webhook_info=AsyncMock(return_value=NS(url=''))
        app.bot.set_my_commands=AsyncMock()
        async def forever(*args):await asyncio.Event().wait()
        with patch.object(self.rt,'worker',side_effect=forever), patch.object(self.rt.security,'worker',side_effect=forever), patch.object(self.rt.guard,'worker',side_effect=forever):
            await bot.on_startup(app);await asyncio.sleep(0)
            self.assertEqual(len({self.rt.task,self.rt.security_task,self.rt.guard_task}),3)
            commands={c.command for c in app.bot.set_my_commands.await_args.args[0]}
            self.assertTrue({'protection','lock','unlock','alerts'}.issubset(commands))
            await bot.on_stop(app)
            self.assertTrue(all(t.done() for t in (self.rt.task,self.rt.security_task,self.rt.guard_task)))
        self.assertEqual(self.controller.reload()['scheduler_interval_seconds'],3600)

    async def test_removing_account_cancels_its_worker_without_recreating_state(self):
        b=self.rt.registry.create();self.attach(b,8888)
        with patch('login_guard.DISCOVERY_INTERVAL',0.01):
            task=asyncio.create_task(self.guard.worker(self.app))
            try:
                await asyncio.sleep(0.03);await self.rt.registry.remove(b.key);await asyncio.sleep(0.04)
                self.assertFalse(b.store.path.exists())
                self.assertEqual(len([t for t in asyncio.all_tasks() if t.get_name()=='login-protection-account' and not t.done()]),1)
            finally:
                task.cancel()
                with contextlib.suppress(asyncio.CancelledError):await task

    async def test_guard_restart_never_becomes_an_automatic_rebaseline(self):
        await self.baseline();self.add()
        restarted=bot.Runtime(Store(self.root))
        try:
            account=restarted.registry.get(self.a.key)
            account.sessions.me=NS(id=7777);account.sessions.ensure=AsyncMock(return_value=self.api)
            guard=LoginGuard(restarted.registry,restarted.store,clock=lambda:self.now[0])
            await guard.poll_account(account)
            self.assertEqual(self.api.requests,[NEW])
            self.assertNotIn(str(NEW),guard_state(account.store.reload())['trusted'])
        finally:await restarted.registry.close()

    async def test_console_emergency_unlock_preserves_jobs_and_session_fields(self):
        import manage
        fields=[k for k in self.a.store.reload() if k not in (LOCK_KEY,GEN_KEY)]
        before={k:self.a.store.data[k] for k in fields}
        with patch('manage.stop',return_value=0),patch('manage.lock_held',return_value=False),patch('manage.start') as start:
            self.assertEqual(manage.emergency_unlock(self.root),0)
        self.assertFalse(self.a.store.reload()[LOCK_KEY])
        self.assertEqual({k:self.a.store.data[k] for k in fields},before)
        start.assert_not_called()

    async def test_console_emergency_unlock_aborts_when_process_stop_not_verified(self):
        import manage
        with patch('manage.stop',return_value=1),patch('manage.lock_held',return_value=True),patch('manage.start') as start:
            self.assertEqual(manage.emergency_unlock(self.root),1)
        self.assertTrue(self.a.store.reload()[LOCK_KEY]);start.assert_not_called()

    async def test_console_emergency_unlock_restarts_only_a_previously_running_bot(self):
        import manage
        with patch('manage.stop',return_value=0),patch('manage.lock_held',return_value=True),patch('manage.start',return_value=0) as start:
            self.assertEqual(manage.emergency_unlock(self.root),0)
        start.assert_called_once_with(self.root)
        self.assertFalse(self.a.store.reload()[LOCK_KEY])

    async def test_console_emergency_unlock_never_recreates_a_missing_profile(self):
        import manage
        b=self.rt.registry.create();b.store.path.unlink()
        with patch('manage.stop',return_value=0),patch('manage.lock_held',return_value=False),patch('manage.start') as start:
            self.assertEqual(manage.emergency_unlock(self.root),1)
        self.assertFalse(b.store.path.exists());self.assertTrue(self.a.store.reload()[LOCK_KEY]);start.assert_not_called()

    async def test_console_emergency_unlock_rejects_path_like_profile_keys(self):
        import manage
        self.controller.update(profiles=['../outside'])
        with patch('manage.stop',return_value=0),patch('manage.lock_held',return_value=False),patch('manage.start') as start:
            self.assertEqual(manage.emergency_unlock(self.root),1)
        self.assertTrue(self.a.store.reload()[LOCK_KEY]);start.assert_not_called()

    async def test_failed_arming_does_not_turn_an_off_lock_on(self):
        await self.guard.set_lock(self.a.key,False)
        self.api.read_error=TimeoutError(PRIVATE)
        with self.assertRaises(TimeoutError):await self.guard.set_lock(self.a.key,True)
        self.assertFalse(self.a.store.reload()[LOCK_KEY])


class GuardAdapterTests(unittest.IsolatedAsyncioTestCase):
    def raw_sessions(self):
        return NS(authorizations=[NS(hash=0,date_created=1700000000,current=True,ip=PRIVATE,device_model=PRIVATE),
                                  NS(hash=NEW,date_created=1800000000,current=False,ip=PRIVATE,device_model=PRIVATE)])

    async def test_telethon_list_retains_only_safe_metadata(self):
        adapter=TelethonAdapter();adapter.client=AsyncMock(return_value=self.raw_sessions())
        result=await adapter.authorizations()
        self.assertEqual(type(adapter.client.await_args.args[0]).__name__,'GetAuthorizationsRequest')
        self.assertNotIn(PRIVATE,repr(result));self.assertEqual(result[1].authorization_hash,NEW)

    async def test_pyrogram_list_retains_only_safe_metadata(self):
        adapter=PyrogramAdapter();adapter.client=NS(invoke=AsyncMock(return_value=self.raw_sessions()))
        result=await adapter.authorizations()
        self.assertEqual(type(adapter.client.invoke.await_args.args[0]).__name__,'GetAuthorizations')
        self.assertNotIn(PRIVATE,repr(result));self.assertEqual(result[1].authorization_hash,NEW)

    async def test_telethon_only_single_hash_reset_method(self):
        adapter=TelethonAdapter();adapter.client=AsyncMock(return_value=True)
        self.assertIs(await adapter.terminate_session(NEW),True)
        request=adapter.client.await_args.args[0]
        self.assertEqual(type(request).__name__,'ResetAuthorizationRequest');self.assertEqual(request.hash,NEW)

    async def test_pyrogram_only_single_hash_reset_method(self):
        adapter=PyrogramAdapter();adapter.client=NS(invoke=AsyncMock(return_value=True))
        self.assertIs(await adapter.terminate_session(NEW),True)
        request=adapter.client.invoke.await_args.args[0]
        self.assertEqual(type(request).__name__,'ResetAuthorization');self.assertEqual(request.hash,NEW)

    async def test_both_adapters_reject_zero_before_any_rpc(self):
        tele=TelethonAdapter();tele.client=AsyncMock()
        pyro=PyrogramAdapter();pyro.client=NS(invoke=AsyncMock())
        for adapter in (tele,pyro):
            with self.assertRaises(SafeError):await adapter.terminate_session(0)
        tele.client.assert_not_awaited();pyro.client.invoke.assert_not_awaited()


if __name__=='__main__':unittest.main()
