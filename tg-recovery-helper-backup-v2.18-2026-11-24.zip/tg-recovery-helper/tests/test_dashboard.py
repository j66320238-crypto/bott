"""Offline My IDs/dashboard regression tests, including a full day offline."""
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

from telegram.error import BadRequest, TimedOut

import bot
from dashboard import account_keyboard, account_screen, accounts_screen, countdown, date_time, job_view, phone_number
from recovery import RecoveryEngine
from sessions import PasswordInfo, ResetResult
from storage import SafeError, Store, Vault


def update(action="", uid=1234, kind="private"):
    query = SimpleNamespace(data=action, answer=AsyncMock(), edit_message_text=AsyncMock()) if action else None
    return SimpleNamespace(effective_user=SimpleNamespace(id=uid), effective_chat=SimpleNamespace(type=kind),
                           effective_message=SimpleNamespace(reply_text=AsyncMock(), delete=AsyncMock()), callback_query=query)


def context(rt):
    return SimpleNamespace(application=SimpleNamespace(bot_data={"runtime": rt}, bot=SimpleNamespace(send_message=AsyncMock())), user_data={})


def buttons(keyboard):
    return [b for row in keyboard.inline_keyboard for b in row]


class DashboardTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.store = Store(self.root)
        self.store.update(owner_id=1234, api_id=12345, api_hash="a" * 32)
        self.rt = bot.Runtime(self.store)
        self.a = self.rt.current
        self.a.store.update(registered=True, account_user_id=7777, detected_user_id=7777,
                            owner_phone="+911234567890", library="telethon")
        self.a.sessions.ensure = AsyncMock(side_effect=AssertionError("Read-only UI must not connect"))
        self.now = 1800000000

    async def asyncTearDown(self):
        await self.rt.registry.close()
        self.temp.cleanup()

    def waiting(self, account=None, days=7):
        account = account or self.a
        account.store.update(reset_status="waiting", phase="waiting", wait_kind="reset",
                             reset_started_at=self.now, reset_until_date=self.now + days * 86400,
                             next_attempt_at=self.now + days * 86400,
                             pending_new_password="SENTINEL-CIPHERTEXT-NEVER-RENDER", pending_hint="SENTINEL-HINT-NEVER-RENDER")

    def second(self):
        account = self.rt.registry.create()
        account.store.update(registered=True, account_user_id=8888, detected_user_id=8888,
                             owner_phone="+919876543210", library="pyrogram")
        account.sessions.ensure = AsyncMock(side_effect=AssertionError("Read-only UI must not connect"))
        return account

    async def test_home_has_prominent_my_ids_button(self):
        first = bot.menu().inline_keyboard[0]
        self.assertEqual(first[0].text, "My IDs")
        self.assertEqual(first[0].callback_data, "myids")

    async def test_list_shows_all_numbers_and_target_ids(self):
        b = self.second()
        text, keyboard = accounts_screen(self.rt.registry, self.now)
        for value in ("+911234567890", "+919876543210", "7777", "8888", "MY IDs"):
            self.assertIn(value, text)
        self.assertEqual({x.callback_data for x in buttons(keyboard) if x.callback_data.startswith("account:")},
                         {"account:" + self.a.key, "account:" + b.key})
        self.assertEqual(self.store.reload()["owner_id"], 1234)

    async def test_list_has_wait_state_and_remaining_time(self):
        self.waiting()
        text, _ = accounts_screen(self.rt.registry, self.now + 86400)
        self.assertIn("Active jobs: 1", text)
        self.assertIn("6d 0h 0m", text)
        self.assertIn("Reset waiting", text)

    async def test_dashboard_shows_number_id_exact_deadline_and_both_timezones(self):
        self.waiting()
        text, _ = account_screen(self.a, self.now + 86400)
        self.assertIn("ACCOUNT DASHBOARD", text)
        self.assertIn("+911234567890", text)
        self.assertIn("Telegram ID: 7777", text)
        self.assertIn("Remaining: 6d 0h 0m", text)
        self.assertIn(date_time(self.now + 7 * 86400), text)
        self.assertIn(date_time(self.now + 7 * 86400, utc=True), text)
        self.assertIn("Offline time counts", text)

    async def test_dashboard_never_renders_pending_password_hint_or_credentials(self):
        self.waiting()
        self.a.store.update(api_hash="SECRET-API-HASH", bot_token="SECRET-BOT-TOKEN")
        for text in (account_screen(self.a, self.now)[0], accounts_screen(self.rt.registry, self.now)[0]):
            for secret in ("SENTINEL-CIPHERTEXT-NEVER-RENDER", "SENTINEL-HINT-NEVER-RENDER", "SECRET-API-HASH", "SECRET-BOT-TOKEN"):
                self.assertNotIn(secret, text)

    async def test_unverified_detected_phone_is_display_only(self):
        self.a.store.update(registered=False, owner_phone="", detected_phone="+919876543210")
        text, _ = account_screen(self.a, self.now)
        self.assertIn("Phone: +919876543210", text)
        self.assertIn("Required before recovery", text)
        self.assertFalse(self.a.store.reload()["registered"])

    async def test_cooldown_is_not_seven_day_reset(self):
        self.a.store.update(reset_status="waiting", phase="cooldown", wait_kind="cooldown",
                            retry_at=self.now + 3600, next_attempt_at=self.now + 3600)
        text, _ = account_screen(self.a, self.now)
        self.assertIn("Eligibility cooldown", text)
        self.assertIn("NOT started", text)
        self.assertIn("0d 1h 0m", text)
        self.assertNotIn("Telegram reset deadline", text)

    async def test_elapsed_deadline_reports_due_not_completed(self):
        self.waiting()
        text, _ = account_screen(self.a, self.now + 8 * 86400)
        self.assertIn("Due now", text)
        self.assertIn("check pending", text)
        self.assertNotIn("new 2FA confirmed", text)
        self.assertEqual(self.a.store.reload()["reset_status"], "waiting")

    async def test_cancelled_job_does_not_display_old_countdown(self):
        self.waiting()
        self.a.store.update(reset_status="cancelled", phase="cancelled")
        text, _ = account_screen(self.a, self.now)
        self.assertIn("No active saved countdown", text)
        self.assertNotIn("Remaining:", text)

    async def test_applying_phase_does_not_imply_old_password_still_protected(self):
        self.waiting()
        self.a.store.update(phase="applying", password_apply_status="not_confirmed", next_attempt_at=self.now + 3600)
        text, _ = account_screen(self.a, self.now)
        self.assertIn("Applying new password", text)
        self.assertIn("not confirmed", text)
        self.assertIn("Next permitted attempt", text)
        self.assertNotIn("Telegram reset deadline", text)

    async def test_more_options_are_bound_to_their_account(self):
        _, keyboard = account_screen(self.a, self.now, more=True)
        for b in buttons(keyboard):
            if b.callback_data.startswith("acct:"):
                self.assertTrue(b.callback_data.startswith("acct:" + self.a.key + ":"))
                self.assertLessEqual(len(b.callback_data.encode()), 64)
        self.assertIn("Remove local profile", [b.text for b in buttons(keyboard)])

    async def test_pagination_reaches_twenty_profiles_without_truncation(self):
        self.store.update(max_accounts=20)
        for i in range(19):
            account = self.rt.registry.create()
            account.store.update(detected_user_id=9000 + i, detected_phone="+919000000" + f"{i:03d}")
        reached = set()
        for page in range(4):
            text, keyboard = accounts_screen(self.rt.registry, self.now, page)
            self.assertLess(len(text), 3400)
            reached.update(b.callback_data[8:] for b in buttons(keyboard) if b.callback_data.startswith("account:"))
        self.assertEqual(reached, set(self.rt.registry.keys()))
        self.assertIn("Page 1/4", accounts_screen(self.rt.registry, self.now, -99)[0])
        self.assertIn("Page 4/4", accounts_screen(self.rt.registry, self.now, 999)[0])

    async def test_corrupt_profile_does_not_hide_other_ids(self):
        self.second()
        self.a.store.path.write_text("{broken")
        text, _ = accounts_screen(self.rt.registry, self.now)
        self.assertIn("Profile unavailable", text)
        self.assertIn("+919876543210", text)

    async def test_my_ids_command_does_not_call_any_session_or_reset(self):
        self.waiting()
        before = self.a.store.path.read_bytes()
        self.a.engine.start = AsyncMock()
        event = update()
        await bot.accounts_command(event, context(self.rt))
        self.assertIn("MY IDs", event.effective_message.reply_text.await_args.args[0])
        self.a.sessions.ensure.assert_not_awaited()
        self.a.engine.start.assert_not_awaited()
        self.assertEqual(before, self.a.store.path.read_bytes())

    async def test_non_owner_cannot_read_numbers_or_ids(self):
        event = update("myids", uid=7777)
        await bot.callback(event, context(self.rt))
        event.callback_query.edit_message_text.assert_not_awaited()
        self.assertEqual(event.callback_query.answer.await_args.args[0], "Access denied.")

    async def test_owner_cannot_read_dashboard_in_a_group(self):
        event = update("account:" + self.a.key, kind="group")
        await bot.callback(event, context(self.rt))
        event.callback_query.edit_message_text.assert_not_awaited()
        self.assertIn("Access denied", event.callback_query.answer.await_args.args[0])

    async def test_selecting_number_opens_account_options_without_reset(self):
        b = self.second()
        self.waiting()
        before = self.a.store.path.read_bytes()
        event = update("account:" + self.a.key)
        await bot.callback(event, context(self.rt))
        self.assertEqual(self.rt.registry.active_key, self.a.key)
        self.assertIn("ACCOUNT DASHBOARD", event.callback_query.edit_message_text.await_args.args[0])
        self.assertIn("+911234567890", event.callback_query.edit_message_text.await_args.args[0])
        self.assertEqual(before, self.a.store.path.read_bytes())
        self.a.sessions.ensure.assert_not_awaited()
        b.sessions.ensure.assert_not_awaited()

    async def test_refresh_edits_same_message_with_single_device_check(self):
        self.waiting()
        before = self.a.store.path.read_bytes()
        self.a.engine.tick = AsyncMock()
        event = update("acct:" + self.a.key + ":refresh")
        with patch("bot.time.time", return_value=self.now + 86400):
            await bot.callback(event, context(self.rt))
        self.assertIn("6d 0h 0m", event.callback_query.edit_message_text.await_args.args[0])
        event.effective_message.reply_text.assert_not_awaited()
        self.a.engine.tick.assert_not_awaited()
        # Refresh performs exactly one device check (the idle design's only read).
        self.a.sessions.ensure.assert_awaited_once()
        self.assertEqual(before, self.a.store.path.read_bytes())

    async def test_repeated_identical_refresh_is_not_an_error(self):
        event = update("acct:" + self.a.key + ":refresh")
        event.callback_query.edit_message_text.side_effect = BadRequest("Message is not modified")
        await bot.callback(event, context(self.rt))
        event.effective_message.reply_text.assert_not_awaited()

    async def test_uneditable_old_screen_falls_back_to_new_message(self):
        event = update("acct:" + self.a.key + ":refresh")
        event.callback_query.edit_message_text.side_effect = BadRequest("Message can't be edited")
        await bot.callback(event, context(self.rt))
        event.effective_message.reply_text.assert_awaited_once()

    async def test_network_error_is_not_silently_reported_as_success(self):
        event = update("acct:" + self.a.key + ":refresh")
        event.callback_query.edit_message_text.side_effect = TimedOut()
        with self.assertRaises(TimedOut): await bot.callback(event, context(self.rt))

    async def test_old_account_check_button_routes_to_its_embedded_account(self):
        b = self.second()
        self.a.engine.tick, b.engine.tick = AsyncMock(return_value="A checked"), AsyncMock(return_value="B checked")
        await bot.callback(update("acct:" + self.a.key + ":check"), context(self.rt))
        self.a.engine.tick.assert_awaited_once_with(manual=True)
        b.engine.tick.assert_not_awaited()
        self.assertEqual(self.rt.registry.active_key, self.a.key)

    async def test_account_cancel_option_requires_new_final_confirmation(self):
        self.waiting()
        self.second()
        self.a.engine.cancel = AsyncMock()
        ctx = context(self.rt)
        event = update("acct:" + self.a.key + ":cancel")
        await bot.callback(event, ctx)
        self.a.engine.cancel.assert_not_awaited()
        self.assertEqual(ctx.user_data["cancel_account"], self.a.key)
        self.assertIn("cancel ONLY", event.effective_message.reply_text.await_args.args[0].replace("Cancel ONLY", "cancel ONLY"))

    async def test_removed_account_button_never_falls_back_to_other_account(self):
        b = self.second()
        await self.rt.registry.remove(b.key)
        self.a.engine.tick = AsyncMock()
        with self.assertRaises(SafeError):
            await bot.callback(update("acct:" + b.key + ":check"), context(self.rt))
        self.a.engine.tick.assert_not_awaited()
        self.assertEqual(self.rt.registry.active_key, self.a.key)

    async def test_unknown_account_action_does_not_change_selection(self):
        b = self.second()
        with self.assertRaises(SafeError):
            await bot.callback(update("acct:" + self.a.key + ":unknown"), context(self.rt))
        self.assertEqual(self.rt.registry.active_key, b.key)

    async def test_old_accounts_button_remains_compatible(self):
        event = update("accounts")
        await bot.callback(event, context(self.rt))
        self.assertIn("MY IDs", event.callback_query.edit_message_text.await_args.args[0])

    async def test_timer_command_uses_current_time_without_contacting_session(self):
        self.waiting()
        event = update()
        with patch("bot.time.time", return_value=self.now + 2 * 86400):
            await bot.timer_command(event, context(self.rt))
        self.assertIn("5d 0h 0m", event.effective_message.reply_text.await_args.args[0])
        self.a.sessions.ensure.assert_not_awaited()

    async def test_direct_import_persists_display_phone_but_not_verified_permission(self):
        source = self.root / "own.session"
        db = sqlite3.connect(source)
        db.execute("CREATE TABLE sessions (dc_id INTEGER)"); db.commit(); db.close()
        class Preview:
            async def connect(_self, *args): return SimpleNamespace(id=8888, phone="919876543210", bot=False)
            async def close(_self): pass
        with patch("sessions.TelethonAdapter", Preview):
            result = await self.rt.router.import_file(source)
        data = result.account.store.reload()
        self.assertEqual(data["detected_phone"], "+919876543210")
        self.assertTrue(data["registered"])
        self.assertEqual(data["owner_phone"], "+919876543210")
        self.assertEqual(data["account_user_id"], 8888)
        self.assertEqual(data["reset_status"], "idle")
        self.assertEqual(phone_number(data), "+919876543210")


class TimerMathTests(unittest.TestCase):
    def test_less_than_a_minute_and_due_are_distinct(self):
        self.assertEqual(countdown(1050, 1000), "Less than 1 minute")
        self.assertEqual(countdown(1000, 1000), "Due now")
        self.assertEqual(countdown(1000, 9999), "Due now")

    def test_ist_and_utc_are_explicit(self):
        self.assertIn("06:30:00 IST", date_time(3600))
        self.assertIn("01:00:00 UTC", date_time(3600, utc=True))

    def test_unknown_deadline_is_not_guessed_as_seven_days(self):
        view = job_view({"reset_status": "waiting", "phase": "requesting"}, 1000)
        self.assertEqual(view.deadline, 0)
        self.assertIn("No deadline is guessed", view.note)


class OfflineRecoveryTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.store = Store(self.root)
        self.store.update(registered=True, account_user_id=7777, owner_phone="+911234567890")
        self.vault = Vault(self.root)
        self.now = 1800000000
        self.deadline = self.now + 7 * 86400
        self.adapter = SimpleNamespace(info=AsyncMock(return_value=PasswordInfo(True)),
                                       reset=AsyncMock(return_value=ResetResult("wait", self.deadline)),
                                       set_password=AsyncMock(return_value=True))
        self.sessions = SimpleNamespace(ensure=AsyncMock(return_value=self.adapter))
        self.engine = RecoveryEngine(self.store, self.sessions, self.vault, lambda: self.now)
        await self.engine.start(self.vault.seal("offline-test-only-password"), "")
        self.adapter.info.return_value = PasswordInfo(True, pending_reset_date=self.deadline)

    async def asyncTearDown(self): self.temp.cleanup()

    async def test_one_day_offline_restart_leaves_six_days_without_new_rpc(self):
        self.now += 86400
        fresh = Store(self.root)
        self.adapter.info.reset_mock()
        resumed = RecoveryEngine(fresh, self.sessions, Vault(self.root), lambda: self.now)
        await resumed.tick()
        self.assertEqual(fresh.reload()["reset_until_date"], self.deadline)
        self.assertEqual(countdown(self.deadline, self.now), "6d 0h 0m")
        self.assertEqual(self.adapter.reset.await_count, 1)
        self.adapter.info.assert_not_awaited()
        self.adapter.set_password.assert_not_awaited()

    async def test_restart_after_deadline_finishes_not_another_seven_day_wait(self):
        self.now += 8 * 86400
        async def finish():
            self.adapter.info.return_value = PasswordInfo(False)
            return ResetResult("ok")
        self.adapter.reset.side_effect = finish
        fresh = Store(self.root)
        resumed = RecoveryEngine(fresh, self.sessions, Vault(self.root), lambda: self.now)
        await resumed.tick()
        self.assertEqual(fresh.reload()["reset_status"], "done")
        self.assertEqual(fresh.data["password_apply_status"], "applied")
        self.assertEqual(self.adapter.reset.await_count, 2)  # initial request + official finish
        self.adapter.set_password.assert_awaited_once()
        self.assertEqual(fresh.data["reset_until_date"], 0)

    async def test_new_official_deadline_is_respected_if_server_reports_a_later_date(self):
        self.now += 8 * 86400
        extended = self.now + 3600
        self.adapter.info.return_value = PasswordInfo(True, pending_reset_date=extended)
        fresh = Store(self.root)
        resumed = RecoveryEngine(fresh, self.sessions, Vault(self.root), lambda: self.now)
        await resumed.tick()
        self.assertEqual(fresh.reload()["reset_until_date"], extended)
        self.assertEqual(self.adapter.reset.await_count, 1)
        self.adapter.set_password.assert_not_awaited()


if __name__ == "__main__":
    unittest.main()
