"""Offline regression tests: controller identity != target identity; isolated jobs."""
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

import bot
from accounts import AccountRegistry
from sessions import PasswordInfo, ResetResult
from storage import SafeError, Store, Vault


class Adapter:
    def __init__(self, deadline=2000):
        self.password = True
        self.pending = 0
        self.deadline = deadline
        self.reset_calls = 0
        self.set_calls = 0
        self.received_password = None
        self.finish = False

    async def info(self): return PasswordInfo(self.password, pending_reset_date=self.pending)

    async def reset(self):
        self.reset_calls += 1
        if self.finish:
            self.password = False
            self.pending = 0
            return ResetResult("ok")
        self.pending = self.deadline
        return ResetResult("wait", self.deadline)

    async def set_password(self, password, hint):
        self.set_calls += 1
        self.received_password = password
        self.password = True
        return True

    async def decline(self):
        self.pending = 0
        return True

    async def spamcheck(self): return "No limits."


class Sessions:
    def __init__(self, adapter): self.adapter = adapter
    async def ensure(self): return self.adapter


def update_for(action="", uid=1234):
    message = SimpleNamespace(reply_text=AsyncMock(), delete=AsyncMock(), document=SimpleNamespace(get_file=AsyncMock()))
    query = SimpleNamespace(data=action, answer=AsyncMock()) if action else None
    return SimpleNamespace(effective_user=SimpleNamespace(id=uid), effective_chat=SimpleNamespace(type="private"),
                           effective_message=message, callback_query=query)


def context_for(runtime, data=None):
    app = SimpleNamespace(bot_data={"runtime": runtime}, bot=SimpleNamespace(send_message=AsyncMock()))
    return SimpleNamespace(application=app, user_data=data or {})


class MultiAccountTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.controller = Store(self.root)
        self.controller.update(owner_id=1234, api_id=54321, api_hash="a" * 32)
        self.rt = bot.Runtime(self.controller)
        self.reg = self.rt.registry
        self.a = self.reg.get()
        self.now = 1000

    async def asyncTearDown(self):
        await self.reg.close()
        self.temp.cleanup()

    def verified(self, account, uid, phone="+911234567890"):
        account.store.update(account_user_id=uid, detected_user_id=uid, registered=True, owner_phone=phone)
        account.engine.clock = lambda: self.now

    async def test_controller_and_target_ids_can_differ(self):
        db = sqlite3.connect(self.a.store.root / "mine.session")
        db.execute("CREATE TABLE sessions (dc_id INTEGER)"); db.commit(); db.close()
        class OwnAccount:
            async def connect(self, *args): return SimpleNamespace(id=7777, phone="911234567890", bot=False)
            async def close(self): pass
        with patch("sessions.TelethonAdapter", OwnAccount):
            await self.a.sessions.ensure()
            await self.a.sessions.verify_phone("+911234567890")
        self.assertEqual(self.a.store.data["account_user_id"], 7777)
        self.assertEqual(self.controller.reload()["owner_id"], 1234)
        self.assertEqual(self.a.store.data["owner_id"], 0)
        self.assertTrue(self.a.store.data["registered"])

    async def test_only_controller_can_operate_bot_not_target_uid(self):
        self.verified(self.a, 7777)
        self.assertTrue(await bot.allowed(update_for(uid=1234), context_for(self.rt)))
        self.assertFalse(await bot.allowed(update_for(uid=7777), context_for(self.rt)))

    async def test_passwords_and_deadlines_are_separate(self):
        self.verified(self.a, 7777)
        b = self.reg.create(); self.verified(b, 8888)
        aa, bb = Adapter(2000), Adapter(3000)
        self.a.engine.sessions, b.engine.sessions = Sessions(aa), Sessions(bb)
        await self.a.engine.start(self.reg.vault.seal("password-for-A-only"), "A hint")
        saved_a = self.a.store.path.read_text()
        await b.engine.start(self.reg.vault.seal("password-for-B-only"), "B hint")
        self.assertEqual(saved_a, self.a.store.path.read_text())
        self.assertEqual(self.a.store.data["reset_until_date"], 2000)
        self.assertEqual(b.store.data["reset_until_date"], 3000)
        self.assertEqual(self.reg.vault.open(self.a.store.data["pending_new_password"]), "password-for-A-only")
        self.assertEqual(self.reg.vault.open(b.store.data["pending_new_password"]), "password-for-B-only")
        self.assertEqual(self.controller.reload()["pending_new_password"], "")

    async def test_due_account_finishes_without_touching_later_account(self):
        self.verified(self.a, 7777)
        b = self.reg.create(); self.verified(b, 8888)
        aa, bb = Adapter(2000), Adapter(4000)
        self.a.engine.sessions, b.engine.sessions = Sessions(aa), Sessions(bb)
        await self.a.engine.start(self.reg.vault.seal("password-for-A-only"), "")
        await b.engine.start(self.reg.vault.seal("password-for-B-only"), "")
        aa.finish = True
        self.now = 2100
        active_before = self.reg.active_key
        await self.reg.tick_all()
        self.assertEqual(self.a.store.data["reset_status"], "done")
        self.assertEqual(b.store.data["reset_status"], "waiting")
        self.assertEqual(bb.reset_calls, 1)
        self.assertEqual(aa.received_password, "password-for-A-only")
        self.assertEqual(self.reg.active_key, active_before)

    async def test_restart_preserves_each_profile_and_active_selection(self):
        b = self.reg.create()
        self.a.store.update(reset_status="waiting", reset_until_date=5000, pending_new_password="cipher-A")
        b.store.update(reset_status="waiting", reset_until_date=7000, pending_new_password="cipher-B")
        fresh = AccountRegistry(Store(self.root))
        self.assertEqual(fresh.active_key, b.key)
        self.assertEqual(fresh.get(self.a.key).store.data["pending_new_password"], "cipher-A")
        self.assertEqual(fresh.get(b.key).store.data["reset_until_date"], 7000)
        await fresh.close()

    async def test_one_scheduler_failure_does_not_skip_other_profile(self):
        b = self.reg.create()
        self.a.engine.tick = AsyncMock(side_effect=SafeError("Expired session"))
        b.engine.tick = AsyncMock(return_value="B checked")
        result = await self.reg.tick_all()
        b.engine.tick.assert_awaited_once()
        self.assertEqual(result[b.key], "B checked")
        self.assertIn("paused", result[self.a.key])

    async def test_unreadable_profile_does_not_block_healthy_tick(self):
        b = self.reg.create()
        self.a.store.path.write_text("{broken")
        b.engine.tick = AsyncMock(return_value="B still checked")
        result = await self.reg.tick_all()
        self.assertEqual(result[b.key], "B still checked")
        self.assertFalse(self.reg.has_notices())

    async def test_missing_profile_is_not_recreated_as_idle(self):
        b = self.reg.create()
        self.a.store.path.unlink()
        fresh = AccountRegistry(Store(self.root))
        with self.assertRaises(SafeError): fresh.get(self.a.key)
        self.assertFalse(self.a.store.path.exists())
        fresh.get(b.key).engine.tick = AsyncMock(return_value="B survives")
        self.assertEqual((await fresh.tick_all())[b.key], "B survives")
        await fresh.close()

    async def test_duplicate_target_account_rejected(self):
        self.verified(self.a, 7777)
        b = self.reg.create()
        b.store.update(detected_user_id=7777)
        with self.assertRaisesRegex(SafeError, "already added"):
            self.reg.assert_unique(b.key)
        self.assertEqual(b.store.data["reset_status"], "idle")

    async def test_selecting_another_account_does_not_cancel_first(self):
        self.a.store.update(reset_status="waiting", reset_until_date=3000)
        b = self.reg.create()
        self.reg.select(self.a.key)
        self.reg.select(b.key)
        self.assertEqual(self.a.store.reload()["reset_status"], "waiting")
        self.assertEqual(self.a.store.data["reset_until_date"], 3000)

    async def test_old_reset_button_cannot_apply_to_new_selected_account(self):
        self.verified(self.a, 7777)
        b = self.reg.create(); self.verified(b, 8888)
        b.engine.start = AsyncMock()
        context = context_for(self.rt, {"flow": "confirm", "draft": {
            "account_key": self.a.key, "account_user_id": 7777,
            "created": int(__import__('time').time()), "nonce": "oldnonce"}})
        with self.assertRaisesRegex(SafeError, "another account"):
            await bot.callback(update_for("begin:oldnonce"), context)
        b.engine.start.assert_not_awaited()

    async def test_old_cancel_button_cannot_cancel_other_account(self):
        b = self.reg.create()
        b.engine.cancel = AsyncMock()
        context = context_for(self.rt, {"cancel_account": self.a.key, "cancel_nonce": "oldnonce"})
        with self.assertRaises(SafeError): await bot.callback(update_for("cancel_yes:oldnonce"), context)
        b.engine.cancel.assert_not_awaited()

    async def test_account_switch_clears_sensitive_drafts(self):
        b = self.reg.create()
        context = context_for(self.rt, {"flow": "confirm", "draft": {"encrypted": "old-secret"}, "upload_nonce": "old"})
        await bot.callback(update_for("account:" + self.a.key), context)
        self.assertNotIn("draft", context.user_data)
        self.assertNotIn("upload_nonce", context.user_data)
        self.assertEqual(self.reg.active_key, self.a.key)

    async def test_unauthorized_session_document_is_not_downloaded(self):
        update = update_for(uid=9999)
        await bot.document_input(update, context_for(self.rt, {"flow": "upload"}))
        update.effective_message.document.get_file.assert_not_awaited()

    async def test_active_profile_cannot_be_removed(self):
        self.a.store.update(reset_status="waiting", pending_new_password="keep-me")
        with self.assertRaises(SafeError): await self.reg.remove(self.a.key)
        self.assertIn(self.a.key, self.reg.keys())
        self.assertEqual(self.a.store.reload()["pending_new_password"], "keep-me")

    async def test_removing_idle_profile_does_not_touch_other_state(self):
        self.a.store.update(reset_status="waiting", reset_until_date=3000)
        b = self.reg.create()
        await self.reg.remove(b.key)
        self.assertTrue(self.a.store.path.exists())
        self.assertFalse(b.store.root.exists())
        self.assertEqual(self.a.store.reload()["reset_until_date"], 3000)

    async def test_account_limit_is_explained_without_destroying_profiles(self):
        self.controller.update(max_accounts=2)
        self.reg.create()
        with self.assertRaisesRegex(SafeError, "limit is 2"):
            self.reg.create()
        self.assertEqual(len(self.reg.keys()), 2)

    async def test_shared_local_sessions_are_listed_and_traversal_is_blocked(self):
        shared = self.root / "sessions"
        shared.mkdir(exist_ok=True)
        db = sqlite3.connect(shared / "second.session")
        db.execute("CREATE TABLE sessions (dc_id INTEGER)"); db.commit(); db.close()
        self.assertIn("@local/sessions/second.session", self.a.sessions.candidates())
        self.assertEqual(self.a.sessions.checked_path("@local/sessions/second.session"), shared / "second.session")
        with self.assertRaises(SafeError): self.a.sessions.checked_path("@local/../../other.session")

    async def test_account_specific_notices_do_not_change_selection(self):
        self.verified(self.a, 7777)
        b = self.reg.create(); self.verified(b, 8888)
        self.a.store.queue("A finished")
        b.store.queue("B waiting")
        context = context_for(self.rt)
        await self.rt.flush(context.application)
        messages = [call.args[1] for call in context.application.bot.send_message.await_args_list]
        self.assertTrue(any("ID 7777" in m and "A finished" in m for m in messages))
        self.assertTrue(any("ID 8888" in m and "B waiting" in m for m in messages))
        self.assertEqual(self.reg.active_key, b.key)
        self.assertFalse(self.a.store.data["notices"])
        self.assertFalse(b.store.data["notices"])

    async def test_failed_notice_for_one_profile_does_not_erase_other_notice(self):
        b = self.reg.create()
        self.a.store.queue("A notice")
        b.store.queue("B notice")
        context = context_for(self.rt)
        async def send(_owner, text, **kwargs):
            if "A notice" in text: raise TimeoutError()
        context.application.bot.send_message.side_effect = send
        await self.rt.flush(context.application)
        self.assertEqual(self.a.store.data["notices"], ["A notice"])
        self.assertEqual(b.store.data["notices"], [])

    async def test_session_replacement_locked_only_for_its_waiting_profile(self):
        self.a.store.update(reset_status="waiting")
        with self.assertRaisesRegex(SafeError, "active saved job"):
            await self.a.sessions.select("any.session")
        b = self.reg.create()
        self.assertEqual(b.store.data["reset_status"], "idle")

    async def test_target_account_not_verified_cannot_start_reset(self):
        self.a.store.update(registered=False, detected_user_id=7777)
        adapter = Adapter()
        self.a.engine.sessions = Sessions(adapter)
        with self.assertRaises(SafeError):
            await self.a.engine.start(self.reg.vault.seal("password-never-applied"), "")
        self.assertEqual(adapter.reset_calls, 0)


class MigrationTests(unittest.TestCase):
    def test_legacy_wait_and_encrypted_password_migrate_once_without_restarting_timer(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            controller = Store(root)
            vault = Vault(root)
            encrypted = vault.seal("existing-pending-password")
            controller.update(owner_id=1234, api_id=54321, api_hash="a" * 32,
                              registered=True, session_name="sessions/old.session", library="telethon",
                              reset_status="waiting", phase="waiting", wait_kind="reset", reset_until_date=999999,
                              next_attempt_at=999999, pending_new_password=encrypted)
            reg = AccountRegistry(controller)
            account = reg.get()
            self.assertEqual(controller.data["owner_id"], 1234)
            self.assertEqual(controller.data["pending_new_password"], "")
            self.assertEqual(account.store.data["account_user_id"], 1234)
            self.assertEqual(account.store.data["session_name"], "@local/sessions/old.session")
            self.assertEqual(account.store.data["reset_until_date"], 999999)
            self.assertEqual(account.store.data["next_attempt_at"], 999999)
            self.assertEqual(reg.vault.open(account.store.data["pending_new_password"]), "existing-pending-password")
            again = AccountRegistry(Store(root))
            self.assertEqual(len(again.keys()), 1)
            self.assertEqual(again.get().store.data["pending_new_password"], encrypted)

    def test_invalid_registry_key_fails_closed(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = Store(Path(tmp))
            store.update(multi_account_version=2, profiles=["../../escape"])
            with self.assertRaises(SafeError): AccountRegistry(store)


if __name__ == "__main__":
    unittest.main()
