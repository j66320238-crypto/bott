"""Offline, synthetic security-chat tests. No login codes are requested.

The only outbound content permitted is fixed category/account/time metadata.
Adapters may inspect a body transiently; bodies never enter the durable outbox.
"""
from __future__ import annotations

import asyncio
import contextlib
import dataclasses
import json
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock, patch

import bot
from accounts import ACCOUNT_FIELDS
from security_alerts import (
    ENABLED_KEY, STATE_KEY, INTERVAL, SERVICE_USER_ID, ServiceEvent, SecurityMonitor,
    alert_state, alert_status, alerts_screen, classify_service_text, render_alert, retry_delay,
)
from sessions import PyrogramAdapter, TelethonAdapter
from storage import SafeError, Store

SENTINEL = "SYNTHETIC-PRIVATE-BODY Login code: 983761 https://example.invalid/secret-login"


class History:
    def __init__(self, events=()):
        self.events = list(events)
        self.calls = []
        self.error = None

    async def service_messages(self, offset_id=0, limit=50):
        self.calls.append((offset_id, limit))
        if self.error:
            raise self.error
        return sorted((e for e in self.events if not offset_id or e.message_id < offset_id),
                      key=lambda e: e.message_id, reverse=True)[:limit]


def update(uid=1234, kind="private", action=None):
    return NS(effective_user=NS(id=uid), effective_chat=NS(type=kind),
              effective_message=NS(reply_text=AsyncMock(), delete=AsyncMock()),
              callback_query=NS(data=action, answer=AsyncMock(), edit_message_text=AsyncMock()) if action else None)


def context(rt):
    return NS(application=NS(bot_data={"runtime": rt}, bot=NS(send_message=AsyncMock())), user_data={})


def buttons(keyboard):
    return [button for row in keyboard.inline_keyboard for button in row]


class ClassificationTests(unittest.TestCase):
    def test_login_code_becomes_enum_not_content(self):
        self.assertEqual(classify_service_text(SENTINEL), "otp")

    def test_other_security_notice_becomes_generic(self):
        self.assertEqual(classify_service_text("New login from a device at 12:00, 2026."), "message")

    def test_digits_alone_are_not_called_an_otp(self):
        self.assertEqual(classify_service_text("A setting changed on 20261121."), "message")

    def test_code_words_without_digits_are_generic(self):
        self.assertEqual(classify_service_text("Never share your login code."), "message")

    def test_empty_or_unknown_content_is_generic(self):
        self.assertEqual(classify_service_text(None), "message")
        self.assertEqual(classify_service_text("unrecognized-language 983761"), "message")

    def test_common_localized_code_patterns(self):
        for value in ("Код входа: 983761", "Código de verificación: 983761", "Code de connexion: 983761",
                      "Anmeldecode 983761", "登录验证码 983761", "आपका लॉगिन कोड 983761", "رمز التحقق 983761"):
            with self.subTest(value=value):
                self.assertEqual(classify_service_text(value), "otp")

    def test_metadata_event_has_no_text_or_link_field(self):
        self.assertEqual({f.name for f in dataclasses.fields(ServiceEvent)}, {"message_id", "date", "kind", "outgoing"})

    def test_state_rejects_extra_body_field(self):
        with self.assertRaises(SafeError):
            alert_state({STATE_KEY: {"body": SENTINEL}})

    def test_outbox_rejects_extra_body_or_code_field(self):
        for field in ("body", "text", "code", "url", "media", "text_hash"):
            with self.subTest(field=field), self.assertRaises(SafeError):
                alert_state({STATE_KEY: {"pending": {field: SENTINEL}}})

    def test_state_rejects_non_numeric_metadata(self):
        for invalid in (True, "983761", -1, 2**63):
            with self.subTest(invalid=invalid), self.assertRaises(SafeError):
                alert_state({STATE_KEY: {"cursor": invalid}})

    def test_state_rejects_freeform_error_text(self):
        with self.assertRaises(SafeError):
            alert_state({STATE_KEY: {"error": SENTINEL}})

    def test_retry_delay_respects_rate_limit(self):
        self.assertEqual(retry_delay(NS(seconds=321)), 322)
        self.assertEqual(retry_delay(NS(value=199)), 200)
        self.assertEqual(retry_delay(NS(retry_after=timedelta(seconds=500))), 501)

    def test_retry_delay_has_conservative_defaults(self):
        SessionRevokedError = type("SessionRevokedError", (Exception,), {})
        self.assertEqual(retry_delay(SessionRevokedError(SENTINEL)), 3600)
        self.assertEqual(retry_delay(RuntimeError(SENTINEL)), 60)
        self.assertEqual(INTERVAL, 30)

    def test_corrupt_alert_state_does_not_break_dashboard_status(self):
        self.assertIn("attention", alert_status({STATE_KEY: {"unexpected": SENTINEL}}))


class MonitorTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.controller = Store(self.root)
        self.controller.update(owner_id=1234, api_id=12345, api_hash="a" * 32)
        self.rt = bot.Runtime(self.controller)
        self.a = self.rt.current
        self.now = [1800000000]
        self.history = self.attach(self.a, 7777)
        self.history.events = [ServiceEvent(50, self.now[0] - 600, "message")]
        self.monitor = SecurityMonitor(self.rt.registry, self.controller, clock=lambda: self.now[0])
        self.app = NS(bot=NS(send_message=AsyncMock()))

    def attach(self, account, uid):
        account.store.update(account_user_id=uid, detected_user_id=uid, registered=True,
                             owner_phone="+911234567890", library="telethon", session_name="sessions/fake.session")
        history = History()
        account.sessions.me = NS(id=uid)
        account.sessions.ensure = AsyncMock(return_value=history)
        return history

    async def asyncTearDown(self):
        await self.rt.registry.close()
        self.temp.cleanup()

    def state(self, account=None):
        return alert_state((account or self.a).store.reload())

    def core(self, account=None):
        data = (account or self.a).store.reload()
        return {k: data[k] for k in ACCOUNT_FIELDS if k not in (ENABLED_KEY, STATE_KEY)}

    async def baseline(self):
        await self.monitor.poll_account(self.a)

    async def new_message(self, kind="otp", number=51, outgoing=False):
        self.history.events.append(ServiceEvent(number, self.now[0], kind, outgoing))
        await self.monitor.poll_account(self.a)

    async def test_defaults_enable_existing_and_future_profiles(self):
        self.assertTrue(self.controller.reload()[ENABLED_KEY])
        self.assertTrue(self.a.store.reload()[ENABLED_KEY])
        self.assertTrue(self.rt.registry.create().store.reload()[ENABLED_KEY])

    async def test_baseline_does_not_replay_old_messages(self):
        self.history.events.append(ServiceEvent(49, self.now[0] - 800, "otp"))
        await self.baseline()
        await self.monitor.flush_all(self.app)
        self.assertEqual(self.state()["cursor"], 50)
        self.assertTrue(self.state()["initialized"])
        self.app.bot.send_message.assert_not_awaited()

    async def test_empty_service_history_can_be_baselined(self):
        self.history.events = []
        await self.baseline()
        self.assertEqual(self.state()["cursor"], 0)
        await self.new_message(number=1)
        self.assertEqual(self.state()["pending"]["otp"], 1)

    async def test_new_otp_alert_contains_no_body_code_or_link(self):
        await self.baseline()
        await self.new_message(classify_service_text(SENTINEL))
        await self.monitor.flush_all(self.app)
        message = self.app.bot.send_message.await_args.args[1]
        self.assertIn("OTP message received", message)
        self.assertIn("ID 7777", message)
        self.assertIn("+911234567890", message)
        self.assertIn("IST", message)
        for secret in (SENTINEL, "983761", "example.invalid", "SYNTHETIC-PRIVATE-BODY"):
            self.assertNotIn(secret, message + self.a.store.path.read_text())

    async def test_generic_alert_has_only_fixed_category(self):
        await self.baseline()
        await self.new_message("unknown-private-body-is-not-an-enum")
        await self.monitor.flush_all(self.app)
        text = self.app.bot.send_message.await_args.args[1]
        self.assertIn("Telegram message received", text)
        self.assertNotIn("unknown-private", text + self.a.store.path.read_text())

    async def test_alert_is_sent_only_to_controller_not_target_uid(self):
        await self.baseline()
        await self.new_message()
        await self.monitor.flush_all(self.app)
        self.assertEqual(self.app.bot.send_message.await_args.args[0], 1234)

    async def test_alert_button_remains_bound_to_originating_account(self):
        await self.baseline()
        await self.new_message()
        b = self.rt.registry.create()
        self.rt.registry.select(b.key)
        await self.monitor.flush_all(self.app)
        keyboard = self.app.bot.send_message.await_args.kwargs["reply_markup"]
        self.assertIn("account:" + self.a.key, [x.callback_data for x in buttons(keyboard)])

    async def test_cursor_and_outbox_are_durable_before_send(self):
        await self.baseline()
        await self.new_message()
        async def deliver(*args, **kwargs):
            on_disk = json.loads(self.a.store.path.read_text())[STATE_KEY]
            self.assertEqual(on_disk["cursor"], 51)
            self.assertEqual(on_disk["pending"]["otp"], 1)
        self.app.bot.send_message.side_effect = deliver
        await self.monitor.flush_all(self.app)
        self.assertEqual(self.state()["pending"], {})

    async def test_duplicate_poll_does_not_count_or_notify_twice(self):
        await self.baseline()
        await self.new_message()
        await self.monitor.poll_account(self.a)
        self.assertEqual(self.state()["pending"]["otp"], 1)
        await self.monitor.flush_all(self.app)
        await self.monitor.poll_account(self.a)
        await self.monitor.flush_all(self.app)
        self.app.bot.send_message.assert_awaited_once()

    async def test_full_runtime_restart_retains_cursor_and_pending(self):
        await self.baseline()
        await self.new_message()
        restarted = bot.Runtime(Store(self.root))
        try:
            a = restarted.registry.get(self.a.key)
            a.sessions.me = NS(id=7777)
            a.sessions.ensure = AsyncMock(return_value=self.history)
            monitor = SecurityMonitor(restarted.registry, restarted.store, clock=lambda: self.now[0])
            await monitor.poll_account(a)
            await monitor.flush_all(self.app)
            self.app.bot.send_message.assert_awaited_once()
            self.assertEqual(alert_state(a.store.reload())["cursor"], 51)
            self.assertEqual(alert_state(a.store.reload())["pending"], {})
        finally:
            await restarted.registry.close()

    async def test_offline_new_messages_are_caught_up_after_baseline(self):
        await self.baseline()
        self.now[0] += 86400
        self.history.events += [ServiceEvent(51, self.now[0] - 800, "otp"), ServiceEvent(52, self.now[0] - 100, "message")]
        await self.monitor.poll_account(self.a)
        await self.monitor.flush_all(self.app)
        text = self.app.bot.send_message.await_args.args[1]
        self.assertIn("OTP message received", text)
        self.assertIn("Telegram message received", text)
        self.assertEqual(self.state()["cursor"], 52)

    async def test_outgoing_service_chat_message_is_not_an_arrival(self):
        await self.baseline()
        await self.new_message(outgoing=True)
        await self.monitor.flush_all(self.app)
        self.assertEqual(self.state()["cursor"], 51)
        self.app.bot.send_message.assert_not_awaited()

    async def test_burst_is_combined_as_safe_category_counts(self):
        await self.baseline()
        self.history.events += [ServiceEvent(i, self.now[0], "otp" if i % 2 else "message") for i in range(51, 57)]
        await self.monitor.poll_account(self.a)
        self.assertEqual(self.state()["pending"]["otp"], 3)
        self.assertEqual(self.state()["pending"]["message"], 3)
        await self.monitor.flush_all(self.app)
        self.app.bot.send_message.assert_awaited_once()

    async def test_large_backlog_is_paginated_and_restart_resumable(self):
        await self.baseline()
        self.history.events += [ServiceEvent(i, self.now[0], "otp") for i in range(51, 281)]
        await self.monitor.poll_account(self.a)
        self.assertEqual(self.state()["scan"]["otp"], 200)
        self.assertEqual(self.state()["cursor"], 50)
        self.assertFalse(self.state()["pending"])
        restarted = SecurityMonitor(self.rt.registry, self.controller, clock=lambda: self.now[0])
        await restarted.poll_account(self.a)
        self.assertFalse(self.state()["scan"])
        self.assertEqual(self.state()["pending"]["otp"], 230)
        self.assertEqual(self.state()["cursor"], 280)
        self.assertTrue(any(offset for offset, _ in self.history.calls))

    async def test_new_arrival_during_backlog_is_not_lost_or_double_counted(self):
        await self.baseline()
        self.history.events += [ServiceEvent(i, self.now[0], "otp") for i in range(51, 281)]
        await self.monitor.poll_account(self.a)
        self.history.events.append(ServiceEvent(281, self.now[0], "message"))
        await self.monitor.poll_account(self.a)
        self.assertEqual(self.state()["pending"]["otp"], 230)
        self.assertEqual(self.state()["cursor"], 280)
        await self.monitor.flush_all(self.app)
        await self.monitor.poll_account(self.a)
        self.assertEqual(self.state()["pending"]["message"], 1)
        self.assertEqual(self.state()["pending"]["otp"], 0)

    async def test_duplicate_ids_in_a_response_are_deduplicated(self):
        await self.baseline()
        self.history.events += [ServiceEvent(51, self.now[0], "otp")] * 3
        await self.monitor.poll_account(self.a)
        self.assertEqual(self.state()["pending"]["otp"], 1)

    async def test_deleted_old_messages_do_not_rewind_the_cursor(self):
        await self.baseline()
        self.history.events = []
        await self.monitor.poll_account(self.a)
        self.assertEqual(self.state()["cursor"], 50)

    async def test_read_failure_logs_and_persists_class_only(self):
        self.history.error = RuntimeError(SENTINEL)
        with self.assertLogs("security_alerts", level="WARNING") as logs:
            await self.baseline()
        self.assertEqual(self.state()["error"], "RuntimeError")
        self.assertNotIn(SENTINEL, str(logs.output) + self.a.store.path.read_text())
        self.assertNotIn("983761", str(logs.output) + self.a.store.path.read_text())

    async def test_read_retry_does_not_fetch_early(self):
        self.history.error = TimeoutError(SENTINEL)
        await self.baseline()
        calls = len(self.history.calls)
        self.now[0] += 30
        await self.baseline()
        self.assertEqual(len(self.history.calls), calls)
        self.history.error = None
        self.now[0] += 31
        await self.baseline()
        self.assertTrue(self.state()["initialized"])
        self.assertEqual(self.state()["error"], "")

    async def test_telegram_flood_wait_is_respected(self):
        FloodWaitError = type("FloodWaitError", (Exception,), {})
        error = FloodWaitError(SENTINEL)
        error.seconds = 900
        self.history.error = error
        await self.baseline()
        self.assertEqual(self.state()["retry_at"], self.now[0] + 901)

    async def test_attention_notice_is_controlled_and_deduplicated(self):
        self.history.error = RuntimeError(SENTINEL)
        await self.baseline()
        await self.monitor.flush_all(self.app)
        await self.monitor.flush_all(self.app)
        self.app.bot.send_message.assert_awaited_once()
        text = self.app.bot.send_message.await_args.args[1]
        self.assertIn("NEED ATTENTION", text)
        self.assertNotIn("983761", text)
        self.assertNotIn("example.invalid", text)

    async def test_delivery_failure_retains_safe_outbox_and_retries(self):
        await self.baseline()
        await self.new_message()
        self.app.bot.send_message.side_effect = TimeoutError(SENTINEL)
        await self.monitor.flush_all(self.app)
        self.assertEqual(self.state()["pending"]["otp"], 1)
        self.assertEqual(self.state()["delivery_error"], "TimeoutError")
        self.assertEqual(self.state()["error"], "")
        await self.monitor.flush_all(self.app)
        self.assertEqual(self.app.bot.send_message.await_count, 1)
        self.now[0] += 61
        self.app.bot.send_message.side_effect = None
        await self.monitor.flush_all(self.app)
        self.assertEqual(self.app.bot.send_message.await_count, 2)
        self.assertFalse(self.state()["pending"])
        self.assertEqual(self.state()["delivery_error"], "")

    async def test_delivery_backoff_does_not_pause_reading(self):
        await self.baseline()
        await self.new_message()
        self.app.bot.send_message.side_effect = TimeoutError(SENTINEL)
        await self.monitor.flush_all(self.app)
        await self.new_message("message", number=52)
        self.assertEqual(self.state()["pending"]["message"], 1)
        self.assertEqual(self.state()["pending"]["otp"], 1)
        self.assertIn("delivery", alert_status(self.a.store.reload()))

    async def test_wrong_session_uid_is_rejected_without_history_read(self):
        self.a.sessions.me = NS(id=8888)
        await self.baseline()
        self.assertEqual(self.history.calls, [])
        self.assertEqual(self.state()["error"], "SafeError")
        self.assertFalse(self.state()["initialized"])

    async def test_unverified_import_can_monitor_without_phone_prompt(self):
        self.a.store.update(registered=False, account_user_id=0, owner_phone="", detected_phone="+911234567890")
        await self.baseline()
        await self.new_message()
        self.assertTrue(self.state()["initialized"])
        self.assertEqual(self.state()["pending"]["otp"], 1)
        self.assertFalse(self.a.store.reload()["registered"])

    async def test_session_manager_pins_detected_uid_before_phone_verification(self):
        self.a.store.update(account_user_id=0, detected_user_id=7777, registered=False)
        self.a.sessions.ensure = self.a.sessions.__class__.ensure.__get__(self.a.sessions)
        self.a.sessions.me = None
        fake = NS(connect=AsyncMock(return_value=NS(id=8888, phone="911234567890")), close=AsyncMock())
        with patch.object(self.a.sessions, "checked_path", return_value=Path("fake.session")), \
             patch.object(self.a.sessions, "_runtime_copy", return_value=Path("fake.session")), \
             patch("sessions.TelethonAdapter", return_value=fake):
            with self.assertRaises(SafeError):
                await self.a.sessions.ensure()
        self.assertEqual(self.a.store.reload()["detected_user_id"], 7777)
        self.assertIsNone(self.a.sessions.adapter)

    async def test_empty_profile_never_connects(self):
        self.a.store.update(account_user_id=0, detected_user_id=0, session_name="")
        await self.baseline()
        self.a.sessions.ensure.assert_not_awaited()

    async def test_master_off_skips_reads_and_delivery(self):
        await self.baseline()
        await self.new_message()
        count = len(self.history.calls)
        self.controller.update(**{ENABLED_KEY: False})
        await self.monitor.poll_all()
        await self.monitor.flush_all(self.app)
        self.assertEqual(len(self.history.calls), count)
        self.app.bot.send_message.assert_not_awaited()

    async def test_account_off_does_not_affect_other_account(self):
        b = self.rt.registry.create()
        other = self.attach(b, 8888)
        await self.monitor.set_enabled(self.a.key, False)
        await self.monitor.poll_all()
        self.assertEqual(self.history.calls, [])
        self.assertTrue(other.calls)
        self.assertFalse(self.state()["initialized"])
        self.assertTrue(self.state(b)["initialized"])

    async def test_off_then_on_sets_new_baseline_not_old_replay(self):
        await self.baseline()
        await self.monitor.set_enabled(self.a.key, False)
        self.history.events.append(ServiceEvent(51, self.now[0], "otp"))
        await self.monitor.set_enabled(self.a.key, True)
        await self.monitor.poll_account(self.a)
        await self.monitor.flush_all(self.app)
        self.assertEqual(self.state()["cursor"], 51)
        self.app.bot.send_message.assert_not_awaited()

    async def test_idempotent_enable_preserves_pending_and_cursor(self):
        await self.baseline()
        await self.new_message()
        before = self.state()
        await self.monitor.set_enabled(self.a.key, True)
        await self.monitor.set_all(True)
        self.assertEqual(self.state(), before)

    async def test_disable_all_and_future_imports_respect_master_switch(self):
        await self.monitor.set_all(False)
        b = self.rt.registry.create()
        self.attach(b, 8888)
        await self.monitor.poll_all()
        b.sessions.ensure.assert_not_awaited()
        self.assertFalse(self.controller.reload()[ENABLED_KEY])
        await self.monitor.set_all(True)
        await self.monitor.poll_all()
        self.assertTrue(self.state(b)["initialized"])

    async def test_bad_account_is_isolated_from_healthy_accounts(self):
        b = self.rt.registry.create()
        self.attach(b, 8888)
        self.a.store.update(**{STATE_KEY: {"unexpected": SENTINEL}})
        await self.monitor.poll_all()
        self.assertTrue(self.state(b)["initialized"])

    async def test_all_monitor_work_preserves_existing_waiting_job(self):
        self.a.store.update(reset_status="waiting", phase="waiting", wait_kind="reset",
                             reset_started_at=self.now[0] - 86400, reset_until_date=self.now[0] + 6 * 86400,
                             next_attempt_at=self.now[0] + 6 * 86400, pending_new_password="cipher-to-keep",
                             pending_hint="hint-to-keep", password_apply_status="not_started")
        before = self.core()
        await self.baseline()
        await self.new_message()
        await self.monitor.flush_all(self.app)
        await self.monitor.set_enabled(self.a.key, False)
        await self.monitor.set_all(True)
        self.assertEqual(self.core(), before)

    async def test_monitor_waits_on_same_account_operation_lock(self):
        async with self.a.engine.lock:
            task = asyncio.create_task(self.monitor.poll_account(self.a))
            await asyncio.sleep(0)
            self.a.sessions.ensure.assert_not_awaited()
        await task
        self.a.sessions.ensure.assert_awaited_once()

    async def test_slow_account_cannot_block_another_account_worker(self):
        b = self.rt.registry.create()
        self.attach(b, 8888)
        slow, healthy = asyncio.Event(), asyncio.Event()
        async def flush(account, app):
            if account.key == self.a.key:
                await slow.wait()
            else:
                healthy.set()
        # Idle workers skip the timer poll; the always-on flush proves isolation.
        with patch.object(self.monitor, "poll_account", AsyncMock()), \
             patch.object(self.monitor, "flush_account", side_effect=flush):
            task = asyncio.create_task(self.monitor.worker(self.app))
            try:
                await asyncio.wait_for(healthy.wait(), 1)
            finally:
                task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await task
        self.assertFalse(any(t.get_name() == "security-alert-account" and not t.done() for t in asyncio.all_tasks()))

    async def test_supervisor_restarts_cancelled_child_without_stopping_other_accounts(self):
        with patch("security_alerts.DISCOVERY_INTERVAL", 0.01):
            task = asyncio.create_task(self.monitor.worker(self.app))
            try:
                await asyncio.sleep(0.03)
                child = next(t for t in asyncio.all_tasks() if t.get_name() == "security-alert-account" and not t.done())
                child.cancel()
                await asyncio.sleep(0.04)
                self.assertFalse(task.done())
                self.assertTrue(any(t is not child and t.get_name() == "security-alert-account" and not t.done()
                                    for t in asyncio.all_tasks()))
            finally:
                task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await task

    async def test_removed_account_worker_is_cancelled_and_joined(self):
        b = self.rt.registry.create()
        self.attach(b, 8888)
        with patch("security_alerts.DISCOVERY_INTERVAL", 0.01):
            task = asyncio.create_task(self.monitor.worker(self.app))
            try:
                await asyncio.sleep(0.03)
                await self.rt.registry.remove(b.key)
                await asyncio.sleep(0.04)
                children = [t for t in asyncio.all_tasks() if t.get_name() == "security-alert-account" and not t.done()]
                self.assertEqual(len(children), 1)
                self.assertFalse(task.done())
            finally:
                task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await task
        self.assertFalse(any(t.get_name() == "security-alert-account" and not t.done() for t in asyncio.all_tasks()))

    async def test_cancelled_initial_connection_closes_local_adapter(self):
        self.a.sessions.ensure = self.a.sessions.__class__.ensure.__get__(self.a.sessions)
        self.a.sessions.me = None
        connecting = asyncio.Event()
        async def connect(*args):
            connecting.set()
            await asyncio.Event().wait()
        fake = NS(connect=AsyncMock(side_effect=connect), close=AsyncMock())
        with patch.object(self.a.sessions, "checked_path", return_value=Path("fake.session")), \
             patch.object(self.a.sessions, "_runtime_copy", return_value=Path("fake.session")), \
             patch("sessions.TelethonAdapter", return_value=fake):
            task = asyncio.create_task(self.a.sessions.ensure())
            await asyncio.wait_for(connecting.wait(), 1)
            task.cancel()
            with self.assertRaises(asyncio.CancelledError):
                await task
        fake.close.assert_awaited_once()
        self.assertIsNone(self.a.sessions.adapter)

    async def test_cancellation_is_not_swallowed_or_saved_as_error(self):
        self.history.error = asyncio.CancelledError()
        with self.assertRaises(asyncio.CancelledError):
            await self.baseline()
        self.assertEqual(self.state()["error"], "")

    async def test_has_pending_uses_only_categories_or_controlled_attention(self):
        self.assertFalse(self.monitor.has_pending())
        await self.baseline()
        await self.new_message()
        self.assertTrue(self.monitor.has_pending())
        await self.monitor.flush_all(self.app)
        self.assertFalse(self.monitor.has_pending())

    async def test_alert_settings_ui_is_read_only_and_has_bound_buttons(self):
        self.a.sessions.ensure.reset_mock()
        before = self.a.store.path.read_bytes()
        text, keyboard = alerts_screen(self.rt.registry, self.controller, key=self.a.key)
        self.assertIn("TELEGRAM SECURITY ALERTS", text)
        self.assertIn(f"acct:{self.a.key}:alerts_off", [x.callback_data for x in buttons(keyboard)])
        self.a.sessions.ensure.assert_not_awaited()
        self.assertEqual(self.a.store.path.read_bytes(), before)

    async def test_alerts_command_denies_other_users_and_groups_exactly(self):
        for event in (update(uid=8888), update(kind="group")):
            await bot.alerts_command(event, context(self.rt))
            self.assertEqual(event.effective_message.reply_text.await_args.args[0], "Access denied.")
        self.a.sessions.ensure.assert_not_awaited()

    async def test_unauthorized_callback_cannot_disable_any_account(self):
        event = update(uid=8888, action="alerts:all_off")
        await bot.callback(event, context(self.rt))
        event.callback_query.answer.assert_awaited_once_with("Access denied.", show_alert=True)
        self.assertTrue(self.controller.reload()[ENABLED_KEY])

    async def test_owner_callback_can_disable_all_without_questionnaire(self):
        event = update(action="alerts:all_off")
        await bot.callback(event, context(self.rt))
        self.assertFalse(self.controller.reload()[ENABLED_KEY])
        self.assertFalse(self.a.store.reload()[ENABLED_KEY])
        self.a.sessions.ensure.assert_not_awaited()

    async def test_account_callback_affects_named_account_not_selected_one(self):
        b = self.rt.registry.create()
        self.attach(b, 8888)
        self.rt.registry.select(b.key)
        await bot.callback(update(action=f"acct:{self.a.key}:alerts_off"), context(self.rt))
        self.assertFalse(self.a.store.reload()[ENABLED_KEY])
        self.assertTrue(b.store.reload()[ENABLED_KEY])
        self.assertEqual(self.rt.registry.active_key, b.key)

    async def test_removed_account_alert_callback_fails_closed(self):
        b = self.rt.registry.create()
        key = b.key
        await self.rt.registry.remove(key)
        with self.assertRaises(SafeError):
            await bot.callback(update(action=f"acct:{key}:alerts_off"), context(self.rt))
        self.assertTrue(self.a.store.reload()[ENABLED_KEY])

    async def test_settings_list_is_paginated_and_never_contacts_sessions(self):
        for _ in range(6):
            self.rt.registry.create()
        text, keyboard = alerts_screen(self.rt.registry, self.controller)
        self.assertLess(len(text), 3500)
        self.assertIn("alerts:page:1", [x.callback_data for x in buttons(keyboard)])
        self.a.sessions.ensure.assert_not_awaited()

    async def test_on_startup_and_stop_manage_both_workers(self):
        app = context(self.rt).application
        app.bot.get_webhook_info = AsyncMock(return_value=NS(url=""))
        app.bot.set_my_commands = AsyncMock()
        async def forever(*args):
            await asyncio.Event().wait()
        with patch.object(self.rt, "worker", side_effect=forever), \
             patch.object(self.rt.security, "worker", side_effect=forever):
            await bot.on_startup(app)
            await asyncio.sleep(0)
            self.assertIsNotNone(self.rt.task)
            self.assertIsNotNone(self.rt.security_task)
            self.assertNotEqual(self.rt.task, self.rt.security_task)
            self.assertIn("alerts", [x.command for x in app.bot.set_my_commands.await_args.args[0]])
            await bot.on_stop(app)
            self.assertTrue(self.rt.task.done())
            self.assertTrue(self.rt.security_task.done())
        self.assertEqual(self.controller.reload()["scheduler_interval_seconds"], 3600)


class AdapterTests(unittest.IsolatedAsyncioTestCase):
    async def test_telethon_adapter_reads_only_official_peer_and_discards_body(self):
        adapter = TelethonAdapter()
        date = datetime(2026, 11, 21, 7, tzinfo=timezone.utc)
        messages = [NS(id=51, chat_id=SERVICE_USER_ID, message=SENTINEL, date=date, out=False),
                    NS(id=52, chat_id=9999, message=SENTINEL, date=date, out=False)]
        adapter.client = NS(get_messages=AsyncMock(return_value=messages))
        events = await adapter.service_messages(offset_id=60, limit=50)
        adapter.client.get_messages.assert_awaited_once_with(777000, limit=50, offset_id=60)
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0].kind, "otp")
        self.assertNotIn("983761", repr(events))
        self.assertNotIn("example.invalid", repr(events))

    async def test_telethon_unknown_peer_fallback_is_still_only_777000(self):
        adapter = TelethonAdapter()
        adapter.client = NS(get_messages=AsyncMock(side_effect=[ValueError(SENTINEL), []]))
        self.assertEqual(await adapter.service_messages(), [])
        peer = adapter.client.get_messages.await_args.args[0]
        self.assertEqual(peer.user_id, 777000)
        self.assertEqual(peer.access_hash, 0)

    async def test_pyrogram_adapter_reads_only_official_peer_and_discards_body(self):
        adapter = PyrogramAdapter()
        calls = []
        async def history(chat_id, **kwargs):
            calls.append((chat_id, kwargs))
            for peer, text in ((SERVICE_USER_ID, SENTINEL), (9999, SENTINEL)):
                yield NS(id=51, chat=NS(id=peer), text=text, caption=None, date=1800000000, outgoing=False)
        adapter.client = NS(get_chat_history=history)
        events = await adapter.service_messages(offset_id=60, limit=50)
        self.assertEqual(calls, [(777000, {"offset_id": 60, "limit": 50})])
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0].kind, "otp")
        self.assertNotIn("983761", repr(events))
        self.assertNotIn("example.invalid", repr(events))

    async def test_pyrogram_outgoing_and_caption_are_metadata_only(self):
        adapter = PyrogramAdapter()
        async def history(*args, **kwargs):
            yield NS(id=51, chat=NS(id=SERVICE_USER_ID), text=None, caption=SENTINEL, date=1800000000, outgoing=True)
        adapter.client = NS(get_chat_history=history)
        event = (await adapter.service_messages())[0]
        self.assertTrue(event.outgoing)
        self.assertEqual(event.kind, "otp")
        self.assertNotIn("983761", repr(event))


if __name__ == "__main__":
    unittest.main()
