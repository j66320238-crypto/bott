"""Universal password, live-session verify, pinned completion, and session-safe errors."""
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock

import bot
from recovery import RecoveryEngine
from sessions import PasswordInfo, account_identity, public_error
from storage import Store
from ui_state import pin_owner_message


class FreshResetAuthorisationForbiddenError(Exception):
    pass


class UniversalTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.store = Store(self.root)
        self.store.update(owner_id=1234, api_id=12345, api_hash="a" * 32)
        self.rt = bot.Runtime(self.store)
        self.account = self.rt.current
        self.account.store.update(registered=True, account_user_id=7777, detected_user_id=7777,
                                   owner_phone="+911234567890", label="Account 1",
                                   session_name="sessions/fake.session")
        self.ctx = NS(application=NS(bot_data={"runtime": self.rt},
                                      bot=NS(send_message=AsyncMock(), pin_chat_message=AsyncMock())),
                      user_data={})

    async def asyncTearDown(self):
        await self.rt.registry.close()
        self.temp.cleanup()

    def message(self, text=""):
        return NS(effective_user=NS(id=1234), effective_chat=NS(type="private"),
                  effective_message=NS(text=text, reply_text=AsyncMock(), delete=AsyncMock()),
                  callback_query=None)

    async def test_saved_universal_password_is_encrypted_and_not_echoed(self):
        secret = "universal-password-value"
        await bot.universal_set_action(self.message(), self.ctx)
        first = self.message(secret)
        await bot.text_input(first, self.ctx)
        second = self.message(secret)
        await bot.text_input(second, self.ctx)
        saved = self.store.reload()["universal_password"]
        self.assertTrue(saved.startswith("fernet:"))
        self.assertNotIn(secret, self.store.path.read_text())
        self.assertIsNone(self.ctx.user_data.get("flow"))
        for call in first.effective_message.reply_text.await_args_list + second.effective_message.reply_text.await_args_list:
            self.assertNotIn(secret, call.args[0])

    async def test_reset_uses_universal_password_without_typing_it_again(self):
        secret = "universal-password-value"
        self.store.update(universal_password=self.rt.vault.seal(secret))
        self.account.sessions.ensure = AsyncMock()
        self.account.engine.start = AsyncMock()
        update = self.message()
        await bot.begin_reset(update, self.ctx)
        card = update.effective_message.reply_text.await_args.args[0]
        self.assertIn("+911234567890", card)
        self.assertIn("7777", card)
        self.assertIn("universal password", card)
        self.assertNotIn(secret, card)
        self.assertEqual(self.ctx.user_data["flow"], "confirm")
        self.account.engine.start.assert_not_awaited()
        nonce = self.ctx.user_data["draft"]["nonce"]
        pressed = self.message()
        pressed.callback_query = NS(data="begin:" + nonce, answer=AsyncMock(), edit_message_text=AsyncMock())
        await bot.callback(pressed, self.ctx)
        self.account.engine.start.assert_awaited_once()
        encrypted, hint = self.account.engine.start.await_args.args[:2]
        self.assertEqual(self.rt.vault.open(encrypted), secret)
        self.assertEqual(hint, "")
        self.assertFalse(self.account.engine.start.await_args.kwargs.get("set_only"))
        shown = pressed.effective_message.reply_text.await_args.args[0]
        self.assertNotIn(secret, shown)

    async def test_completion_notice_is_pinned_and_has_no_password(self):
        secret = "saved-password-not-for-chat"
        self.account.store.update(reset_status="waiting", phase="old_removed", password_action="reset",
                                   pending_new_password=self.rt.vault.seal(secret), pending_hint="")
        adapter = NS(info=AsyncMock(return_value=PasswordInfo(False)), set_password=AsyncMock(return_value=True))
        engine = RecoveryEngine(self.account.store, NS(ensure=AsyncMock(return_value=adapter)), self.rt.vault, lambda: 1000)
        await engine._apply(adapter)
        notice = self.account.store.reload()["notices"][0]
        self.assertTrue(notice.startswith("PIN\n"))
        self.assertIn("PASSWORD RESET DONE", notice)
        self.assertIn("+911234567890", notice)
        self.assertIn("7777", notice)
        self.assertNotIn(secret, notice)
        sent = NS(message_id=42)
        self.ctx.application.bot.send_message = AsyncMock(return_value=sent)
        await self.rt.flush(self.ctx.application)
        body = self.ctx.application.bot.send_message.await_args.args[1]
        self.assertNotIn("PIN\n", body)
        self.assertIn("PASSWORD RESET DONE", body)
        self.assertNotIn(secret, body)
        self.ctx.application.bot.pin_chat_message.assert_awaited_once()
        self.assertEqual(self.account.store.reload()["notices"], [])

    async def test_pin_failure_still_delivers_the_done_message(self):
        self.account.store.queue("PIN\nPASSWORD RESET DONE\nPhone: +911234567890")
        self.ctx.application.bot.send_message = AsyncMock(return_value=NS(message_id=7))
        self.ctx.application.bot.pin_chat_message = AsyncMock(side_effect=TimeoutError("pin denied"))
        await self.rt.flush(self.ctx.application)
        self.assertEqual(self.account.store.reload()["notices"], [])
        self.ctx.application.bot.send_message.assert_awaited()

    def test_fresh_session_error_keeps_the_current_session(self):
        text = public_error(FreshResetAuthorisationForbiddenError())
        self.assertIn("not logged out", text)
        self.assertIn("24 hours", text)

    async def test_pin_helper_ignores_a_non_integer_message_id(self):
        api = NS(pin_chat_message=AsyncMock())
        self.assertFalse(await pin_owner_message(api, 1, NS(message_id="nope")))
        api.pin_chat_message.assert_not_awaited()

    def test_identity_never_includes_a_saved_password(self):
        text = account_identity({"owner_phone": "+911234567890", "account_user_id": 7777, "label": "Account 1",
                                  "pending_new_password": "fernet:secret"})
        self.assertNotIn("fernet", text)
        self.assertIn("7777", text)
