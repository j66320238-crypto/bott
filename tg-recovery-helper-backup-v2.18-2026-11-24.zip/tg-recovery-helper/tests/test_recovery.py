"""Offline tests only. No real reset, account, bot token, or session is used."""
import asyncio
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from bot import owner_allowed
from recovery import RecoveryEngine
from sessions import PasswordInfo, ResetResult, SessionManager, convert_reset, public_error
from storage import SafeError, Store, Vault


class FakeAdapter:
    def __init__(self):
        self.password = True
        self.pending = 0
        self.result = ResetResult("wait", 2000)
        self.reset_calls = 0
        self.set_calls = 0
        self.decline_calls = 0
        self.set_error = None
        self.decline_error = None
        self.reset_error = None

    async def info(self):
        return PasswordInfo(self.password, False, "", self.pending)

    async def reset(self):
        self.reset_calls += 1
        if self.reset_error: raise self.reset_error
        if self.result.kind == "ok": self.password, self.pending = False, 0
        elif self.result.kind == "wait": self.pending = self.result.date
        return self.result

    async def set_password(self, password, hint):
        self.set_calls += 1
        if self.set_error: raise self.set_error
        self.password = True
        return True

    async def decline(self):
        self.decline_calls += 1
        if self.decline_error: raise self.decline_error
        self.pending = 0
        return True

    async def spamcheck(self):
        return "No limits."


class FakeSessions:
    def __init__(self, adapter): self.adapter = adapter
    async def ensure(self): return self.adapter


class EngineTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.store = Store(self.root)
        self.store.update(owner_id=1234, account_user_id=1234, registered=True, owner_phone="+911234567890")
        self.vault = Vault(self.root)
        self.adapter = FakeAdapter()
        self.now = 1000
        self.engine = RecoveryEngine(self.store, FakeSessions(self.adapter), self.vault, lambda: self.now)
        self.secret = self.vault.seal("unique-password-for-test")

    async def asyncTearDown(self): self.temp.cleanup()

    async def start_wait(self):
        await self.engine.start(self.secret, "safe hint")

    async def test_wait_saves_exact_telegram_date_and_no_plaintext(self):
        await self.start_wait()
        self.assertEqual(self.store.data["reset_until_date"], 2000)
        self.assertEqual(self.store.data["reset_status"], "waiting")
        self.assertNotIn("unique-password-for-test", self.store.path.read_text())
        self.assertTrue(self.store.data["pending_new_password"].startswith("fernet:"))

    async def test_repeated_command_does_not_restart_timer(self):
        await self.start_wait()
        with self.assertRaises(SafeError): await self.engine.start(self.secret, "")
        self.assertEqual(self.adapter.reset_calls, 1)

    async def test_manual_check_before_due_never_calls_reset(self):
        await self.start_wait()
        self.now = 1999
        await self.engine.tick(manual=True)
        self.assertEqual(self.adapter.reset_calls, 1)
        self.assertEqual(self.adapter.set_calls, 0)

    async def test_restart_due_finishes_then_clears_secret(self):
        await self.start_wait()
        self.now = 2001
        self.adapter.result = ResetResult("ok")
        # A new store/vault/engine represents a completely restarted process.
        fresh = Store(self.root)
        resumed = RecoveryEngine(fresh, FakeSessions(self.adapter), Vault(self.root), lambda: self.now)
        await resumed.tick()
        self.assertEqual(fresh.data["reset_status"], "done")
        self.assertEqual(fresh.data["password_apply_status"], "applied")
        self.assertEqual(fresh.data["pending_new_password"], "")
        self.assertEqual(self.adapter.set_calls, 1)

    async def test_cooldown_is_not_reported_as_started_timer(self):
        self.adapter.result = ResetResult("cooldown", 1800)
        await self.start_wait()
        self.assertEqual(self.store.data["wait_kind"], "cooldown")
        self.assertEqual(self.store.data["reset_until_date"], 0)
        self.assertIn("NOT started", self.engine.summary())
        self.now = 1799
        await self.engine.tick(manual=True)
        self.assertEqual(self.adapter.reset_calls, 1)
        self.now = 1801
        self.adapter.result = ResetResult("wait", 800000)
        await self.engine.tick()
        self.assertEqual(self.store.data["reset_until_date"], 800000)
        self.assertEqual(self.adapter.set_calls, 0)

    async def test_external_cancellation_requests_a_new_wait(self):
        # v2.11+ reports an externally stopped reset and requests a new official wait.
        await self.start_wait()
        self.adapter.pending = 0
        self.now = 2001
        await self.engine.tick()
        self.assertEqual(self.store.data["reset_status"], "waiting")
        self.assertEqual(self.adapter.reset_calls, 2)
        self.assertTrue(self.store.data["pending_new_password"].startswith("fernet:"))

    async def test_crash_during_apply_with_2fa_on_does_not_reset_again(self):
        self.store.update(reset_status="waiting", phase="applying", pending_new_password=self.secret)
        self.adapter.password = True
        await self.engine.tick()
        self.assertEqual(self.adapter.reset_calls, 0)
        self.assertEqual(self.adapter.set_calls, 0)
        self.assertEqual(self.store.data["password_apply_status"], "enabled_unconfirmed")

    async def test_missing_key_pauses_before_reset(self):
        await self.start_wait()
        (self.root / ".secret.key").unlink()
        self.now = 2001
        await self.engine.tick()
        self.assertEqual(self.adapter.reset_calls, 1)
        self.assertEqual(self.store.data["reset_status"], "waiting")
        self.assertTrue(self.store.data["pending_new_password"])

    async def test_apply_network_failure_is_not_marked_done(self):
        await self.start_wait()
        self.now = 2001
        self.adapter.result = ResetResult("ok")
        self.adapter.set_error = TimeoutError("secret must not appear")
        await self.engine.tick()
        self.assertEqual(self.store.data["reset_status"], "waiting")
        self.assertEqual(self.store.data["phase"], "applying")
        self.assertNotIn("secret must not appear", json.dumps(self.store.data))
        self.adapter.set_error = None
        self.now += 3601
        await self.engine.tick()
        self.assertEqual(self.store.data["reset_status"], "done")
        self.assertEqual(self.adapter.reset_calls, 2)  # initial + official finish, no third reset

    async def test_cancel_failure_preserves_active_job(self):
        await self.start_wait()
        self.adapter.decline_error = TimeoutError("no response")
        with self.assertRaises(SafeError): await self.engine.cancel()
        self.assertEqual(self.store.data["reset_status"], "waiting")
        self.assertTrue(self.store.data["pending_new_password"])

    async def test_cancel_calls_official_decline_then_clears_secret(self):
        await self.start_wait()
        await self.engine.cancel()
        self.assertEqual(self.adapter.decline_calls, 1)
        self.assertEqual(self.store.data["reset_status"], "cancelled")
        self.assertEqual(self.store.data["pending_new_password"], "")

    async def test_idle_startup_does_not_initiate_reset(self):
        await self.engine.tick()
        self.assertEqual(self.adapter.reset_calls, 0)

    async def test_set_only_refuses_existing_password(self):
        with self.assertRaises(SafeError): await self.engine.start(self.secret, "", set_only=True)
        self.assertEqual(self.adapter.reset_calls, 0)
        self.assertEqual(self.adapter.set_calls, 0)

    async def test_no_existing_2fa_sets_password_without_reset(self):
        self.adapter.password = False
        await self.engine.start(self.secret, "", set_only=True)
        self.assertEqual(self.adapter.reset_calls, 0)
        self.assertEqual(self.adapter.set_calls, 1)

    async def test_phone_registration_required_before_mutation(self):
        self.store.update(registered=False)
        with self.assertRaises(SafeError): await self.start_wait()
        self.assertEqual(self.adapter.reset_calls, 0)

    async def test_spambot_one_request_and_rate_limit(self):
        result = await self.engine.spamcheck()
        self.assertEqual(result, "No limits.")
        with self.assertRaises(SafeError): await self.engine.spamcheck()

    async def test_cancel_false_response_does_not_clear_job(self):
        from unittest.mock import AsyncMock
        await self.start_wait()
        with patch.object(self.adapter, "decline", AsyncMock(return_value=False)):
            with self.assertRaises(SafeError):
                await self.engine.cancel()
        self.assertEqual(self.store.data["reset_status"], "waiting")
        self.assertTrue(self.store.data["pending_new_password"])


class StorageTests(unittest.TestCase):
    def test_corrupt_json_fails_closed(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "config.json").write_text("{broken")
            with self.assertRaises(SafeError): Store(root)

    def test_vault_round_trip_and_wrong_key(self):
        with tempfile.TemporaryDirectory() as tmp:
            vault = Vault(Path(tmp))
            encrypted = vault.seal("not-plaintext-on-disk")
            self.assertEqual(vault.open(encrypted), "not-plaintext-on-disk")
            (Path(tmp) / ".secret.key").unlink()
            with self.assertRaises(SafeError): vault.open(encrypted)

    def test_atomic_update_keeps_previous_fields(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = Store(Path(tmp))
            store.update(owner_id=123)
            store.update(phase="waiting")
            self.assertEqual(Store(Path(tmp)).data["owner_id"], 123)

    def test_error_messages_do_not_echo_exception(self):
        self.assertNotIn("SENSITIVE_TOKEN", public_error(RuntimeError("SENSITIVE_TOKEN")))


class OwnershipTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.store = Store(self.root)
        self.store.update(owner_id=1234, api_id=12345, api_hash="a" * 32)
        self.manager = SessionManager(self.store)
        db = sqlite3.connect(self.root / "mine.session")
        db.execute("CREATE TABLE sessions (dc_id INTEGER)")
        db.commit(); db.close()

    async def asyncTearDown(self):
        await self.manager.close()
        self.temp.cleanup()

    async def test_wrong_session_id_rejected_before_any_recovery(self):
        self.store.update(account_user_id=1234)
        class WrongAdapter:
            async def connect(self, *args): return SimpleNamespace(id=9999, bot=False)
            async def close(self): pass
        with patch("sessions.TelethonAdapter", WrongAdapter):
            with self.assertRaisesRegex(SafeError, "does not match"):
                await self.manager.ensure()
        self.assertEqual(self.store.data["reset_status"], "idle")
        self.assertIsNone(self.manager.adapter)

    async def test_format_fallback_telethon_then_pyrogram(self):
        calls = []
        class WrongFormat:
            async def connect(self, *args):
                calls.append("telethon")
                raise sqlite3.OperationalError("no such column: version")
            async def close(self): pass
        class RightFormat:
            async def connect(self, *args):
                calls.append("pyrogram")
                return SimpleNamespace(id=1234, phone_number="911234567890", is_bot=False)
            async def close(self): pass
        with patch("sessions.TelethonAdapter", WrongFormat), patch("sessions.PyrogramAdapter", RightFormat):
            await self.manager.ensure()
        self.assertEqual(calls, ["telethon", "pyrogram"])
        self.assertEqual(self.store.data["library"], "pyrogram")

    async def test_phone_mismatch_rejected(self):
        self.manager.adapter = object()
        self.manager.me = SimpleNamespace(id=1234, phone="911234567890")
        with self.assertRaisesRegex(SafeError, "Phone mismatch"):
            await self.manager.verify_phone("+919999999999")
        self.assertFalse(self.store.data["registered"])
        self.manager.adapter = None

    async def test_non_database_session_rejected(self):
        (self.root / "bad.session").write_text("This is not SQLite")
        with self.assertRaises(SafeError): self.manager.checked_path("bad.session")

    async def test_path_traversal_rejected(self):
        with self.assertRaises(SafeError): self.manager.checked_path("../not-mine.session")

    async def test_private_owner_guard(self):
        self.assertTrue(owner_allowed(1234, "private", 1234))
        self.assertFalse(owner_allowed(9999, "private", 1234))
        self.assertFalse(owner_allowed(1234, "group", 1234))
        self.assertFalse(owner_allowed(0, "private", 0))


class ScheduledCliTests(unittest.TestCase):
    def test_run_once_idle_never_contacts_an_account(self):
        import bot
        import contextlib
        import io
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            store = Store(root)
            store.update(owner_id=1234, api_id=12345, api_hash="a" * 32,
                         bot_token="123456:" + "x" * 35)
            with patch("bot.ROOT", root), patch("sys.argv", ["bot.py", "--run-once"]), contextlib.redirect_stdout(io.StringIO()):
                bot.main()
            self.assertEqual(Store(root).data["reset_status"], "idle")
            self.assertEqual(Store(root).data["notices"], [])

    def test_run_once_yields_to_running_bot(self):
        import bot
        import contextlib
        import io
        from storage import ProcessLock
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            Store(root)
            output = io.StringIO()
            with ProcessLock(root / "bot.lock"):
                with patch("bot.ROOT", root), patch("sys.argv", ["bot.py", "--run-once"]), contextlib.redirect_stdout(output):
                    bot.main()
            self.assertIn("already owns scheduled checks", output.getvalue())


if __name__ == "__main__":
    unittest.main()
