import os,sys,json,fcntl,shutil,time,hashlib,subprocess,re
from pathlib import Path
root=Path('/home/tgidsellerindian/tg-recovery-helper'); stage=Path('/home/tgidsellerindian/tg-recovery-helper/.upgrade-myids-6c697a79'); names=['bot.py', 'accounts.py', 'sessions.py', 'recovery.py', 'storage.py', 'ingest.py', 'ui_state.py', 'manage.py', 'dashboard.py', 'requirements.txt', 'README.md', 'DEPLOYMENT.md', 'run.sh', '.gitignore', 'tests/test_recovery.py', 'tests/test_accounts.py', 'tests/test_easy_flow.py', 'tests/test_dashboard.py']
python=str(root/'.venv/bin/python')
job_fields=('account_user_id','detected_user_id','owner_phone','registered','session_name','library','reset_status','phase','wait_kind','reset_started_at','reset_until_date','retry_at','next_attempt_at','pending_new_password','pending_hint','password_apply_status')
identity_fields=('owner_id','bot_token','api_id','api_hash','profiles','active_account','owner_ui_state')
def digest(value): return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def fingerprints(d):
 result={'controller':digest({k:d.get(k) for k in identity_fields}),'jobs':{}}
 for key in d.get('profiles',[]):
  if not re.fullmatch(r'(main|[a-f0-9]{12})',key): raise RuntimeError('Invalid profile key')
  a=json.loads((root/'accounts'/key/'config.json').read_text())
  result['jobs'][key]=digest({k:a.get(k) for k in job_fields})
 result['key']=hashlib.sha256((root/'.secret.key').read_bytes()).hexdigest() if (root/'.secret.key').exists() else None
 return result
backup=None
try:
 with (root/'bot.lock').open('a+b') as guard:
  try: fcntl.flock(guard.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
  except BlockingIOError: raise RuntimeError('Active process still holds lock; no code replaced')
  d=json.loads((root/'config.json').read_text())
  before=fingerprints(d)
  backup=root/'.backups'/('before-2.2-'+str(int(time.time())))
  backup.mkdir(mode=0o700)
  sensitive=['config.json','.secret.key']+['accounts/'+k+'/config.json' for k in d.get('profiles',[])]
  for name in names+sensitive:
   src=root/name
   if src.is_file():
    dest=backup/name; dest.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
    shutil.copy2(src,dest); dest.chmod(0o600)
  (backup/'preservation.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n'); (backup/'preservation.json').chmod(0o600)
  replaced=[]
  try:
   for name in names:
    dest=root/name; dest.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
    os.replace(stage/name,dest); dest.chmod(0o700 if name=='run.sh' else 0o600); replaced.append(name)
   compile_names=['bot.py','accounts.py','sessions.py','recovery.py','storage.py','ingest.py','ui_state.py','manage.py','dashboard.py','tests']
   subprocess.run([python,'-m','compileall','-q',*compile_names],cwd=root,check=True,timeout=35)
   subprocess.run([python,'-m','unittest','discover','-s','tests','-q'],cwd=root,check=True,timeout=150)
   if fingerprints(json.loads((root/'config.json').read_text())) != before:
    raise RuntimeError('Preservation mismatch; code rolled back without restoring/replacing private state')
  except BaseException:
   for name in replaced:
    if (backup/name).is_file(): shutil.copy2(backup/name,root/name)
    else: (root/name).unlink(missing_ok=True)
   raise
 print('PRIVATE_BACKUP='+str(backup))
 print('REMOTE_112_TESTS_AND_COMPILE=PASS')
 print('CONTROLLER_JOBS_SESSION_SELECTION_AND_KEY_PRESERVED=True')
 print('V2_2_CODE_INSTALLED=True')
except BaseException as e:
 print('UPGRADE_ERROR_CLASS='+type(e).__name__)
 print('No private configuration rollback or reset RPC was attempted by the installer.')
 raise
