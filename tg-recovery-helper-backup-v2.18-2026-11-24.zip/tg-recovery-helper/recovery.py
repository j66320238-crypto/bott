"""Durable, conservative recovery state machine. Telegram supplies every deadline.

This module does not know bot tokens and never sends passwords to the UI.
A restart can resume a pending operation, but cannot make an offline host run.
"""
from __future__ import annotations

import asyncio
import logging
import time
from datetime import datetime, timezone
from typing import Callable

from sessions import account_identity, public_error, retry_seconds
from storage import SafeError, Store, Vault

log = logging.getLogger(__name__)


def when(value: int) -> str:
    if not value:
        return "not scheduled"
    return datetime.fromtimestamp(int(value), timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")


def remaining(value: int, now: int) -> str:
    seconds = max(0, int(value) - int(now))
    days, seconds = divmod(seconds, 86400)
    hours, seconds = divmod(seconds, 3600)
    minutes = seconds // 60
    return f"{days}d {hours}h {minutes}m"


class RecoveryEngine:
    def __init__(self, store: Store, sessions, vault: Vault, clock: Callable = time.time):
        self.store, self.sessions, self.vault, self.clock = store, sessions, vault, clock
        self.lock = asyncio.Lock()

    def now(self) -> int:
        return int(self.clock())

    def _notice(self, text: str) -> None:
        self.store.queue(text)

    def summary(self) -> str:
        data = self.store.reload()
        status = data["reset_status"]
        lines = [f"Reset state: {status}", f"Phase: {data['phase']}"]
        if status == "waiting":
            if data["wait_kind"] == "cooldown":
                deadline = int(data["retry_at"] or 0)
                lines += [
                    "Eligibility cooldown: the seven-day reset timer has NOT started yet.",
                    f"Telegram allows another request at: {when(deadline)}",
                ]
            elif data["reset_until_date"]:
                deadline = int(data["reset_until_date"])
                lines += [
                    f"Telegram's reset deadline: {when(deadline)}",
                    f"Remaining: {remaining(deadline, self.now())}",
                    "Do not start another reset. The saved job will resume after a restart.",
                ]
            else:
                lines.append("A confirmed operation is being reconciled with Telegram.")
            lines.append("Automatic action requires this program to be running and online.")
        if data["password_apply_status"] == "manual_required":
            lines.append("IMPORTANT: new 2FA was NOT confirmed. Set it in Telegram settings or use /setpassword.")
        if data["password_apply_status"] == "enabled_unconfirmed":
            lines.append("2FA is ON, but the bot cannot confirm which password was applied. Verify it in the Telegram app.")
        if data["last_error_code"]:
            lines.append(f"Last error class: {data['last_error_code']}")
        return "\n".join(lines)

    async def start(self, encrypted_password: str, hint: str, set_only: bool = False):
        """Called only after an owner-only explicit confirmation in the UI."""
        async with self.lock:
            data = self.store.reload()
            if data["reset_status"] == "waiting":
                raise SafeError("A reset is already in progress. Use /status or /cancel; its timer was not restarted.")
            self.vault.open(encrypted_password)  # Fail closed before any account change.
            if not data["registered"] or not int(data.get("account_user_id") or 0):
                raise SafeError("Verify this account's session and phone with /resetpassword or /verify first.")
            adapter = await self.sessions.ensure()
            info = await adapter.info()
            if set_only and info.has_password:
                raise SafeError("2FA is already ON. /setpassword will not change an existing password or start a reset.")
            self.store.update(
                pending_new_password=encrypted_password, pending_hint=hint,
                reset_status="waiting", phase="requesting", wait_kind="",
                reset_started_at=0, reset_until_date=0, retry_at=0,
                next_attempt_at=0, password_apply_status="pending", last_error_code="",
                password_action="set" if set_only else "reset",
            )
            log.info("Owner confirmed a recovery operation")
            try:
                if not info.has_password:
                    self.store.update(phase="old_removed", password_apply_status="pending")
                    self._notice("Telegram reports that 2FA is already OFF. No reset wait is needed; applying your confirmed new password.")
                    await self._apply(adapter)
                elif info.pending_reset_date:
                    self._waiting(int(info.pending_reset_date), existing=True)
                    if info.pending_reset_date <= self.now():
                        await self._request(adapter)
                else:
                    await self._request(adapter)
            except Exception as error:
                self._defer(error)
                raise SafeError(public_error(error)) from None

    def _waiting(self, date: int, existing: bool = False):
        if date <= 0:
            raise SafeError("Telegram returned an invalid deadline. No deadline was guessed locally.")
        self.store.update(
            reset_status="waiting", phase="waiting", wait_kind="reset",
            reset_started_at=self.store.data["reset_started_at"] or self.now(),
            reset_until_date=date, retry_at=0, next_attempt_at=date, last_error_code="",
        )
        self._notice(
            ("Attached to Telegram's existing reset timer. " if existing else "Telegram accepted the reset request (normally a seven-day timer). ")
            + f"Deadline: {when(date)}. I will check automatically while running, and reconcile saved state after a restart. "
            "This is a password reset, not account deletion."
        )

    async def _request(self, adapter):
        # Persist BEFORE calling a state-changing RPC. A crash must not lose intent.
        self.vault.open(self.store.data["pending_new_password"])
        self.store.update(phase="requesting")
        result = await asyncio.wait_for(adapter.reset(), timeout=60)
        if result.kind == "wait":
            self._waiting(result.date)
        elif result.kind == "cooldown":
            if result.date <= self.now():
                raise SafeError("Telegram returned a cooldown without a future date. State was preserved.")
            self.store.update(
                reset_status="waiting", phase="cooldown", wait_kind="cooldown",
                retry_at=result.date, reset_until_date=0, next_attempt_at=result.date,
                last_error_code="",
            )
            self._notice(
                f"Telegram requires an eligibility cooldown until {when(result.date)}. "
                "The seven-day reset has NOT started. The confirmed request will be retried then while the bot is online."
            )
        elif result.kind == "ok":
            self.store.update(
                phase="old_removed", wait_kind="", reset_until_date=0,
                retry_at=0, next_attempt_at=0, password_apply_status="pending",
            )
            self._notice("Telegram confirmed removal of the old 2FA password. Applying the new password now.")
            await self._apply(adapter)
        else:
            raise SafeError("An unknown reset response was received. No further account change was attempted.")

    async def _apply(self, adapter):
        """Never initiate another reset after the old password has been removed."""
        data = self.store.reload()
        plaintext = self.vault.open(data["pending_new_password"])
        info = await asyncio.wait_for(adapter.info(), timeout=40)
        if info.has_password:
            # It may have succeeded immediately before a crash, or the owner may
            # have set a different password elsewhere. Do not overwrite or reset it.
            self.store.update(
                reset_status="done", phase="done", password_apply_status="enabled_unconfirmed",
                pending_new_password="", pending_hint="", next_attempt_at=0, last_error_code="",
            )
            self._notice(
                account_identity(self.store.reload()) + "\n\n"
                "2FA is ON. This may be a successful password update from before a restart, "
                "or a change you made in another app. I did not change or reset it again, and no email was requested. "
                "Verify the password in Telegram. No password is sent in chat. This bot session was not logged out."
            )
            return
        self.store.update(phase="applying", password_apply_status="applying")
        try:
            success = await asyncio.wait_for(adapter.set_password(plaintext, data["pending_hint"]), timeout=90)
            if success is False:
                raise SafeError("Telegram did not confirm the new password. Check 2FA in the Telegram app.")
        finally:
            plaintext = ""  # Best effort only; Python cannot guarantee memory erasure.
        self.store.update(
            reset_status="done", phase="done", password_apply_status="applied",
            pending_new_password="", pending_hint="", next_attempt_at=0,
            reset_until_date=0, retry_at=0, wait_kind="", last_error_code="",
        )
        title = "PASSWORD SET DONE" if data.get("password_action") == "set" else "PASSWORD RESET DONE"
        log.info("New 2FA password confirmed by Telegram; encrypted pending value cleared")
        self._notice(
            "PIN\n" + title + "\n" + account_identity(data) + "\n\n"
            "Telegram confirmed the new 2FA password is ON. "
            "No recovery email was requested or changed. The saved copy was cleared after confirmation and is not included here. "
            "This bot session was not logged out."
        )

    def _defer(self, error: Exception):
        seconds = retry_seconds(error)
        code = type(error).__name__[:80]
        data = self.store.reload()
        fields = {"next_attempt_at": self.now() + seconds, "last_error_code": code}
        if data["phase"] == "applying":
            fields["password_apply_status"] = "not_confirmed"
        self.store.update(**fields)
        log.warning("Recovery deferred (%s), no exception values logged", code)
        self._notice(
            public_error(error) + " State is preserved. "
            + ("IMPORTANT: the old password is already removed; the new password is not yet confirmed. Check 2FA in the app. "
               if data["phase"] in ("old_removed", "applying") else "")
            + f"Next automatic attempt no earlier than {when(self.now() + seconds)}."
        )

    async def tick(self, manual: bool = False) -> str:
        """Run on startup, hourly, and on /check. Never execute before server time."""
        async with self.lock:
            data = self.store.reload()
            if data["reset_status"] != "waiting":
                return self.summary()
            # Manual checks also respect rate limits and server-controlled dates.
            if data["next_attempt_at"] and self.now() < int(data["next_attempt_at"]):
                return self.summary()
            try:
                if not data["registered"] or not int(data.get("account_user_id") or 0):
                    raise SafeError("This account is not phone-verified. Automatic work is paused; use /verify for this profile.")
                self.vault.open(data["pending_new_password"])
                adapter = await self.sessions.ensure()
                if data["phase"] in ("old_removed", "applying"):
                    await self._apply(adapter)
                    return self.summary()
                info = await asyncio.wait_for(adapter.info(), timeout=40)
                if not info.has_password:
                    self.store.update(phase="old_removed")
                    await self._apply(adapter)
                elif info.pending_reset_date and info.pending_reset_date > self.now():
                    if info.pending_reset_date != data["reset_until_date"]:
                        self._waiting(int(info.pending_reset_date), existing=True)
                elif data["phase"] == "waiting" and not info.pending_reset_date:
                    # Someone cancelled it outside this bot. Tell the owner and start a new official request.
                    # The saved password stays encrypted. The seven-day wait is not skipped.
                    self._notice(
                        "RESET WAS STOPPED\n" + account_identity(self.store.reload()) + "\n\n"
                        "Telegram reports no active reset while 2FA is still ON. Someone stopped it outside this bot. "
                        "A new official reset is being requested now. Telegram's wait is not skipped. "
                        "No password is included. This bot session was not logged out."
                    )
                    await self._request(adapter)
                else:
                    self._notice("Telegram's saved deadline is due. Checking the official reset request now; no waiting period is skipped.")
                    await self._request(adapter)
            except Exception as error:
                self._defer(error)
            return self.summary()

    async def cancel(self) -> str:
        async with self.lock:
            data = self.store.reload()
            if not data["registered"] or not int(data.get("account_user_id") or 0):
                raise SafeError("Verify this account with /verify before cancelling a Telegram reset.")
            adapter = await self.sessions.ensure()
            info = await asyncio.wait_for(adapter.info(), timeout=40)
            if info.pending_reset_date:
                try:
                    declined = await asyncio.wait_for(adapter.decline(), timeout=40)
                    if declined is False:
                        raise SafeError("Telegram did not confirm server cancellation.")
                except Exception as error:
                    # Never claim server cancellation if it actually failed.
                    raise SafeError(public_error(error) + " Cancellation was NOT confirmed; the saved job remains active.") from None
            self.store.update(
                reset_status="cancelled", phase="cancelled", reset_until_date=0,
                reset_started_at=0, retry_at=0, next_attempt_at=0, wait_kind="",
                pending_new_password="", pending_hint="", password_apply_status="not_started", last_error_code="",
            )
            log.info("Owner cancelled local recovery work; any active Telegram reset was declined")
            if not info.has_password:
                return "Automatic work cancelled and pending password cleared. IMPORTANT: 2FA is currently OFF; set it in Telegram or use /setpassword. An already-removed password cannot be restored by cancellation."
            return "Cancellation confirmed. Saved automatic work and pending password were cleared. Cancelling may cause a Telegram cooldown before another reset."

    async def spamcheck(self) -> str:
        async with self.lock:
            if not self.store.data["registered"] or not int(self.store.data.get("account_user_id") or 0):
                raise SafeError("Verify the selected account with /verify before contacting @SpamBot.")
            now = self.now()
            if now - int(self.store.data["last_spamcheck_at"] or 0) < 60:
                raise SafeError("Wait at least 60 seconds between /spamcheck requests.")
            adapter = await self.sessions.ensure()
            self.store.update(last_spamcheck_at=now)
            log.info("Owner requested a single /start message to official @SpamBot")
            return await asyncio.wait_for(adapter.spamcheck(), timeout=45)
