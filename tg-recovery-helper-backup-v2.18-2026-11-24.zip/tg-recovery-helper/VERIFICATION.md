# v2.8 — universal password, live phone verify, pinned result

Audit of the deployed build. **No password was applied, no reset was started, no email or code was requested, and no session was logged out during this update.**

## Behavior

- A logged-in session supplies its own phone number and Telegram ID. The owner does not type the number after upload.
- `/universal` saves one encrypted password. Reset and Enable 2FA use it after one account confirmation. The password is never shown again.
- If 2FA is already OFF, that saved password is applied immediately, with no email step.
- If 2FA is ON, Telegram's official timer is not skipped. The saved password is applied when Telegram removes the old one.
- When Telegram confirms the password, the owner message is pinned. It says `PASSWORD RESET DONE` or `PASSWORD SET DONE` and includes the phone and Telegram ID. The password is not included.
- Lock ON terminates new logins. The session running this bot is never a termination target. Sessions already present when the lock was armed stay trusted.
- A session younger than 24 hours cannot terminate other logins until Telegram allows it. That delay does not log the current session out.

## Verification

```text
local    python -m pytest -q tests  ->  347 passed, 55 subtests passed
remote   staged isolated tree       ->  STAGED_VERSION 2.8
                                      Ran 347 tests in 25.154s   OK
remote   py_compile                  ->  COMPILE_OK
```

Live process after restart: `Multi-account bot v2.8 initialized; universal password and session-phone verify added; lock still keeps this session`.

Preservation: controller config, secret key, and every saved session hash matched before and after installation. Three saved recovery jobs remained waiting, each with its encrypted password still present, its Telegram deadline unchanged, and protection/alerts still ON. No email-change journal was started.

## Honest limits

- A password cannot be written over an existing 2FA password, and the official reset timer cannot be shortened.
- Jobs that were already waiting keep the password saved for that job. `/universal` applies to later Reset clicks.
- If Telegram keeps requiring a recovery email after the pending code is cancelled, the password is not reported as set and the saved copy remains.
- Lock ON is not a pre-login block. A session younger than 24 hours must wait for Telegram's limit before it can terminate other logins.
- The typed password still passes through this private bot chat. Deletion of that message is best effort.
- No live password apply was exercised during this update.
