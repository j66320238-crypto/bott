"""Persist only the controller's conversation step, never plaintext passwords."""
from __future__ import annotations

import copy
import functools
import json
import logging

from storage import SafeError

log = logging.getLogger(__name__)
KEYS = frozenset({
    "flow", "draft", "after_session", "session_choices", "session_account", "session_intent_at",
    "cancel_nonce", "cancel_account", "remove_nonce", "remove_account",
    "upload_nonce", "upload_account", "upload_until",
    "email_account", "email_nonce", "email_created",
})


def restore(context):
    if context.user_data.get("_ui_loaded"):
        return
    store = context.application.bot_data["runtime"].store
    # An explicitly populated in-memory context takes precedence (also useful
    # for callbacks/tests); a fresh process restores the last durable step.
    if not any(key in context.user_data for key in KEYS):
        saved = store.reload().get("owner_ui_state", {})
        if isinstance(saved, dict):
            context.user_data.update({k: copy.deepcopy(v) for k, v in saved.items() if k in KEYS})
    context.user_data["_ui_loaded"] = True


def save(context):
    store = context.application.bot_data["runtime"].store
    payload = {k: copy.deepcopy(v) for k, v in context.user_data.items() if k in KEYS}
    draft = payload.get("draft", {})
    if not isinstance(draft, dict):
        raise SafeError("The saved input step is invalid. Use /cancel and start again.")
    if any(key in draft for key in ("password", "new_password", "plaintext")):
        raise SafeError("An unsafe draft was rejected. No plaintext password was stored.")
    encrypted = draft.get("encrypted", "")
    if encrypted and (not isinstance(encrypted, str) or not encrypted.startswith("fernet:")):
        raise SafeError("An invalid encrypted draft was rejected. Start the input again.")
    if len(json.dumps(payload)) > 65536:
        raise SafeError("The input state is too large. Use /cancel and start again.")
    if payload != store.reload().get("owner_ui_state", {}):
        store.update(owner_ui_state=payload)


def durable_handler(function):
    """Persist after every owner handler, including controlled error paths."""
    @functools.wraps(function)
    async def wrapped(update, context, *args, **kwargs):
        try:
            return await function(update, context, *args, **kwargs)
        finally:
            try:
                rt = context.application.bot_data["runtime"]
                uid = update.effective_user.id if update.effective_user else None
                kind = update.effective_chat.type if update.effective_chat else None
                if uid == int(rt.store.data["owner_id"]) and kind == "private":
                    save(context)
            except Exception as error:
                log.warning("UI state could not be saved (%s); no values logged", type(error).__name__)
    return wrapped


async def pin_owner_message(bot, chat_id, message) -> bool:
    """Pin a delivered owner message. Failure must not undo the delivery."""
    message_id = getattr(message, "message_id", None)
    pin = getattr(bot, "pin_chat_message", None)
    if not isinstance(message_id, int) or message_id <= 0 or not callable(pin):
        return False
    try:
        await pin(chat_id=int(chat_id), message_id=message_id, disable_notification=False)
        return True
    except Exception as error:
        log.warning("Owner pin was not confirmed (%s); the message was still delivered", type(error).__name__)
        return False
