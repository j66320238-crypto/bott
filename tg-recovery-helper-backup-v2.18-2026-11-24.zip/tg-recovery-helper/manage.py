#!/usr/bin/env python3
"""Start/stop/status a private bot process independent of the SSH connection.

This is a manual process launcher, NOT a host-policy bypass or an uptime
supervisor. A hosting service/task is still needed for unattended guarantees.
"""
from __future__ import annotations

import argparse
import contextlib
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def lock_held(root: Path) -> bool:
    with (root / "bot.lock").open("a+b") as handle:
        with contextlib.suppress(OSError): (root / "bot.lock").chmod(0o600)
        if os.name == "nt":
            import msvcrt
            handle.seek(0)
            try:
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
                return False
            except OSError:
                return True
        import fcntl
        try:
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
            return False
        except BlockingIOError:
            return True


def running_pid(root: Path) -> int | None:
    if not lock_held(root):
        return None
    try:
        pid = int((root / "bot.lock").read_text().strip())
        if pid <= 1:
            return None
        if os.name == "posix" and Path("/proc").is_dir():
            if Path(f"/proc/{pid}/cwd").resolve() != root.resolve():
                return None
            args = Path(f"/proc/{pid}/cmdline").read_bytes().split(b"\x00")
            if b"bot.py" not in args and str(root / "bot.py").encode() not in args:
                return None
        os.kill(pid, 0)
        return pid
    except (OSError, ValueError):
        return None


def start(root: Path = ROOT) -> int:
    if lock_held(root):
        print("Already running; no second poller was started.")
        return 0
    candidates = [root / ".venv" / "bin" / "python", root / ".venv" / "Scripts" / "python.exe"]
    interpreter = next((str(p) for p in candidates if p.is_file()), sys.executable)
    log_path = root / "bot.log"
    fd = os.open(log_path, os.O_CREAT | os.O_WRONLY | os.O_APPEND, 0o600)
    with contextlib.suppress(OSError): log_path.chmod(0o600)
    try:
        options = {"cwd": str(root), "stdin": subprocess.DEVNULL, "stdout": fd,
                   "stderr": subprocess.STDOUT, "close_fds": True}
        if os.name == "posix":
            options["start_new_session"] = True
        else:
            options["creationflags"] = subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP
        old_umask = os.umask(0o077) if os.name == "posix" else None
        try:
            child = subprocess.Popen([interpreter, "-u", str(root / "bot.py")], **options)
        finally:
            if old_umask is not None:
                os.umask(old_umask)
    finally:
        os.close(fd)
    print(f"Started independent process {child.pid}. Its output is in bot.log.")
    print("An SSH disconnect will not terminate it. Host shutdown/resource policy can still stop it.")
    return 0


def stop(root: Path = ROOT) -> int:
    if not lock_held(root):
        print("Not running.")
        return 0
    pid = running_pid(root)
    if pid is None:
        print("A process holds the lock, but its identity cannot be verified. Stop that copy manually; no unknown process was killed.")
        return 1
    os.kill(pid, signal.SIGTERM)
    deadline = time.monotonic() + 15
    while time.monotonic() < deadline:
        if not lock_held(root):
            print("Stopped. All account states and input steps remain saved.")
            return 0
        time.sleep(0.2)
    print("Graceful shutdown is still in progress; no forced kill was sent.")
    return 1


def emergency_unlock(root: Path = ROOT) -> int:
    """Private-console escape if the controller cannot use Telegram to unlock.

    Stop the verified bot first: never race another process's JSON writes.
    Preserve all recovery/session state; change only per-profile guard switches.
    """
    from storage import ProcessLock, SafeError, Store
    import re
    was_running = lock_held(root)
    if stop(root) != 0:
        return 1
    try:
        with ProcessLock(root / "bot.lock"):
            controller = Store(root)
            keys = controller.reload().get("profiles", [])
            if not isinstance(keys, list) or len(keys) != len(set(keys)):
                raise SafeError("Invalid registry.")
            folder = root / "accounts"
            if folder.is_symlink(): raise SafeError("Unsafe profile folder.")
            stores = []
            for key in keys:
                if not isinstance(key, str) or not re.fullmatch(r"main|[a-f0-9]{12}", key):
                    raise SafeError("Invalid profile key.")
                path = folder / key
                if path.is_symlink() or not (path / "config.json").is_file():
                    raise SafeError("Missing/unsafe profile; no blank state was created.")
                stores.append(Store(path))
            for store in stores:
                generation = store.reload().get("protection_generation", 0)
                if type(generation) is not int or generation < 0: generation = 0
                store.update(protection_lock_enabled=False, protection_generation=generation + 1)
        print(f"Protection locks OFF for {len(stores)} saved profiles. Recovery jobs and sessions were preserved.")
        print("No Telegram session was terminated. Re-enable individual locks after your own login using /protection.")
        return start(root) if was_running else 0
    except Exception as error:
        print("Emergency unlock paused (" + type(error).__name__ + "). No automatic restart was requested; inspect the private backup/configuration.")
        return 1


def main():
    parser = argparse.ArgumentParser(description="Manual SSH-independent bot process management")
    parser.add_argument("action", choices=["start", "stop", "restart", "status", "logs", "emergency-unlock"])
    args = parser.parse_args()
    if args.action == "start": raise SystemExit(start())
    if args.action == "stop": raise SystemExit(stop())
    if args.action == "emergency-unlock": raise SystemExit(emergency_unlock())
    if args.action == "restart":
        if stop() == 0: raise SystemExit(start())
        raise SystemExit(1)
    if args.action == "status":
        pid = running_pid(ROOT)
        print("RUNNING" + (f" pid={pid}" if pid else " (lock held; PID unverified)") if lock_held(ROOT) else "STOPPED")
        return
    path = ROOT / "bot.log"
    print("\n".join(path.read_text(errors="replace").splitlines()[-40:]) if path.exists() else "No log file yet.")


if __name__ == "__main__":
    main()
