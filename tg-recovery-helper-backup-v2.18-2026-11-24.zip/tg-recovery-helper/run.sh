#!/bin/sh
# Use this exact script as the Alwaysdata background service command.
# Running a second copy safely exits because bot.py owns an OS file lock.
set -eu
umask 077
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
exec .venv/bin/python -u bot.py
