# Private Telegram Recovery Bot — v2.8

**Send your own logged-in session file → account saved → choose an action. No import questionnaire.**

English UI · owner-only control · auto Telethon/Pyrogram detection · separate own-account profiles · durable input steps and reset jobs · `/spamcheck` · code-free `/alerts` · per-ID `/protection` lock · login-email status and guided change

## New in v2.8 — universal password, no retyped phone, pinned result

- Upload a session: the phone number and Telegram ID come from the live session. You do not type the number again.
- `/universal` saves one encrypted password. **Reset password** and **Enable 2FA if OFF** use it after one account confirmation. The password is not shown again.
- When Telegram confirms the password, the owner receives a pinned `PASSWORD RESET DONE` or `PASSWORD SET DONE` message with the phone and Telegram ID. The password is not in that message.
- Lock ON terminates new logins. The session running this bot is never terminated. A session younger than 24 hours cannot terminate other logins until Telegram allows it.

## New in v2.6 — login-email status and a guided LOGIN-email change

**Login email is not the 2FA recovery email.** The bot now shows both, separately, on the account dashboard and on `/email`:

- **Login email:** `SET (masked pattern)` / **NOT SET** / **UNKNOWN** — the address Telegram uses to email sign-in codes.
- **2FA recovery email:** **SET** / **NOT SET** / **UNCONFIRMED** — the separate recovery address used by Two-Step Verification.

Values come from the official `account.getPassword` response (`loginEmailPattern`, `hasRecovery`, `emailUnconfirmedPattern`) and are cached with a "Checked" time. Only a masked pattern is stored: the local part and most of the domain are always hidden. Nothing is guessed when the status is unknown.

### Changing the login email — five taps, no code editing

1. Open **Email** on the account card (or send `/email`). If the status is old, tap **Refresh email status**.
2. Tap **Change LOGIN email** and send the new address as a chat message. Nothing is sent to Telegram yet.
3. Review the confirmation card (current masked login email → new masked login email) and tap **Send code to the new address**.
4. Telegram emails a verification code to the **new** address. Enter only that emailed code in the chat.
5. The bot reports success **only** when Telegram returns the matching `account.emailVerified` receipt.

**Change-only rule:** Telegram requires an existing login email for `emailVerifyPurposeLoginChange`. If the status is **NOT SET**, this feature refuses and explains that setup must happen in the official app if Telegram offers it. The bot never starts a sign-in, SMS/phone-code, `auth.resetLoginEmail` or automatic setup flow as a fallback.

### Added safety and honesty

- Only `getPassword`, `sendVerifyEmailCode(loginEmailChange)` and `verifyEmail(loginEmailChange)` are used. No logout, session revocation, password update, phone change, 2FA recovery-email change or account deletion exists in this feature.
- The new address is kept **encrypted**; the UI, state and notifications show only the masked pattern. The emailed code is never stored, echoed or logged — even for restart recovery: an interrupted step asks you to re-enter the code, and no code is replayed automatically.
- Rate limits: one email-code request per two minutes per account, at most three per hour locally, three code attempts per request, five seconds between attempts, 25-second RPC timeout and Telegram's own FloodWait respected. Uncertain outcomes are labelled uncertain, never success.
- Durable intent is written **before** the email-request RPC. A restart resumes the saved step; it never silently resends. "Stop LOCAL input" cancels only local text entry.
- Status refresh, resume, cancel and the last checked/retry times stay available. Password recovery state, timers, protection lock and other accounts are untouched; changes are blocked while a recovery is in a sensitive `requesting`/`old_removed`/`applying` phase.
- **No zero-risk promise:** Telegram can still rate-limit or reject an email change, and the new address plus code travel through this private bot chat and Telegram cloud servers. Deletion of chat messages is best effort, not secure erasure.

## Retained v2.5 — new-login alerts and a default-ON protection lock

**Important: this detects/revokes new active authorizations; it is NOT a pre-login block.** A new session may have access before detection. The bot must be online, the saved session must remain authorized, and Telegram must permit revocation. No zero-access or permanent-protection guarantee is possible.

### Simple controls — no code editing

1. Open **Protection lock** or `/protection` to see every own account, its lock status, Last check and pending actions.
2. Open the intended account's settings and tap **Turn lock OFF** **before** signing in yourself on another device. `/unlock` turns OFF the currently selected account's lock.
3. Sign in using the official app. Then tap **Turn lock ON** (or `/lock`). Enabling takes a fresh read-only baseline and trusts the sessions active then. No phone/password/OTP question is added.
4. Leave it ON for protection against later new sessions. It stays ON **until manually switched OFF**, even after the seven-day reset wait ends. Changing selection never disables other profiles' locks.

Saved own-account profiles and future valid imports default to **lock ON** and **alerts ON**. Your deliberate per-account OFF choice survives restarts and re-imports. The fixed bot controller alone can change these settings; a target session UID does not become a bot administrator.

### Emergency OFF if you cannot access the controller chat

From your private hosting/SSH console (not a Telegram message), run:

```sh
cd /home/tgidsellerindian/tg-recovery-helper
.venv/bin/python manage.py emergency-unlock
```

This verifies/stops the running local bot, takes its process lock, turns OFF protection for all saved profiles without touching recovery/session/password fields, and restarts only if it was previously running. It makes no Telegram revocation/login request. It refuses missing/unsafe profiles instead of creating blank states. Disable any external supervisor first if it races a manual stop. Sign in, then re-enable the desired locks in `/protection`. On PC/Termux use your project directory/interpreter instead of the hosted path.

### What the lock does

- On first arming, existing sessions are retained as trusted. **The current session is never a termination target.** Already-active suspicious sessions are not silently removed; review them yourself in the official Telegram app's **Settings > Devices**.
- About every 30 seconds while online, an independent worker reads official `account.getAuthorizations` metadata. Newly observed active sessions cause a **New login/session detected** alert for that account, including while a recovery is waiting.
- With the lock ON, only a new, non-current, non-trusted authorization created since arming is eligible for individual `account.resetAuthorization(hash)`. The account identity, lock generation, current-session flag, creation date and live membership are rechecked before the call. No all-session logout or arbitrary hash-input command exists. At most three candidates are attempted per account/tick.
- An older/undated unknown authorization is alerted but **not automatically terminated**, rather than guessing that a pre-existing session is new.
- Telegram's successful acknowledgment is saved, then the list is read again. **Termination confirmed** is used only after acknowledgment plus absence from the active list. False/error/timeout results are not reported as success. An ambiguous timeout followed by absence is labeled unconfirmed.
- Telegram rate limits and fresh-session restrictions are respected. Failures retain only controlled error-class metadata, show a delayed/attention state and retry later. Neither 2FA nor an official waiting rule is bypassed.
- OFF is persisted without waiting for an account's slow network/operation lock. Future termination attempts stop; **an attempt already in progress may finish**. A stale, slow ON operation cannot overwrite a later OFF choice. Repeated ON taps/restarts do not silently re-trust new intruders.
- Login notices continue with the lock OFF. `/alerts` controls both code-free service-chat and login notices. **Turning alerts OFF does NOT turn the protection lock OFF**; use `/protection` or `/unlock` for that.
- Restart state includes the trusted baseline, seen authorization IDs, pending actions, generation, counters and a fixed-category durable outbox. No device descriptions, IPs, raw messages, OTP values, session authentication keys or login links are added to that state or owner notices. Opaque authorization identifiers stay private on the host and are never sent in alerts.
- The official password-recovery engine and its deadlines remain separate and unchanged. Alerts/guard operations never start/cancel/restart a password reset.

A normal restart catches still-active new authorizations created after its saved baseline. A session that disappears between checks may be missed. **Reuse of a copied existing session/authentication key may not create a new authorization and cannot be reliably detected by this guard.** Protect session files, bot credentials and your controller account; review existing devices and add a recovery email after recovery. A guard is an extra layer, not a substitute for those controls.

## Retained v2.4 — code-free security alerts for all own accounts

- All saved own-account profiles and future valid imports default **ON**. No phone/password/OTP questionnaire is added for monitoring. The configured owner can use **Security alerts** or `/alerts` for per-account and all-account ON/OFF controls.
- **Only the official Telegram service/security chat, fixed user ID `777000`, is inspected.** No other private chat, group, channel, arbitrary bot or configurable source is monitored.
- Notifications contain only **“OTP message received” / “Telegram message received,” account identity and time (IST)**. Bursts are combined into category counts. Codes, message bodies, login links, attachments and hashes of message text are never put in the alert outbox, logs or owner notifications.
- A body can be inspected **transiently in memory** to select one of those two categories. OTP classification is a best-effort keyword/digit heuristic, not a guarantee; unknown languages/formats fall back to a generic Telegram-message alert. No code value is extracted as a field.
- Healthy online profiles are checked about **every 30 seconds**, using independent per-account workers. The official recovery scheduler stays **hourly**. Rate limits, network failures, a long backlog or an account operation holding its lock can delay that account's check.
- First successful enable/re-enable establishes a baseline and **does not replay old history**. After that baseline, normal restarts retain the cursor; messages arriving during downtime are caught up if Telegram still retains them. Deleted/unavailable history cannot be recovered, and edited old messages do not trigger a fresh-arrival alert.
- Cursors, page progress and a category-only outbox survive restart. The outbox is saved atomically before delivery and retained on failure. Normal polls/restarts deduplicate by message ID; a crash after Telegram accepts an alert but before the disk acknowledgment can still duplicate that alert. Exactly-once delivery is not claimed.
- Read-only history requests do not send a message, mark messages as read, request/generate an OTP, change a phone, or initiate/cancel/restart a reset. Turning alerts OFF discards that account's pending alerts; turning it ON again starts a new baseline.
- Alerts go **only to the fixed bot controller**, never to a target-session UID or a user-selected destination. Account-specific buttons remain bound to the account that generated the alert.

Example (no real message text or code):

```text
TELEGRAM SECURITY ALERT
Account 2 | ID 123456789
Phone: +910000000000
OTP message received
Time: 21 Nov 2026, 12:30:00 IST
Message text, codes and login links are not included.
```

The bot must remain running for approximately 30-second checks. A separately enabled hourly `--run-once` task can only check once per invocation; it is not a 30-second monitor or a live chat UI.

## Retained v2.3 — send, save, choose

- A plain session upload now ends at a **short account card**, not an automatic phone/password wizard. Simply adding an account asks no Accept, phone or password questions.
- Filename/extension no longer decides whether a file is a session. A valid logged-in Telethon/Pyrogram SQLite database can be named `.session`, `.db`, `.sqlite`, have no extension, or arrive without a public filename. The database/library/account are checked automatically.
- Local session scanning also detects the database content rather than requiring a `.session` suffix.
- **Add my account** only shows where to send/select a file. It no longer creates unused blank profiles or consumes slots just because the button was tapped.
- Import replies are shorter and do not repeat the recovery-wait footer. My IDs and its timer/actions remain available.
- Phone verification and new-password input happen when you deliberately choose **Reset password** (or another action requiring verification), not as the price of saving a session.
- If you explicitly started `/resetpassword` and it was waiting for a session, a matching upload can continue that same guided flow for ten minutes. A stale intent, another routed profile or an already-waiting job never inherits it.
- Re-uploading a waiting account still selects its existing job without replacing its session, deadline or pending password.

**Supported content is still a logged-in Telethon/Pyrogram SQLite session, up to 5 MB.** An arbitrary filename is fine; a real ZIP archive, StringSession text, tdata folder, corrupted file or logged-out session is not automatically converted into a valid session. No login/OTP flow is added.

## Retained v2.2 — My IDs

- The **My IDs** home button and `/myids` list saved phone numbers, Telegram IDs, account state and remaining time. `/accounts` remains an alias.
- Tap a phone/ID button to open that account's dashboard. It shows its verified/detected number, target ID, session format and job state.
- An active timer shows **remaining time and the exact deadline in IST and UTC**. Eligibility cooldown is clearly separate from an active reset wait.
- **Refresh timer** updates the same screen using the current clock; it does not send a reset, replace a password or restart a job. The display is a timestamped snapshot, not an automatically ticking message.
- **Live status**, **Check saved job**, **Reset password**, **SpamBot check**, **Cancel THIS reset** and **More options** operate on the account attached to that screen. More options includes phone verification, session setup, enabling 2FA when OFF, and local profile removal.
- Buttons from older account screens remain bound to their original account. Removed accounts fail closed instead of falling back to a different profile.
- Lists are paginated five profiles at a time, up to the existing configured cap. One unreadable profile does not hide healthy IDs.
- `/timer` opens the selected account's dashboard directly.

### If the bot is offline for a day

**Yes, the offline day still counts toward Telegram's existing wait.** The bot saves Telegram's absolute deadline, not a countdown that pauses with the process:

```text
remaining time = saved Telegram deadline - current time
```

For example, immediately after a fresh seven-day wait, one full day offline leaves about six days, not seven new days. The exact displayed time follows Telegram's returned date; a cooldown or changed server deadline can differ from that example. If the bot is offline when a deadline is reached, the automatic action is delayed until a worker runs again. Startup reconciliation and hourly checks resume confirmed jobs without creating a fresh waiting period. Refresh does not bypass Telegram's eligibility rules or server-side cancellation.

Opening My IDs/selecting another profile clears unfinished chat input, not previously confirmed recovery jobs. Existing timers for other profiles continue independently.

## Retained v2.1 fixes

- A plain owner-sent `.session` document is accepted without `/session` or an Accept round-trip.
- Its library and account ID are detected automatically. An existing account is selected; a new account gets a separate profile.
- A matching previously verified account does not ask for its phone again. New accounts and changed phone numbers still need matching phone verification before recovery or other protected actions, not just to save the session.
- Short password prompts replace repeated long warnings. Password encryption stays in the background, with no extra UI step.
- The current input step is saved. A restart can resume the password confirmation/hint step instead of losing the conversation. Only ciphertext, not plaintext passwords, is persisted.
- Best-effort message deletion has a short timeout and cannot stall the input handler indefinitely.
- Passwords beginning with `/` are handled during password input instead of disappearing as unknown commands.
- `manage.py start` runs the bot independently of the SSH connection, rather than attaching the bot to a temporary SSH pseudo-terminal.
- Re-uploading a session for an account already waiting selects that existing job without replacing its session, timer or pending password.

The configured **owner/controller ID controls who may use the bot**. Target account IDs can differ from it. Each profile remains pinned to its own verified target ID.

## Quick flow — already configured server

For accounts already added, tap **My IDs** (or send `/myids`), then tap the phone/ID. No re-upload is needed just to view its timer or options.

1. Open the bot in a private chat from the configured controller account.
2. Send one of **your OWN logged-in Telethon/Pyrogram SQLite session files**. Its name does not matter.
3. The bot auto-detects its account/library and returns a short saved-account card. Stop here if you only wanted to add it.
4. Send another own session to add/select another account, or use **My IDs** to view all numbers and timers.
5. When you want recovery, tap **Reset password** on the intended account or send `/resetpassword`.
6. The live session supplies the phone number and Telegram ID, so you do not type the number again. Set `/universal` once; Reset and Enable 2FA use that saved password. No email is asked.
7. Press the final confirmation for that account to authorize official recovery.

Uploading/selecting a session does **not** send a password-reset request. There is no bulk-reset command. The explicit final reset/cancellation/profile-removal confirmations remain to prevent wrong-account changes.

If you were interrupted before the v2.1 update, send `/resetpassword` once to restart the input for the selected account. Its saved phone verification remains valid if the session/phone still match.

## Telegram's waiting rule

Telegram normally starts a **seven-day server-side password-reset timer** for an already logged-in session with a forgotten 2FA password. An eligibility cooldown can apply before that timer starts. The program uses Telegram's exact dates and cannot skip them. [1](https://core.telegram.org/api/srp)

Saved jobs are checked on startup and hourly. A stopped machine, unavailable network, expired session or host policy can still delay completion. The program cannot act while no worker is running. Password setup does not ask for or set a recovery email. After Telegram confirms the password, the owner gets a pinned `PASSWORD RESET DONE` or `PASSWORD SET DONE` message with the phone number and Telegram ID. The password itself is never included. The saved copy is then cleared.

## Commands

| Command | Action |
|---|---|
| `/start` | Short welcome/menu |
| **Send a session document** | Auto-detect content/library/account, save/select it and show its card; no import questionnaire |
| **`/resetpassword`** | Recovery flow for the selected account; aliases `/reset`, `/reset_start` |
| **`/myids`** | List phone numbers, target IDs and remaining times; tap one for its options (`/accounts` alias) |
| `/timer` | Selected account dashboard and timer snapshot |
| **`/alerts`** | Code-free service-chat/login notice switches; does not disable protection |
| **`/protection`** | All-account protection status and account-bound lock controls |
| **`/email`** | Login-email status plus a guided LOGIN-email change for the selected account (read-only until you confirm) |
| `/lock` | Arm the selected account and trust its currently active sessions; idempotent if already armed |
| `/unlock` | Turn OFF the selected account lock before your own new login; notices stay enabled |
| `/addaccount` | Show the upload/local-file picker; no empty profile is created just by tapping Add |
| `/session` | Local-file picker; local files are auto-routed too |
| `/verify` | Verify selected account's phone without a reset |
| `/status` | Live 2FA, login-email/recovery-email status, hint and selected account's saved job |
| `/check` | Reconcile selected account's due job without skipping the wait |
| `/cancel` | Clear input, or explicitly confirm cancellation of this account's saved job |
| `/setpassword` | Enable 2FA only if already OFF, not overwrite a protected password |
| `/removeaccount` | Confirm removal of an inactive local profile |
| `/spamcheck` | Send ONE `/start` to official @SpamBot through selected verified session and relay its reply |
| `/help` | Detailed flow and safety information |

Only the configured owner may operate the bot in private. Profile IDs do not become bot administrators. `/spamcheck` is limited to one request per minute per account and sends no spam or appeal.

Default capacity: 10 profiles, configurable locally up to the supported cap of 20. Duplicate target IDs are routed to the existing profile instead of creating conflicting jobs.

## Installation from the source ZIP

### 1. Bot and API credentials

- Create your bot with official **@BotFather** `/newbot`.
- Get your own API ID/hash from `https://my.telegram.org` → API development tools.
- Configure the **controller's Telegram ID** separately from session account IDs. The prepared deployment already has it set.
- Keep all secrets private. Rotate a bot token that has already been shared in chat using @BotFather `/revoke`.

### 2. Python environment

Python **3.12 is recommended**. The code/test suite also runs on Python 3.13. Pyrogram is a legacy compatibility adapter; Telethon is preferred when you choose the source format.

Linux/Alwaysdata:

```sh
cd telegram-recovery-helper
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
mkdir -p sessions
.venv/bin/python bot.py --setup
```

Windows:

```powershell
py -3.12 -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
.venv\Scripts\python bot.py --setup
```

Termux:

```sh
pkg update
pkg install python clang make rust openssl libffi
python -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python bot.py --setup
```

Native packages vary on Android. If TgCrypto/cryptography will not build, use the prepared Alwaysdata/Python 3.12 environment rather than forcing incompatible wheels. Android battery management can still kill Termux.

The setup wizard uses hidden prompts for token/hash and retains existing values when Enter is pressed. It does not overwrite a different fixed controller ID. Advanced environment overrides are `TG_BOT_TOKEN`, `TG_API_ID`, `TG_API_HASH`, `TG_OWNER_ID`.

### 3. Start

Foreground (managed hosting service should use this):

```sh
.venv/bin/python bot.py
# Or on POSIX:
sh run.sh
```

Manual SSH-independent process:

```sh
.venv/bin/python manage.py start
.venv/bin/python manage.py status
.venv/bin/python manage.py logs
.venv/bin/python manage.py stop
.venv/bin/python manage.py restart
```

`manage.py` uses a detached process, disconnected stdin and a private log file, so closing SSH does not send the bot a terminal hangup. It is **not a supervisor** and does not evade host shutdown/resource rules. Managed Alwaysdata service or an enabled hourly scheduled task is still required for unattended availability; see `DEPLOYMENT.md`.

Do not run the same token on multiple hosts. The local lock stops duplicate processes in this installation. The manager verifies PID, working directory and bot command before stopping a process; an unverified PID is not killed.

### 4. Local files instead of uploads

Put own Telethon/Pyrogram SQLite files in the program folder or its shared `sessions/` folder, then select via `/session`. Filenames/extensions do not matter; only actual session databases are listed. No session strings, real ZIP archives, pickles or executables. Close other programs using the same file.

## Safety without extra dialog steps

- **Use only your own accounts.** Never share sessions, tokens, API hashes, OTPs, passwords, configured `accounts/`, `.secret.key`, or private backups.
- Direct bot uploads/password entries pass through Telegram cloud servers; they are **not local-only or secret chats**. Secure SSH does not change that transport. Local session placement avoids the bot-upload leg. This warning is centralized in `/start`, `/help` and this README rather than repeated in every password prompt.
- Pending passwords/drafts are encrypted locally and never echoed. Someone with both the private state and key can decrypt them; protect the host and backups.
- Input-message deletion is best effort, with a short timeout, not secure erasure. Python cannot guarantee wiping old disk blocks or memory.
- Input drafts are bound to account ID/profile and expire after 10 minutes. Switching profiles clears unfinished input. Old reset/cancel buttons cannot apply to a newly selected account.
- Session preview calls only connect/get_me. New phone verification and final account-specific confirmation remain before any reset.
- An active recovery's session/timer/password are not changed as a side effect of duplicate upload.
- No OTP forwarding/storage or generation, interactive session creation, account deletion, arbitrary recipient messaging, spam, bulk reset or wait bypass is implemented. The login-email feature changes only the login email after you enter the emailed code; it never logs out a session, removes a password or changes the 2FA recovery email. Security-chat text is inspected only transiently for category, never relayed or persisted by the alert feature.

## Files and durable state

```text
bot.py                         English owner UI and worker
accounts.py                    Controller/account separation and profile registry
dashboard.py                   Read-only My IDs list and absolute-deadline timer screens
security_alerts.py             Fixed-peer, metadata-only monitor, durable cursors/outbox, settings
login_guard.py                 Safe new-authorization detection, individual revocation, lock controls
login_email.py                 Login-email status cache, guided encrypted change, rate limits
ingest.py                      Session preview and automatic account routing
ui_state.py                    Restart-resumable input steps, encrypted drafts
sessions.py                    Telethon/Pyrogram adapters and target pinning
recovery.py                    Per-account official recovery state machine
storage.py                     Atomic JSON, encryption and process/PID lock
manage.py                      Manual SSH-independent start/stop/status
config.json                    Controller secrets, active selection, owner_ui_state
.secret.key                    Root private encryption key (runtime only)
accounts/<key>/config.json     That account's ID/phone, timer, ciphertext and notices
accounts/<key>/sessions/       Imported local source copies
accounts/<key>/.runtime/       Adapter-specific private runtime sessions
.imports/                      Private temporary preview area, cleaned after import
bot.log                        Phase/error-class logs, never input/password values
```

The verified profile phone field retains the compatibility name `owner_phone`; it means the target account's phone, not the controller's. `detected_phone` is cached for display only and never grants phone verification. Root `owner_ui_state` contains only step metadata and any encrypted draft. Root `security_alerts_enabled` is the master switch; the same child field controls its own profile. Child `security_alerts_state` contains only a baseline/cursor, numeric page progress/category counts/dates and controlled exception-class metadata, never the service message body/code/link. Child `protection_lock_enabled`, `protection_generation` and `protection_state` hold its durable lock policy, trusted/seen opaque authorization identifiers and category-only action/outbox metadata. There is no all-account termination switch. Child `email_info` holds only the masked login-email pattern, separate 2FA recovery-email status, check/retry times and a controlled error class; child `login_email_change` holds the change stage, masked destination pattern, nonce, rate-limit counters and the **encrypted** new address, never the emailed code. Confirmed recovery state remains in the profile even after UI input is cleared.

Writes use atomic JSON replacement/fsync. Back up the configured project privately, including its key and profile states. Do not delete config/key to fix a timer. Corrupt child state is paused while readable saved profiles can continue. A corrupt root registry needs restoration from backup.

## Troubleshooting

| Problem | Action |
|---|---|
| No response after password prompt | Check `manage.py status` and `manage.py logs`. A dead SSH-attached process cannot respond. Start the detached copy; v2.1 saves input steps. |
| Previous v2 input was lost | Send `/resetpassword` once; existing phone verification is retained. No reset starts without final confirmation. |
| Short password | A visible reply asks for 10–128 characters. |
| Session sent without clicking Accept | Supported. Send it directly; v2.3 saves/selects it and shows its card without starting input questions. |
| Session filename is not `.session` | Supported if its actual content is a valid Telethon/Pyrogram SQLite session. |
| Upload immediately asks for a password | A plain upload no longer does this. A recent explicit `/resetpassword` request can continue its own matching flow; `/cancel` clears it. |
| Another account's session | Only own accounts may be enrolled; it is detected into a separate profile, not forced to equal controller UID. |
| Already waiting | Existing job/profile is selected; no new timer or replacement session is installed. |
| Bot was offline for a day | That day counts. My IDs recalculates the remaining time from the saved server deadline and the current clock. |
| Timer message looks unchanged | Tap Refresh timer. It is a timestamped snapshot, not an animated countdown. |
| My IDs button missing on an old message | Send `/myids` or `/start` to get the updated UI. |
| Security alert did not arrive | Open `/alerts`; check the master/account switches and Last check. First enable skips old history. Keep the process online and respect Telegram rate limits. Deleted messages cannot be caught up. |
| Want to log in on your own new device | Open the intended account in `/protection`, turn its lock OFF first, then sign in. Turn ON afterward to trust current devices and guard later new sessions. |
| Lock ON but a login was not terminated | Read its protection status/attention notice. The bot must be online; Telegram rate limits/session-age restrictions can prevent revocation. This is not a pre-login block. |
| Want the OTP/body in an alert | Not supported. Read the actual security message in your official Telegram app; alerts intentionally exclude all codes, text and login links. |
| Login email shows NOT SET | This bot only changes an existing login email. Set it up in the official Telegram app if offered; no sign-in/SMS flow is started here. |
| Emailed code was rejected | Re-check the same mailbox and the saved request, then retry within three attempts. Wrong codes are never stored or echoed, and no automatic resend occurs. |
| Email request outcome uncertain | Check the new mailbox and open `/email`; use the saved step or refresh the status. The bot never claims success without Telegram's confirmation. |
| Invalid/expired session | Import is rejected without consuming a new profile slot or changing another job. |
| Same account has a changed phone | Phone verification is requested again. |
| Telegram cooldown/session too fresh | Wait until Telegram allows the operation. No supported bypass exists. |
| Missing `.secret.key` | Restore its matching private backup. Scheduled recovery pauses rather than losing the pending password. |
| Password update not confirmed | Check 2FA in the official app and keep the worker online. The old password may already be removed. |
| Polling conflict/existing webhook | Stop the other deployment; do not run two copies. |
| Host killed detached process | Use the hosting service/task; the manual launcher is not a supervisor. |
| Token shared | Stop process/task, revoke in @BotFather, run private `--setup`, restart. |

## Tests

```sh
.venv/bin/python -m unittest discover -s tests -v
```

Tests are offline and use fake Telegram responses: identity separation, independent jobs, restart/input resume, direct session routing, duplicate/active-job protection, password reply transitions, short/deletion timeouts, format fallback, cancellation/removal, encrypted storage, safe detached launch, import-only receipts, filename-independent detection, explicit scoped reset continuation, owner-only My IDs screens, pagination, account-bound dashboard actions, read-only refresh, and one-day/past-deadline offline recovery. The security-alert tests additionally cover fixed-peer adapters, code/text/link privacy, category-only state, initial baselines, restarts/deduplication, paginated/offline backlog, delivery retries, rate limits, UID pinning, independent workers and owner-only controls. New protection tests additionally cover safe initial trust, current-session immunity, final live revalidation, OFF/ON races, retry restrictions, ambiguous revocation, confirmation by absence, durable seen/candidate state, identity isolation, per-account controls and three-worker shutdown. The v2.6 login-email tests cover address/code validation, masking, encrypted-only storage, status separation (SET/NOT SET/UNKNOWN vs 2FA recovery email), change-only refusal without any send RPC, profile-bound nonces, durable intent, rate limits, wrong/expired/uncertain codes, sensitive-phase blocking, restart resume without resend, adapter request shapes and dashboard placement. A live seven-day recovery or a real email change is not simulated by installing this code.

## References

- [1](https://core.telegram.org/api/srp) Telegram logged-in password-reset flow
- [2](https://core.telegram.org/constructor/account.password) Telegram password status and pending reset
- [Telethon reset](https://tl.telethon.dev/methods/account/reset_password.html)
- [Pyrogram password enable](https://docs.pyrogram.org/api/methods/enable_cloud_password)

- [Telethon authorization listing](https://tl.telethon.dev/methods/account/get_authorizations.html)
- [Telethon individual authorization reset](https://tl.telethon.dev/methods/account/reset_authorization.html)
- [Telethon sendVerifyEmailCode](https://tl.telethon.dev/methods/account/send_verify_email_code.html)
- [Telethon verifyEmail](https://tl.telethon.dev/methods/account/verify_email.html)
- [Login-change purpose](https://tl.telethon.dev/constructors/email_verify_purpose_login_change.html)
