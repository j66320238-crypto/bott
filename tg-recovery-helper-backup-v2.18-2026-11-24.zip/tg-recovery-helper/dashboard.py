"""Read-only account lists and timer screens. No Telegram session RPCs here.

A countdown is always absolute_deadline - current_time, never a persisted number
of seconds. Refreshing a screen cannot start/restart/cancel a saved recovery.
Only explicitly selected, non-secret profile fields are rendered.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

from telegram import InlineKeyboardButton as Button, InlineKeyboardMarkup as Markup

from recovery import remaining
from sessions import phone_digits
from security_alerts import alert_status
from login_guard import guard_status, other_devices_text
from login_email import email_lines

PAGE_SIZE = 5
IST = timezone(timedelta(hours=5, minutes=30), name="IST")


def date_time(value: int, *, utc: bool = False) -> str:
    if not value:
        return "Not scheduled"
    return datetime.fromtimestamp(int(value), timezone.utc if utc else IST).strftime("%d %b %Y, %H:%M:%S %Z")


def countdown(deadline: int, now: int) -> str:
    seconds = int(deadline) - int(now)
    if seconds <= 0:
        return "Due now"
    return "Less than 1 minute" if seconds < 60 else remaining(deadline, now)


def phone_number(data: dict) -> str:
    # detected_phone is for display only; it never grants verification.
    value = data.get("owner_phone") if data.get("registered") else data.get("detected_phone")
    digits = phone_digits(str(value or ""))
    return "+" + digits if 7 <= len(digits) <= 15 else "Not available yet"


@dataclass(frozen=True)
class JobView:
    title: str
    kind: str = "none"
    deadline: int = 0
    deadline_label: str = ""
    note: str = ""


def job_view(data: dict, now: int) -> JobView:
    status = data.get("reset_status", "idle")
    phase = data.get("phase", "idle")
    apply = data.get("password_apply_status", "not_started")
    if status == "waiting":
        if phase in ("old_removed", "applying"):
            return JobView(
                "Applying new password" if phase == "applying" else "Old password removed; password application pending",
                kind="apply", note="New 2FA is not confirmed yet. Do not start another reset.",
            )
        if data.get("wait_kind") == "cooldown" or phase == "cooldown":
            date = int(data.get("retry_at") or 0)
            return JobView(
                "Eligibility cooldown" if date > now else "Eligibility check due",
                kind="cooldown", deadline=date, deadline_label="Next eligible request",
                note="The seven-day reset timer has NOT started. Telegram decides when a request is allowed.",
            )
        date = int(data.get("reset_until_date") or 0)
        if date:
            return JobView(
                "Reset waiting" if date > now else "Reset deadline reached; check pending",
                kind="reset", deadline=date, deadline_label="Telegram reset deadline",
                note="Offline time counts. Restarting the bot does not restart this timer.",
            )
        return JobView("Reconciling confirmed request", note="Waiting for an official Telegram result. No deadline is guessed locally.")
    if apply == "enabled_unconfirmed":
        return JobView("2FA is ON; password needs verification", note="Verify the password in the official Telegram app. The bot will not reset it again automatically.")
    if apply == "manual_required":
        return JobView("Manual password setup required", note="New 2FA was not confirmed. Check the official app before using Enable 2FA.")
    if status == "done":
        return JobView("Completed; new 2FA confirmed" if apply == "applied" else "Saved job completed", note="No recovery email was required for this password. It is not shown in chat.")
    if status == "cancelled":
        return JobView("Cancelled; no active saved job")
    return JobView("Ready; no reset requested" if data.get("registered") else "Phone verification needed" if data.get("detected_user_id") or data.get("account_user_id") else "Session not added yet")


def account_button(key: str, action: str, text: str) -> Button:
    return Button(text, callback_data=f"acct:{key}:{action}")


def account_keyboard(key: str, data: dict, *, more: bool = False) -> Markup:
    if more:
        return Markup([
            [account_button(key, "verify", "Verify phone"), account_button(key, "session", "Session setup")],
            [account_button(key, "email", "Email"), account_button(key, "set", "Enable 2FA if OFF")],
            [account_button(key, "alerts", "Security alerts"), account_button(key, "devices", "Other devices")],
            [account_button(key, "guard", "Protection lock")],
            [account_button(key, "remove", "Remove local profile"), account_button(key, "refresh", "Back to this account")],
            [Button("My IDs", callback_data="myids")],
        ])
    rows = [[account_button(key, "refresh", "Refresh timer"), account_button(key, "live", "Live status")]]
    if data.get("reset_status") == "waiting":
        rows += [[account_button(key, "check", "Check saved job")],
                 [account_button(key, "cancel", "Cancel THIS reset")]]
    else:
        rows.append([account_button(key, "reset", "Reset password"), account_button(key, "check", "Check saved job")])
    rows += [
        [account_button(key, "email", "Email"), account_button(key, "spam", "SpamBot check")],
        [account_button(key, "alerts", "Security alerts"), account_button(key, "devices", "Other devices")],
        [account_button(key, "guard", "Protection lock")],
        [account_button(key, "more", "More options"), Button("My IDs", callback_data="myids")],
        [Button("Main menu", callback_data="home")],
    ]
    return Markup(rows)


def import_screen(result, now: int) -> tuple[str, Markup]:
    """A successful upload is a receipt, not an implicit recovery wizard."""
    account = result.account
    data = account.store.reload()
    uid = int(data.get("account_user_id") or data.get("detected_user_id") or 0)
    library = {"telethon": "Telethon", "pyrogram": "Pyrogram"}.get(data.get("library"), "Detected")
    lines = ["ACCOUNT SELECTED" if result.kept_active_job else "SESSION SAVED",
             "Phone: " + phone_number(data), "Telegram ID: " + (str(uid) if uid else "Not detected yet"),
             "Format: " + library]
    if result.kept_active_job:
        view = job_view(data, now)
        lines += ["Existing session and saved job unchanged.", "Status: " + view.title]
        if view.deadline:
            lines += ["Remaining: " + countdown(view.deadline, now), "Deadline (IST): " + date_time(view.deadline)]
        if view.kind in ("cooldown", "apply"):
            lines.append(view.note)
    else:
        lines.append("Phone and Telegram ID came from the live session. No number needs to be typed. No reset started.")
    rows = [[account_button(account.key, "refresh", "Open account"), Button("My IDs", callback_data="myids")]]
    if data.get("reset_status") == "waiting":
        rows.append([account_button(account.key, "check", "Check saved job")])
    else:
        rows.insert(0, [account_button(account.key, "reset", "Reset password")])
    return "\n".join(lines), Markup(rows)


def account_screen(account, now: int, *, more: bool = False, master_enabled: bool = True, universal_set: bool | None = None) -> tuple[str, Markup]:
    data = account.store.reload()
    view = job_view(data, now)
    uid = int(data.get("account_user_id") or data.get("detected_user_id") or 0)
    label = " ".join(str(data.get("label") or "Account").split())[:60]
    library = {"telethon": "Telethon", "pyrogram": "Pyrogram"}.get(data.get("library"), "Not detected")
    lines = [
        "ACCOUNT OPTIONS" if more else "ACCOUNT DASHBOARD", label,
        "Phone: " + phone_number(data), "Telegram ID: " + (str(uid) if uid else "Not detected yet"),
        "Phone verification: " + ("Verified from the live session" if data.get("registered") else "Required before recovery"),
        *(["Universal password: " + ("SET — Reset uses it" if universal_set else "NOT SET — open Universal password")] if universal_set is not None else []),
        "Session format: " + library, *email_lines(data),
        "Security alerts: " + alert_status(data, master_enabled),
        "Protection lock: " + guard_status(data),
        other_devices_text(data),
        "", "Saved job: " + view.title,
    ]
    if view.deadline:
        lines += ["Remaining: " + countdown(view.deadline, now),
                  view.deadline_label + " (IST): " + date_time(view.deadline),
                  "Same deadline (UTC): " + date_time(view.deadline, utc=True)]
    elif data.get("reset_status") != "waiting":
        lines.append("Timer: No active saved countdown")
    if view.note:
        lines.append(view.note)
    retry = int(data.get("next_attempt_at") or 0)
    if data.get("reset_status") == "waiting" and retry > now and retry != view.deadline:
        lines += ["Next permitted attempt (IST): " + date_time(retry), "Retry in: " + countdown(retry, now)]
    if data.get("last_error_code"):
        lines.append("Last check needs attention. Use Live status; saved work is preserved.")
    lines += ["", "Updated: " + date_time(now),
              "This is a snapshot. Refresh checks devices once and does not send a reset request.",
              "Confirmed jobs continue on their saved timer. If the bot is offline at the deadline, action waits until it is online again."]
    return "\n".join(lines), account_keyboard(account.key, data, more=more)


def accounts_screen(registry, now: int, page: int = 0) -> tuple[str, Markup]:
    keys = registry.keys()
    pages = max(1, (len(keys) + PAGE_SIZE - 1) // PAGE_SIZE)
    page = max(0, min(int(page), pages - 1))
    start = page * PAGE_SIZE
    entries = []
    jobs = detected = 0
    for key in keys:
        try:
            data = registry.get(key).store.reload()
            uid = int(data.get("account_user_id") or data.get("detected_user_id") or 0)
            detected += bool(uid)
            jobs += data.get("reset_status") == "waiting"
            entries.append((key, data, uid, job_view(data, now)))
        except Exception:
            # One unreadable child must not hide the remaining saved IDs.
            entries.append((key, None, 0, None))
    lines = ["MY IDs", f"Detected IDs: {detected} | Saved profiles: {len(keys)} | Active jobs: {jobs}",
             f"Page {page + 1}/{pages} — tap a number to open its options.", ""]
    buttons = []
    for index, (key, data, uid, view) in enumerate(entries[start:start + PAGE_SIZE], start + 1):
        if data is None:
            lines += [f"{index}. Profile unavailable — restore its private backup.", ""]
            continue
        label = " ".join(str(data.get("label") or "Account").split())[:40]
        phone = phone_number(data)
        marker = " [SELECTED]" if key == registry.active_key else ""
        lines += [f"{index}. {label}{marker}", f"Phone: {phone} | ID: {uid or 'Not detected'}",
                  view.title + (" | " + countdown(view.deadline, now) if view.deadline else ""),
                  "Lock: " + guard_status(data), ""]
        button_label = f"{index}. {phone} | ID {uid}" if uid else f"{index}. {label} — finish setup"
        buttons.append([Button(button_label[:64], callback_data="account:" + key)])
    navigation = []
    if page:
        navigation.append(Button("Previous", callback_data=f"myids:{page - 1}"))
    if page + 1 < pages:
        navigation.append(Button("Next", callback_data=f"myids:{page + 1}"))
    if navigation:
        buttons.append(navigation)
    buttons += [[Button("Add my account", callback_data="addaccount"), Button("Refresh list", callback_data=f"myids:{page}")],
                [Button("Security alerts", callback_data="alerts"), Button("Main menu", callback_data="home")]]
    lines += ["Send another OWN .session document to add/select its account automatically.",
              "Opening accounts never restarts or cancels confirmed timers.", "Updated: " + date_time(now)]
    return "\n".join(lines), Markup(buttons)
