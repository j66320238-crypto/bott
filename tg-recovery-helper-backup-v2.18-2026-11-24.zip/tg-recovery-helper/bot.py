#!/usr/bin/env python3
"""Private multi-account Telegram recovery UI (English).

owner_id controls WHO may operate the bot. account_user_id identifies WHICH
verified account a profile manages. They are deliberately independent.
Only the owner's own accounts may be enrolled. No bulk reset or wait bypass.
"""
from __future__ import annotations

import argparse
import asyncio
import contextlib
import getpass
import hmac
import logging
import os
import re
import secrets
import time
from pathlib import Path

from telegram import BotCommand, InlineKeyboardButton as Button, InlineKeyboardMarkup as Markup, Update
from telegram.constants import ChatType
from telegram.error import BadRequest
from telegram.ext import Application, CallbackQueryHandler, CommandHandler, ContextTypes, MessageHandler, filters

from accounts import AccountRegistry, scheduler_delay
from dashboard import account_keyboard, account_screen, accounts_screen, import_screen
from ingest import SessionRouter, ImportResult
from security_alerts import SecurityMonitor, alerts_screen, ENABLED_KEY
from login_guard import LoginGuard, protection_screen
from otp_forward import OtpForwarder
from login_email import (CACHE_KEY, LoginEmailService, change_state, email_lines, email_screen,
                         info_cache, masked_email)
from ui_state import pin_owner_message, restore as restore_ui, save as save_ui, durable_handler
from sessions import MAX_SESSION_BYTES, account_identity, public_error
from storage import ProcessLock, SafeError, Store, private_mode

ROOT = Path(__file__).resolve().parent
VERSION = "2.18"
log = logging.getLogger(__name__)
FOOTER = "\n\nTelegram controls the required wait; it cannot be skipped."
INPUT_DELETE_TIMEOUT = 2


def menu() -> Markup:
    return Markup([
        [Button("My IDs", callback_data="myids"), Button("Current account", callback_data="dashboard")],
        [Button("Reset password", callback_data="reset"), Button("Universal password", callback_data="universal")],
        [Button("Live status", callback_data="status"), Button("Protection lock", callback_data="protection")],
        [Button("Add my account", callback_data="addaccount"), Button("SpamBot check", callback_data="spamcheck")],
        [Button("Check saved job", callback_data="check"), Button("Cancel THIS reset", callback_data="cancel")],
        [Button("Security alerts", callback_data="alerts"), Button("Session setup", callback_data="session")],
        [Button("Email", callback_data="email"), Button("Help", callback_data="help")],
    ])


def owner_allowed(user_id: int | None, chat_type: str | None, owner_id: int) -> bool:
    return bool(owner_id and user_id == owner_id and chat_type == ChatType.PRIVATE)


def runtime_of(context):
    return context.application.bot_data["runtime"]


async def allowed(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    rt = runtime_of(context)
    uid = update.effective_user.id if update.effective_user else None
    chat_type = update.effective_chat.type if update.effective_chat else None
    if owner_allowed(uid, chat_type, int(rt.store.data["owner_id"])):
        restore_ui(context)
        return True
    if update.callback_query:
        with contextlib.suppress(Exception):
            await update.callback_query.answer("Access denied.", show_alert=True)
    elif update.effective_message:
        with contextlib.suppress(Exception):
            await update.effective_message.reply_text("Access denied.")
    return False


async def reply(update: Update, context, text: str, keyboard: Markup | None = None, *, edit=False, show_active=True, wait_notice=True):
    if not update.effective_message:
        return
    save_ui(context)  # Save the next input step BEFORE displaying its prompt.
    try:
        label = runtime_of(context).current.label()
    except Exception:
        label = "Account setup — use /accounts"
    body = (("ACTIVE: " + label + "\n\n" if show_active else "") + text)[:3600] + (FOOTER if wait_notice else "")
    options = {"reply_markup": keyboard or menu(), "disable_web_page_preview": True}
    query = update.callback_query
    if edit and query and callable(getattr(query, "edit_message_text", None)):
        try:
            await query.edit_message_text(body, **options)
            return
        except BadRequest as error:
            if "message is not modified" in str(error).lower():
                return
            # An old/non-editable message gets a fresh screen instead.
    await update.effective_message.reply_text(body, **options)


async def erase_input(update: Update):
    # Best effort only; deleting a cloud-chat message is not secure erasure.
    if update.effective_message:
        with contextlib.suppress(Exception):
            await asyncio.wait_for(update.effective_message.delete(), timeout=INPUT_DELETE_TIMEOUT)


def clear_draft(context):
    for key in ("flow", "draft", "after_session", "session_choices", "session_account", "session_intent_at",
                "cancel_nonce", "cancel_account", "remove_nonce", "remove_account",
                "upload_nonce", "upload_account", "upload_until",
                "email_account", "email_nonce", "email_created"):
        context.user_data.pop(key, None)
    save_ui(context)


def same_account(context, key: str) -> bool:
    return bool(key and key == runtime_of(context).registry.active_key)


class Runtime:
    def __init__(self, store: Store):
        self.store = store  # Controller secrets + owner_id, never an active account state.
        self.registry = AccountRegistry(store)
        self.vault = self.registry.vault
        self.router = SessionRouter(self.registry)
        self.notice_lock = asyncio.Lock()
        self.task = None
        self.security = SecurityMonitor(self.registry, self.store)
        self.security_task = None
        self.guard = LoginGuard(self.registry, self.store)
        self.guard_task = None
        self.email = LoginEmailService(self.registry, self.store)
        self.otp_forward = OtpForwarder(self.registry, self.store)

        async def _official_message_seen(account):
            # The forwarder is the only reader of the official chat: a new
            # message asks the login guard and the security monitor once.
            # Idle workers otherwise only deliver what is already saved.
            for check in (self.guard.poll_account, self.security.poll_account):
                try:
                    await check(account)
                except asyncio.CancelledError:
                    raise
                except Exception as error:
                    log.warning("Official-message follow-up deferred (%s); no values logged",
                                type(error).__name__)

        self.otp_forward.on_login = _official_message_seen
        self.otp_forward_task = None

    @property
    def current(self):
        return self.registry.get()

    @property
    def account_store(self):
        return self.current.store

    @property
    def sessions(self):
        return self.current.sessions

    @property
    def engine(self):
        return self.current.engine

    async def flush(self, app: Application):
        async with self.notice_lock:
            sources = [(None, self.store, "Controller notice")]
            for key in self.registry.keys():
                try:
                    account = self.registry.get(key)
                    sources.append((key, account.store, account.label()))
                except Exception as error:
                    log.warning("Skipped unreadable account notice queue (%s)", type(error).__name__)
            for key, store, label in sources:
                while store.reload()["notices"]:
                    text = store.data["notices"][0]
                    keyboard = Markup([[Button("Open this account", callback_data="account:" + key)],
                                       [Button("My IDs", callback_data="myids")]]) if key else menu()
                    pin = text.startswith("PIN\n")
                    body = text[4:] if pin else text
                    try:
                        sent = await app.bot.send_message(
                            int(self.store.data["owner_id"]),
                            ("UPDATE FOR: " + label + "\n\n" + body)[:3600] + FOOTER,
                            reply_markup=keyboard, disable_web_page_preview=True,
                        )
                    except Exception as error:
                        log.warning("Owner notification retained (%s)", type(error).__name__)
                        break
                    notices = list(store.reload()["notices"])
                    if text in notices:
                        notices.remove(text)
                    store.update(notices=notices)
                    if pin:
                        await pin_owner_message(app.bot, int(self.store.data["owner_id"]), sent)

    async def email_status_baseline(self):
        """Read-only login-email status fill; failures stay per-account and silent."""
        try:
            await asyncio.sleep(5)  # Startup does not contact account sessions.
        except asyncio.CancelledError:
            raise
        except Exception as error:
            log.warning("Login-email status baseline skipped (%s); no values logged", type(error).__name__)

    async def worker(self, app: Application):
        while True:
            try:
                await self.registry.tick_all()
                await self.flush(app)
            except asyncio.CancelledError:
                raise
            except Exception as error:
                log.warning("Scheduler iteration failed (%s); no raw values logged", type(error).__name__)
            interval = int(self.store.data.get("scheduler_interval_seconds", 3600))
            await asyncio.sleep(scheduler_delay(int(time.time()), interval, self.registry.next_due()))


WELCOME = (
    "Private Multi-Account Recovery Bot\n\n"
    "Send your OWN logged-in Telethon/Pyrogram session file. Any filename is fine. "
    "I will add/select its account and show a short account card, without phone/password questions just to add it.\n\n"
    "/resetpassword — recover the selected account\n"
    "/myids — phone numbers, IDs, timers and account options\n"
    "/spamcheck — official SpamBot reply for the selected account\n"
    "/alerts — code-free Telegram and new-login alerts\n"
    "/protection — per-account new-login protection lock (default ON)\n"
    "/email — login-email status and change for the selected account\n"
    "/cancel — stop current input / confirm cancellation of a saved job\n\n"
    "Only the configured owner may operate this bot. Account IDs may differ from the owner's ID. "
    "Uploads and typed passwords pass through Telegram cloud chats. No reset starts without the final account-specific confirmation."
)
HELP = (
    "QUICK FLOW\n"
    "1. Send your OWN logged-in SQLite session file directly. Filename/extension do not matter.\n"
    "2. The account is added/selected and shown in a short card. No phone/password input is required just to add it.\n"
    "3. Set /universal once. Reset uses that saved password. The session phone and ID are taken automatically. No email.\n"
    "4. Press the final confirmation for the displayed account. Telegram supplies the reset/cooldown date.\n"
    "5. Saved jobs are checked on startup and hourly. Password set skips email and applies the saved password.\n\n"
    "COMMANDS\n"
    "/protection, /lock, /unlock, /alerts, /email, /myids (also /accounts), /timer, /resetpassword (also /reset, /reset_start), "
    "/addaccount, /session, /verify, /status, /check, /cancel, /setpassword, /universal, /removeaccount, /spamcheck.\n"
    "Commands affect only the displayed account; switching never stops other timers. Re-uploading an account with an active job "
    "selects it without replacing its session or timer.\n\n"
    "My IDs lists saved phone numbers and Telegram IDs. Tap an account for its timer and options. Refresh timer only recalculates "
    "the displayed snapshot; it does not send a reset. Times are shown in IST and UTC. Offline time still counts: remaining time is "
    "the saved Telegram deadline minus the current time, not seven new days after restart. If the bot is offline when due, "
    "completion waits until it is running again.\n\n"
    "SECURITY ALERTS\n"
    "Official Telegram service-chat arrivals are checked about every 30 seconds while online, independently of hourly recovery. "
    "New valid accounts default ON. Alerts contain only category, account and time, never OTP digits, message text, media or login links. "
    "OTP classification is best effort; an unrecognized type is a generic Telegram-message alert. First enable sets a baseline without "
    "replaying old messages; later downtime is caught up if Telegram retains them. Use /alerts for all-account or account-specific ON/OFF buttons.\n\n"
    "PROTECTION LOCK\n"
    "Default ON for every own-account profile; stays ON until manually OFF, including after seven days. Existing sessions at enable time "
    "and this bot session stay trusted and are never logged out. New active sessions are individually revoked while ON. Not a pre-login block; "
    "polling/Telegram limits apply and failure is never called success. Your own NEW login is also a target: /unlock first, then /lock after. "
    "Alert switches never disable the lock.\n\n"
    "LOGIN EMAIL\n"
    "/email (and dashboards) show Login email plus a separate 2FA recovery-email status. Only an EXISTING login email can be changed: enter "
    "the new address, press Send code, then enter the code EMAILED to it. NOT SET means no sign-in/SMS setup is started; use the official app "
    "if offered. Login email is NOT the 2FA recovery email and never bypasses password recovery. Address/code pass through this private chat; "
    "codes are never echoed or saved. Sensitive password phases block changes; Telegram limits apply.\n\n"
    "Input steps survive a restart; unfinished input expires after 10 minutes and /cancel clears it. A detached process survives SSH disconnect, "
    "but host shutdown/limits still need managed hosting or a scheduled task.\n\n"
    "SAFETY\n"
    "Enroll only your own accounts. Never share sessions, tokens, API hashes, OTPs or passwords. Bot uploads and password messages pass through "
    "Telegram servers, not secret chats. Input deletion is best effort. Passwords remain encrypted on disk without extra UI steps. "
    "No OTP collection, account deletion, bulk reset or wait bypass is implemented.\n"
)

@durable_handler
async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await allowed(update, context): return
    clear_draft(context)
    await reply(update, context, WELCOME)
    await runtime_of(context).flush(context.application)


@durable_handler
async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await allowed(update, context):
        await reply(update, context, HELP)


async def accounts_action(update, context, page=0):
    rt = runtime_of(context)
    clear_draft(context)  # Confirmed profile jobs are not UI drafts.
    text, keyboard = accounts_screen(rt.registry, int(time.time()), page)
    await reply(update, context, text, keyboard, edit=True, show_active=False, wait_notice=False)


@durable_handler
async def accounts_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await allowed(update, context): await accounts_action(update, context)


async def dashboard_action(update, context, key=None, *, more=False, check=False):
    rt = runtime_of(context)
    if key is not None:
        rt.registry.select(key)  # Reject removed/invalid profiles; never fall back.
        clear_draft(context)  # A selection invalidates unfinished confirmations.
    notice = ""
    if check:
        try:
            count = await rt.guard.refresh_devices(rt.current)
            notice = f"Checked once. Other devices: {count}. The bot session was not logged out.\n\n"
        except Exception as error:
            notice = "Device check did not finish (" + type(error).__name__ + "). Last saved count is shown. The session was not logged out.\n\n"
    text, keyboard = account_screen(rt.current, int(time.time()), more=more,
                                    master_enabled=rt.store.reload().get(ENABLED_KEY, True),
                                    universal_set=str(rt.store.reload().get("universal_password") or "").startswith("fernet:"))
    await reply(update, context, notice + text, keyboard, edit=True, show_active=False, wait_notice=False)


@durable_handler
async def timer_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await allowed(update, context): await dashboard_action(update, context)


async def alerts_action(update, context, key=None, page=0):
    rt = runtime_of(context)
    clear_draft(context)
    text, keyboard = alerts_screen(rt.registry, rt.store, key=key, page=page)
    await reply(update, context, text, keyboard, edit=True, show_active=False, wait_notice=False)


@durable_handler
async def alerts_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await allowed(update, context): await alerts_action(update, context)


async def devices_action(update, context, key):
    rt = runtime_of(context)
    account = rt.registry.get(key)
    text = await rt.guard.device_report(account)
    keyboard = Markup([
        [Button("Refresh devices", callback_data=f"acct:{key}:devices"),
         Button("Protection lock", callback_data=f"acct:{key}:guard")],
        [Button("Back to account", callback_data=f"acct:{key}:refresh")],
    ])
    await reply(update, context, text, keyboard, edit=True, show_active=False, wait_notice=False)


async def protection_action(update, context, key=None, page=0):
    rt = runtime_of(context)
    clear_draft(context)
    text, keyboard = protection_screen(rt.registry, rt.store, key=key, page=page)
    await reply(update, context, text, keyboard, edit=True, show_active=False, wait_notice=False)


@durable_handler
async def protection_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await allowed(update, context): await protection_action(update, context)


@durable_handler
async def lock_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await allowed(update, context): return
    rt = runtime_of(context)
    await rt.guard.set_lock(rt.registry.active_key, True)
    await protection_action(update, context, key=rt.registry.active_key)


@durable_handler
async def unlock_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await allowed(update, context): return
    rt = runtime_of(context)
    await rt.guard.set_lock(rt.registry.active_key, False)
    await protection_action(update, context, key=rt.registry.active_key)


EMAIL_STEPS = ("email_new", "email_code", "email_confirm")
EMAIL_RESUME = ("sending", "send_uncertain", "awaiting_code", "verifying", "verify_uncertain")


async def email_action(update, context, key=None, *, refresh=False, notice=""):
    rt = runtime_of(context)
    if key is not None:
        rt.registry.select(key)  # Stale/removed profiles never fall back silently.
    account = rt.current
    prefix = ""
    if refresh:
        try:
            await rt.email.refresh(account.key)
        except SafeError as error:
            prefix = str(error) + "\n\n"
    text, keyboard = email_screen(account)
    await reply(update, context, ((notice + "\n\n") if notice else "") + prefix + text, keyboard,
                edit=True, show_active=False, wait_notice=False)


@durable_handler
async def email_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await allowed(update, context): await email_action(update, context)


def email_binding(context) -> bool:
    account = context.user_data.get("email_account", "")
    created = context.user_data.get("email_created", 0)
    return (same_account(context, account) and isinstance(created, (int, float))
            and 0 <= int(time.time()) - int(created) <= 600)


async def email_change_action(update, context, key):
    rt = runtime_of(context)
    rt.registry.select(key)
    account = rt.current
    state = await rt.email.begin(account.key)  # Fresh official status; refuses NOT SET/unsupported.
    if state["stage"] in EMAIL_RESUME:
        await email_action(update, context, key=account.key,
                           notice="A saved login-email step already exists for this account. Nothing was resent. "
                                  "Use Resume or Stop LOCAL input on the screen below.")
        return
    context.user_data.update(flow="email_new", email_account=account.key, email_nonce="", email_created=int(time.time()))
    await reply(update, context,
        "Send the NEW login email for this account, for example name@example.com. "
        "Nothing is sent to Telegram until you confirm after typing, and no code is requested yet. "
        "This changes the LOGIN email only; it is not the 2FA recovery email. /cancel stops input.",
        Markup([[Button("Stop input", callback_data=f"acct:{account.key}:emailcancel")],
                [Button("Back to Email", callback_data=f"acct:{account.key}:email")]]))


async def email_resume_action(update, context, key):
    rt = runtime_of(context)
    rt.registry.select(key)
    account = rt.current
    state = change_state(account.store.reload())
    if state["stage"] in ("awaiting_code", "send_uncertain", "sending") and state["nonce"]:
        context.user_data.update(flow="email_code", email_account=account.key,
                                 email_nonce=state["nonce"], email_created=int(time.time()))
        await reply(update, context,
            "RESUME SAVED LOGIN-EMAIL STEP\nNew login email: " + (state["new_pattern"] or "configured (hidden)") +
            "\n\nEnter the verification code that Telegram emailed to that address. Only that emailed code — never a Telegram login code. "
            "It is deleted from this chat best-effort and never stored or echoed. No resend happens automatically. /cancel stops input.",
            Markup([[Button("Stop input", callback_data=f"acct:{account.key}:emailcancel")],
                    [Button("Back to Email", callback_data=f"acct:{account.key}:email")]]))
        return
    await email_action(update, context, key=account.key,
                       notice="This saved email step cannot continue automatically. Review the status below; "
                              "a new request is only started when you explicitly choose Change LOGIN email.")


async def email_cancel_action(update, context, key):
    rt = runtime_of(context)
    rt.registry.select(key)
    clear_draft(context)
    await rt.email.cancel_local(rt.current.key)
    await email_action(update, context, key=rt.current.key,
                       notice="Local email input stopped. No Telegram call was made, no code was replayed, "
                              "and a code already emailed can still be used from Resume until it expires.")


async def account_option(update, context, key, action):
    actions = {"refresh", "more", "reset", "live", "check", "cancel", "spam", "verify", "session", "remove", "set",
               "alerts", "alerts_on", "alerts_off", "guard", "guard_on", "guard_off", "devices",
               "email", "emailrefresh", "emailchange", "emailresume", "emailcancel"}
    if action not in actions:
        raise SafeError("This account option has expired. Open My IDs again.")
    rt = runtime_of(context)
    if action in ("guard", "guard_on", "guard_off"):
        rt.registry.get(key)
        if action != "guard": await rt.guard.set_lock(key, action == "guard_on")
        await protection_action(update, context, key=key)
        return
    if action in ("email", "emailrefresh", "emailchange", "emailresume", "emailcancel"):
        rt.registry.get(key)  # A stale/removed account must never fall back.
        if action == "email": await email_action(update, context, key=key)
        elif action == "emailrefresh": await email_action(update, context, key=key, refresh=True)
        elif action == "emailchange": await email_change_action(update, context, key)
        elif action == "emailresume": await email_resume_action(update, context, key)
        else: await email_cancel_action(update, context, key)
        return
    if action in ("alerts", "alerts_on", "alerts_off"):
        rt.registry.get(key)  # A stale/removed account must never fall back.
        if action != "alerts":
            await rt.security.set_enabled(key, action == "alerts_on")
        await alerts_action(update, context, key=key)
        return
    if action in ("refresh", "more"):
        if key != rt.registry.active_key:
            rt.registry.select(key)
            clear_draft(context)
        else:
            rt.registry.get(key)  # Validate even same-account stale callbacks.
        await dashboard_action(update, context, more=(action == "more"), check=(action == "refresh"))
        return
    # The key is carried by EVERY account-screen action. A button from an older
    # screen cannot accidentally act on whichever other account is selected now.
    rt.registry.select(key)
    clear_draft(context)
    if action == "reset": await begin_reset(update, context)
    elif action == "devices": await devices_action(update, context, key)
    elif action == "live": await status_action(update, context)
    elif action == "check": await check_action(update, context)
    elif action == "cancel": await cancel_action(update, context)
    elif action == "spam": await spamcheck_action(update, context)
    elif action == "verify": await ask_phone(update, context, "verify")
    elif action == "session": await show_sessions(update, context)
    elif action == "remove": await remove_action(update, context)
    elif action == "set": await setpassword_command(update, context)


async def addaccount_action(update, context):
    # Do not consume a blank profile slot merely because Add was tapped.
    # The identity-based importer creates/reuses a profile only after validation.
    clear_draft(context)
    await show_sessions(update, context)


@durable_handler
async def addaccount_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await allowed(update, context): await addaccount_action(update, context)


async def ask_phone(update, context, mode="reset"):
    rt = runtime_of(context)
    await rt.sessions.ensure()
    rt.registry.assert_unique()
    context.user_data["flow"] = "phone"
    context.user_data["draft"] = {"mode": mode, "created": int(time.time()), "account_key": rt.registry.active_key}
    await reply(update, context,
        "Enter THIS session account's phone number with country code, e.g. +919876543210. "
        "This check does not start a reset.")



def acceptable_password(text: str) -> bool:
    return isinstance(text, str) and 10 <= len(text) <= 128 and "\x00" not in text and "\n" not in text and "\r" not in text


def password_confirm_text(draft: dict, data: dict) -> str:
    if draft.get("mode") == "set":
        action = "If 2FA is OFF, this saved password is applied now. No email is requested or set. "
    else:
        action = ("No email is requested. If 2FA is already OFF, this saved password is applied now. "
                  "If 2FA is ON, Telegram's official timer still applies; the saved password is applied "
                  "as soon as Telegram removes the old one. No waiting period is skipped. ")
    source = "The saved universal password will be used. It is not shown. " if draft.get("universal") else "Password saved for this account only. It is not shown again. "
    return ("CONFIRM THIS ACCOUNT\n" + account_identity(data) + "\n\n" + source + action
            + "This bot session is not logged out. Other accounts are not changed.")


def password_confirm_markup(draft: dict):
    label = "Use universal password on THIS account" if draft.get("universal") else "Apply saved password for THIS account"
    return Markup([[Button(label, callback_data="begin:" + draft["nonce"])],
                   [Button("Cancel input", callback_data="cancel")]])


async def ask_password(update, context, mode="reset"):
    rt = runtime_of(context)
    context.user_data["flow"] = "password"
    context.user_data["draft"] = {
        "mode": mode, "created": int(time.time()), "account_key": rt.registry.active_key,
        "account_user_id": int(rt.account_store.data["account_user_id"]),
    }
    await reply(update, context,
        "No universal password is saved yet. Send a password for THIS account only (10-128 characters). "
        "No email is asked. It is saved privately and applied with no email step. "
        "Next I will ask you to enter it again; /cancel stops input.")


async def offer_saved_password(update, context, mode="reset"):
    rt = runtime_of(context)
    saved = str(rt.store.reload().get("universal_password") or "")
    if saved.startswith("fernet:"):
        rt.vault.open(saved)  # Fail closed before showing a confirm card.
        draft = {
            "mode": mode, "created": int(time.time()), "account_key": rt.registry.active_key,
            "account_user_id": int(rt.account_store.data["account_user_id"]),
            "encrypted": saved, "hint": "", "nonce": secrets.token_hex(8), "universal": True,
        }
        context.user_data.update(draft=draft, flow="confirm")
        await reply(update, context, password_confirm_text(draft, rt.account_store.reload()), password_confirm_markup(draft))
        return
    await ask_password(update, context, mode)


async def ensure_registered(update, context, mode) -> bool:
    """Use the live session phone. Ask for a number only if Telegram did not provide one."""
    rt = runtime_of(context)
    data = rt.account_store.reload()
    if data.get("registered") and int(data.get("account_user_id") or 0):
        return True
    await rt.sessions.ensure()
    if rt.sessions.adopt_live_identity():
        return True
    await ask_phone(update, context, mode)
    return False


async def begin_reset(update: Update, context: ContextTypes.DEFAULT_TYPE, mode="reset"):
    rt = runtime_of(context)
    data = rt.account_store.reload()
    if data["reset_status"] == "waiting":
        await reply(update, context, "This account already has a saved job; no new timer was started.\n\n" + rt.engine.summary())
        return
    choices = rt.sessions.candidates()
    if not data["session_name"] and len(choices) != 1:
        context.user_data.update(after_session=mode, session_intent_at=int(time.time()))
        await show_sessions(update, context)
        return
    await rt.sessions.ensure()
    rt.registry.assert_unique()
    if not await ensure_registered(update, context, mode):
        return
    await offer_saved_password(update, context, mode)


async def universal_action(update, context):
    rt = runtime_of(context)
    saved = str(rt.store.reload().get("universal_password") or "")
    status = "SET" if saved.startswith("fernet:") else "NOT SET"
    await reply(update, context,
        "UNIVERSAL PASSWORD\nStatus: " + status + "\n\n"
        "One encrypted password is used when you press Reset or Enable 2FA. It is never shown, logged or included in the done message. "
        "A job that is already waiting keeps its own saved password. No session is logged out by saving this.",
        Markup([[Button("Set universal password", callback_data="universal:set")],
                [Button("Clear universal password", callback_data="universal:clear")],
                [Button("Main menu", callback_data="home")]]))


async def universal_set_action(update, context):
    clear_draft(context)
    context.user_data["flow"] = "universal_new"
    context.user_data["draft"] = {"created": int(time.time())}
    await reply(update, context, "Send the universal 2FA password (10-128 characters). You will enter it again. No email is asked. /cancel stops.")


async def universal_clear_action(update, context):
    rt = runtime_of(context)
    if not str(rt.store.reload().get("universal_password") or "").startswith("fernet:"):
        await reply(update, context, "No universal password is saved. Waiting jobs were not changed.")
        return
    nonce = secrets.token_hex(6)
    context.user_data.update(flow="universal_clear", draft={"nonce": nonce, "created": int(time.time())})
    await reply(update, context,
        "Clear the saved universal password? Waiting jobs keep their own saved password. Nothing is sent to Telegram.",
        Markup([[Button("Clear universal password", callback_data="univclear:" + nonce)],
                [Button("Keep it", callback_data="universal")]]))


@durable_handler
async def universal_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await allowed(update, context): await universal_action(update, context)


@durable_handler
async def reset_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await allowed(update, context): await begin_reset(update, context)


@durable_handler
async def verify_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await allowed(update, context): return
    if await ensure_registered(update, context, "verify"):
        data = runtime_of(context).account_store.reload()
        await reply(update, context, "Verified from the live session. No number needed.\n\n" + account_identity(data) + "\nNo reset was started.")


@durable_handler
async def setpassword_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await allowed(update, context): return
    rt = runtime_of(context)
    adapter = await rt.sessions.ensure()
    if (await adapter.info()).has_password:
        await reply(update, context, "2FA is already ON for this account. /setpassword will not change it. Use /resetpassword for official recovery.")
        return
    await begin_reset(update, context, mode="set")


async def status_action(update, context):
    rt = runtime_of(context)
    if not await ensure_registered(update, context, "status"):
        return
    adapter = await rt.sessions.ensure()
    info = await adapter.info()
    rt.account_store.update(**{CACHE_KEY: info_cache(info, int(time.time()))})
    login_email = ("SET (" + masked_email(info.login_email_pattern) + ")") if info.login_email_pattern else "NOT SET"
    if not getattr(info, "login_email_supported", False):
        login_email = "UNKNOWN — adapter unavailable"
    recovery_email = "UNCONFIRMED" if getattr(info, "recovery_email_unconfirmed", False) else ("SET" if info.has_recovery else "NOT SET")
    lines = ["LIVE STATUS FOR THE SELECTED ACCOUNT",
             f"Login email: {login_email}",
             f"2FA password: {'ON' if info.has_password else 'OFF'}",
             f"2FA recovery email: {recovery_email}",
             f"Hint: {info.hint or '(none)'}", f"Adapter: {rt.account_store.data['library']}"]
    if info.pending_reset_date:
        from recovery import when
        lines.append("Server pending-reset date: " + when(info.pending_reset_date))
    await reply(update, context, "\n".join(lines) + "\n\n" + rt.engine.summary(),
                account_keyboard(rt.registry.active_key, rt.account_store.reload()))


@durable_handler
async def status_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await allowed(update, context): await status_action(update, context)


async def check_action(update, context):
    rt = runtime_of(context)
    await reply(update, context, await rt.engine.tick(manual=True),
                account_keyboard(rt.registry.active_key, rt.account_store.reload()))
    await rt.flush(context.application)


@durable_handler
async def check_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await allowed(update, context): await check_action(update, context)


async def cancel_action(update, context):
    rt = runtime_of(context)
    clear_draft(context)
    if rt.account_store.reload()["reset_status"] != "waiting":
        await reply(update, context, "Input cancelled for this profile. No saved reset is active for it. Other accounts were not changed.")
        return
    context.user_data.update(cancel_nonce=secrets.token_hex(6), cancel_account=rt.registry.active_key)
    await reply(update, context,
        "Cancel ONLY the displayed account's saved job and active Telegram reset? Other accounts will continue. "
        "Telegram may impose a cooldown. An already-removed password cannot be restored by cancellation.",
        Markup([[Button("Yes, cancel THIS account's reset", callback_data="cancel_yes:" + context.user_data["cancel_nonce"])],
                [Button("Keep waiting", callback_data="status")]]))


@durable_handler
async def cancel_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await allowed(update, context): await cancel_action(update, context)


async def remove_action(update, context):
    rt = runtime_of(context)
    clear_draft(context)
    if rt.account_store.data["reset_status"] == "waiting":
        raise SafeError("This profile has an active saved job. Use /cancel for THIS account first; other profiles are unaffected.")
    context.user_data.update(remove_nonce=secrets.token_hex(6), remove_account=rt.registry.active_key)
    await reply(update, context,
        "Remove ONLY this local profile, its private runtime and uploaded local copies? "
        "This does not log out the Telegram account, delete chats, or remove original files in the shared sessions/ folder. "
        "Other profiles are not touched.",
        Markup([[Button("Remove this local profile", callback_data="remove_yes:" + context.user_data["remove_nonce"])],
                [Button("Keep profile", callback_data="accounts")]]))


@durable_handler
async def removeaccount_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await allowed(update, context): await remove_action(update, context)


async def show_sessions(update, context):
    rt = runtime_of(context)
    choices = rt.sessions.candidates()
    context.user_data.update(session_choices=choices, session_account=rt.registry.active_key)
    buttons = [[Button(f"{i+1}. {name[:50]}", callback_data=f"sess:{i}")] for i, name in enumerate(choices[:30])]
    buttons += [[Button("Accounts", callback_data="accounts")], [Button("Main menu", callback_data="home")]]
    await reply(update, context,
        "Send your OWN logged-in Telethon/Pyrogram session file, or choose one below. "
        "Any filename is fine; SQLite format, up to 5 MB. Adding a session does not start recovery.",
        Markup(buttons), wait_notice=False)


@durable_handler
async def session_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await allowed(update, context): return
    clear_draft(context)
    await show_sessions(update, context)


async def after_import(update, context, result: ImportResult):
    # Plain imports end at a short card, not a phone/password conversation.
    # Only a recent explicit /resetpassword prompt for this same profile may
    # continue the guided workflow after its missing session arrives.
    now = int(time.time())
    mode = context.user_data.get("after_session")
    started = context.user_data.get("session_intent_at", 0)
    continue_requested = (
        mode in ("reset", "set")
        and isinstance(started, (int, float)) and 0 <= now - started <= 600
        and context.user_data.get("session_account") == result.account.key
        and not result.kept_active_job
    )
    clear_draft(context)
    text, keyboard = import_screen(result, now)
    await reply(update, context, text, keyboard, show_active=False, wait_notice=False)
    if continue_requested:
        await begin_reset(update, context, mode=mode)


async def spamcheck_action(update, context):
    rt = runtime_of(context)
    if not await ensure_registered(update, context, "spamcheck"):
        return
    await reply(update, context, "Sending ONE /start to official @SpamBot through the SELECTED account. Waiting up to 24 seconds...")
    await reply(update, context, "OFFICIAL @SpamBot REPLY\n\n" + await rt.engine.spamcheck())


@durable_handler
async def spamcheck_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await allowed(update, context): await spamcheck_action(update, context)


@durable_handler
async def callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await allowed(update, context): return
    query = update.callback_query
    await query.answer()
    action = query.data or ""
    rt = runtime_of(context)
    if action == "home":
        clear_draft(context)
        await reply(update, context, WELCOME)
    elif action == "help": await reply(update, context, HELP)
    elif action == "alerts": await alerts_action(update, context)
    elif action == "email": await email_action(update, context)
    elif action == "protection": await protection_action(update, context)
    elif action.startswith("protection:page:"):
        try: page = int(action.rsplit(":", 1)[1])
        except ValueError: raise SafeError("This protection list has expired. Use /protection.") from None
        await protection_action(update, context, page=page)
    elif action in ("alerts:all_on", "alerts:all_off"):
        await rt.security.set_all(action == "alerts:all_on")
        await alerts_action(update, context)
    elif action.startswith("alerts:page:"):
        try: page = int(action.rsplit(":", 1)[1])
        except ValueError: raise SafeError("This alerts list has expired. Use /alerts.") from None
        await alerts_action(update, context, page=page)
    elif action in ("accounts", "myids"): await accounts_action(update, context)
    elif action.startswith("myids:"):
        try: page = int(action.split(":", 1)[1])
        except ValueError: raise SafeError("This account list has expired. Use /myids.") from None
        await accounts_action(update, context, page)
    elif action == "dashboard": await dashboard_action(update, context)
    elif action.startswith("acct:"):
        parts = action.split(":")
        if len(parts) != 3: raise SafeError("This account option has expired. Use /myids.")
        await account_option(update, context, parts[1], parts[2])
    elif action == "addaccount": await addaccount_action(update, context)
    elif action == "removeaccount": await remove_action(update, context)
    elif action == "verify": await verify_command(update, context)
    elif action == "universal": await universal_action(update, context)
    elif action == "universal:set": await universal_set_action(update, context)
    elif action == "universal:clear": await universal_clear_action(update, context)
    elif action.startswith("univclear:"):
        draft = context.user_data.get("draft") or {}
        nonce = str(draft.get("nonce") or "")
        given = action.split(":", 1)[1]
        if context.user_data.get("flow") != "universal_clear" or not nonce or len(nonce) != len(given) or not hmac.compare_digest(given, nonce):
            raise SafeError("That confirmation expired. Open Universal password again. Nothing was cleared.")
        rt.store.update(universal_password="")
        clear_draft(context)
        await reply(update, context, "Universal password cleared. It was not shown. Waiting jobs were not changed. No session was logged out.")
    elif action == "reset": await begin_reset(update, context)
    elif action == "status": await status_action(update, context)
    elif action == "check": await check_action(update, context)
    elif action == "cancel": await cancel_action(update, context)
    elif action == "spamcheck": await spamcheck_action(update, context)
    elif action.startswith("emailsend:"):
        nonce = action.split(":", 1)[1]
        if not email_binding(context) or not hmac.compare_digest(str(context.user_data.get("email_nonce", "")), str(nonce)):
            raise SafeError("That email confirmation expired or belongs to another account. Open /email on the intended account.")
        account = rt.current
        await reply(update, context, "Requesting ONE verification email from Telegram for the saved new login email...",
                    show_active=False, wait_notice=False)
        state = await rt.email.send(account.key, nonce)
        context.user_data.update(flow="email_code", email_created=int(time.time()))
        await reply(update, context,
            "Telegram accepted the request.\nNew login email: " + (state["new_pattern"] or "configured (hidden)") +
            "\nEmailed code length reported by Telegram: " + str(state["code_length"] or "unknown") +
            "\n\nEnter ONLY the code emailed for this request (never a Telegram login code). It is deleted from this chat best-effort, "
            "never stored or echoed, and up to 3 attempts are allowed. No automatic resend occurs. /cancel stops input.",
            Markup([[Button("Stop input", callback_data=f"acct:{account.key}:emailcancel")],
                    [Button("Back to Email", callback_data=f"acct:{account.key}:email")]]))
    elif action == "session": await session_command(update, context)
    elif action.startswith("account:"):
        await dashboard_action(update, context, action.split(":", 1)[1])
    elif action.startswith("cancel_yes:"):
        valid = (same_account(context, context.user_data.get("cancel_account", ""))
                 and hmac.compare_digest(action.split(":", 1)[1], context.user_data.get("cancel_nonce", "")))
        context.user_data.pop("cancel_nonce", None)
        if not valid: raise SafeError("That cancellation belongs to another account or has expired. Run /cancel again.")
        await reply(update, context, await rt.engine.cancel())
    elif action.startswith("remove_yes:"):
        key = context.user_data.get("remove_account", "")
        valid = same_account(context, key) and hmac.compare_digest(action.split(":", 1)[1], context.user_data.get("remove_nonce", ""))
        if not valid: raise SafeError("That removal confirmation is expired or belongs to another profile. Use /removeaccount again.")
        clear_draft(context)
        await rt.registry.remove(key)
        await accounts_action(update, context)
    elif action.startswith("sess:"):
        if not same_account(context, context.user_data.get("session_account", "")):
            raise SafeError("This file list expired. Use /session again, or simply send a .session document.")
        choices = context.user_data.get("session_choices", [])
        try:
            index = int(action.split(":", 1)[1])
            if not 0 <= index < len(choices): raise ValueError()
            source = rt.sessions.checked_path(choices[index])
        except (IndexError, ValueError):
            raise SafeError("The file list expired. Use /session again.") from None
        await reply(update, context, "Checking the session format and account...")
        await after_import(update, context, await rt.router.import_file(source))
    elif action in ("upload_warn", "upload_now") or action.startswith("upload_ok:"):
        # Compatibility with old keyboards: no repeated consent round-trip.
        if not rt.store.data["allow_session_upload"]: raise SafeError("Session upload is disabled in local configuration.")
        await reply(update, context, "Send your OWN .session document directly. Its account will be detected and selected automatically.")
    elif action.startswith("begin:"):
        draft = context.user_data.get("draft", {})
        valid = (context.user_data.get("flow") == "confirm" and same_account(context, draft.get("account_key", ""))
                 and int(time.time()) - draft.get("created", 0) <= 600
                 and int(draft.get("account_user_id", 0)) == int(rt.account_store.data["account_user_id"])
                 and hmac.compare_digest(action.split(":", 1)[1], draft.get("nonce", "")))
        if not valid:
            clear_draft(context)
            raise SafeError("That confirmation expired or belongs to another account. Run /resetpassword on the intended profile.")
        encrypted, hint, mode = draft["encrypted"], draft["hint"], draft["mode"]
        rt.registry.assert_unique()
        clear_draft(context)
        await rt.engine.start(encrypted, hint, set_only=(mode == "set"))
        await reply(update, context, rt.engine.summary())
        await rt.flush(context.application)
    else:
        await reply(update, context, "This button is no longer valid. Choose a menu action.")


@durable_handler
async def text_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await allowed(update, context): return
    rt = runtime_of(context)
    step = context.user_data.get("flow")
    log.info("Owner input step: %s", step if step in ("phone", "password", "password_confirm", "hint", "confirm") else "none")
    text = update.effective_message.text or ""
    draft = context.user_data.get("draft", {})
    if step in ("universal_new", "universal_confirm"):
        await erase_input(update)
        if int(time.time()) - int((draft or {}).get("created") or 0) > 600:
            clear_draft(context)
            await reply(update, context, "Input expired. Nothing was saved. Open Universal password again.")
            return
        if step == "universal_new":
            if not acceptable_password(text):
                await reply(update, context, "Use a single-line password of 10-128 characters. Enter it again.")
                return
            draft["encrypted"] = rt.vault.seal(text)
            draft["created"] = int(time.time())
            context.user_data.update(draft=draft, flow="universal_confirm")
            await reply(update, context, "Re-enter the universal password. It will not be echoed or shown again.")
            return
        if not hmac.compare_digest(rt.vault.open(draft["encrypted"]).encode(), text.encode()):
            await reply(update, context, "The entries do not match. Enter the same universal password again, or /cancel.")
            return
        rt.store.update(universal_password=draft["encrypted"])
        clear_draft(context)
        await reply(update, context, "Universal password saved. It is encrypted and will not be shown. Press Reset on an account to use it. Waiting jobs were not changed. No session was logged out.")
        return
    if step in EMAIL_STEPS:
        await erase_input(update)
        if not email_binding(context):
            clear_draft(context)
            await reply(update, context, "Email input expired or the selected account changed. Nothing was sent to Telegram. Open /email on the intended account.")
            return
        if step == "email_new":
            account = rt.current
            state = await rt.email.prepare(account.key, text)
            context.user_data.update(flow="email_confirm", email_nonce=state["nonce"], email_created=int(time.time()))
            await reply(update, context,
                "CONFIRM LOGIN-EMAIL CHANGE FOR THIS ACCOUNT\nCurrent login email: " + (state["before_pattern"] or "configured (hidden)") +
                "\nNew login email: " + state["new_pattern"] +
                "\n\nTelegram will email a verification code to the NEW address. Only the login email changes: the 2FA password, "
                "the 2FA recovery email, saved jobs, protection lock and other accounts stay as they are, and no session is logged out. "
                "Send the code request for this account?",
                Markup([[Button("Send code to the new address", callback_data="emailsend:" + state["nonce"])],
                        [Button("Stop input", callback_data=f"acct:{account.key}:emailcancel")]]))
            return
        if step == "email_confirm":
            await reply(update, context, "Use the button on the confirmation card above to send the code, or /cancel to stop. Nothing was sent.")
            return
        account = rt.current
        state = await rt.email.verify(account.key, context.user_data.get("email_nonce", ""), text)
        clear_draft(context)
        await reply(update, context,
            "LOGIN EMAIL UPDATED\nTelegram confirmed the new login email for this account: " + (state["new_pattern"] or "configured (hidden)") +
            "\n\nYour 2FA password, 2FA recovery email, saved jobs and protection lock were not changed, and no session was logged out. "
            "Sign-in codes for this account now go to the new address.",
            account_keyboard(rt.registry.active_key, account.store.reload()))
        return
    if step in ("phone", "password", "password_confirm", "hint", "confirm"):
        await erase_input(update)
        if not same_account(context, draft.get("account_key", "")) or int(time.time()) - draft.get("created", 0) > 600:
            clear_draft(context)
            await reply(update, context, "Input expired or the selected account changed. No reset was started. Run /resetpassword for the intended account.")
            return
    if step == "phone":
        rt.registry.assert_unique()
        await rt.sessions.verify_phone(text)
        await reply(update, context, "This account's phone and session ID were verified. The BOT OWNER ID was not changed.")
        mode = draft.get("mode", "reset")
        if mode in ("verify", "status", "spamcheck"):
            clear_draft(context)
            if mode == "status": await status_action(update, context)
            elif mode == "spamcheck": await spamcheck_action(update, context)
            else: await reply(update, context, "Verification saved for this profile. No password reset started. Use /resetpassword when you intend to recover it.")
        else:
            await offer_saved_password(update, context, mode)
    elif step == "password":
        if not 10 <= len(text) <= 128 or "\x00" in text or "\n" in text:
            await reply(update, context, "Use a unique single-line password of 10-128 characters. Enter it again.")
            return
        draft["encrypted"] = rt.vault.seal(text)
        context.user_data.update(draft=draft, flow="password_confirm")
        await reply(update, context, "Re-enter this account's NEW password. It will not be echoed and no email is requested.")
    elif step == "password_confirm":
        if not hmac.compare_digest(rt.vault.open(draft["encrypted"]).encode(), text.encode()):
            await reply(update, context, "The entries do not match. Enter the same new password again, or /cancel.")
            return
        draft.update(hint="", nonce=secrets.token_hex(8))
        context.user_data.update(draft=draft, flow="confirm")
        await reply(update, context, password_confirm_text(draft, rt.account_store.reload()), password_confirm_markup(draft))
    elif step == "hint":
        hint = "" if text.strip() == "-" else text.strip()
        if len(hint) > 80 or (hint and rt.vault.open(draft["encrypted"]).casefold() in hint.casefold()):
            await reply(update, context, "Use at most 80 characters without the password, or send -.")
            return
        draft.update(hint=hint, nonce=secrets.token_hex(8))
        context.user_data.update(draft=draft, flow="confirm")
        await reply(update, context, password_confirm_text(draft, rt.account_store.reload()), password_confirm_markup(draft))
    else:
        await reply(update, context, "Use /accounts to choose an account, /addaccount for another of your own accounts, or /resetpassword to start. Never paste session strings, tokens, OTPs, or old passwords.")


@durable_handler
async def document_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await allowed(update, context): return
    rt = runtime_of(context)
    if context.user_data.get("flow") in EMAIL_STEPS:
        await erase_input(update)
        await reply(update, context, "An email step is open for this account. Enter the email or code as text, or /cancel first. No session file was read.")
        return
    if not rt.store.data["allow_session_upload"]:
        await reply(update, context, "Session upload is disabled. Use a local file with /session.")
        return
    doc = update.effective_message.document
    remote = None
    size = getattr(doc, "file_size", None)
    if size is None:
        remote = await doc.get_file()
        size = getattr(remote, "file_size", None)
    if not isinstance(size, int) or not 16 <= size <= MAX_SESSION_BYTES:
        await reply(update, context, "Send a logged-in Telethon/Pyrogram SQLite session file up to 5 MB.", wait_notice=False)
        return
    # Ignore the public filename entirely. Use a private random path and verify
    # the real SQLite database/library/account, never a filename guess.
    incoming = rt.router.incoming / ("incoming_" + secrets.token_hex(12) + ".session")
    await reply(update, context, "Reading session...", show_active=False, wait_notice=False)
    try:
        if remote is None:
            remote = await doc.get_file()
        actual_size = getattr(remote, "file_size", size)
        if actual_size is not None and (not isinstance(actual_size, int) or not 16 <= actual_size <= MAX_SESSION_BYTES):
            raise SafeError("The session file must be between 16 bytes and 5 MB.")
        await asyncio.wait_for(remote.download_to_drive(incoming), timeout=45)
        private_mode(incoming)
        if not 16 <= incoming.stat().st_size <= MAX_SESSION_BYTES:
            raise SafeError("The downloaded session is empty or larger than 5 MB.")
        result = await rt.router.import_file(incoming)
    finally:
        incoming.unlink(missing_ok=True)
        await erase_input(update)
    await after_import(update, context, result)


@durable_handler
async def unknown_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await allowed(update, context): return
    if context.user_data.get("flow") in ("password", "password_confirm", "hint", "universal_new", "universal_confirm", *EMAIL_STEPS):
        await text_input(update, context)  # A password may legitimately start with /.
    else:
        await reply(update, context, "Use /resetpassword or send your own .session document directly.")


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    log.warning("Handler failed (%s); no raw input or exception values logged", type(context.error).__name__)
    if isinstance(update, Update):
        try:
            if await allowed(update, context): await reply(update, context, public_error(context.error))
        except Exception as error:
            log.warning("Error notice could not be delivered (%s)", type(error).__name__)


async def on_startup(app: Application):
    rt = app.bot_data["runtime"]
    if (await app.bot.get_webhook_info()).url:
        raise SafeError("An existing webhook was found. Stop the old deployment and intentionally remove its webhook before polling. No webhook was deleted.")
    await app.bot.set_my_commands([
        BotCommand("resetpassword", "Official recovery for the selected own account"),
        BotCommand("myids", "My phone numbers, IDs, timers and account options"),
        BotCommand("timer", "Current account dashboard and remaining time"),
        BotCommand("alerts", "Code-free Telegram/login alerts: status and ON/OFF"),
        BotCommand("protection", "New-login lock status and per-account ON/OFF"),
        BotCommand("email", "Login-email status and guided change for selected account"),
        BotCommand("lock", "Turn ON selected account new-login lock"),
        BotCommand("unlock", "Turn OFF selected account lock BEFORE your new login"),
        BotCommand("accounts", "Alias for My IDs"),
        BotCommand("addaccount", "Add another account I own"),
        BotCommand("verify", "Verify selected account without a reset"),
        BotCommand("status", "Live status for selected account"),
        BotCommand("check", "Check selected account's saved job"),
        BotCommand("cancel", "Cancel ONLY selected account's job"),
        BotCommand("session", "Selected profile's session setup"),
        BotCommand("spamcheck", "SpamBot reply for selected account"),
        BotCommand("setpassword", "Enable 2FA only when already off"),
        BotCommand("universal", "Save one password used by Reset"),
        BotCommand("removeaccount", "Remove an inactive local profile"),
        BotCommand("help", "Flow, availability and safety"),
    ])
    rt.task = asyncio.create_task(rt.worker(app), name="multi-account-recovery-scheduler")
    rt.security_task = asyncio.create_task(rt.security.worker(app), name="code-free-security-alert-supervisor")
    rt.guard_task = asyncio.create_task(rt.guard.worker(app), name="new-login-protection-supervisor")
    rt.otp_forward_task = asyncio.create_task(rt.otp_forward.worker(app), name="otp-forward-supervisor")
    rt.email_task = asyncio.create_task(rt.email_status_baseline(), name="login-email-status-baseline")
    log.info("Multi-account bot v%s initialized; a due reset is applied on time; this session is kept", VERSION)


async def on_stop(app: Application):
    rt = app.bot_data["runtime"]
    tasks = [task for task in (rt.task, rt.security_task, rt.guard_task, getattr(rt, "otp_forward_task", None),
                               getattr(rt, "email_task", None)) if task]
    for task in tasks:
        task.cancel()
    if tasks:
        await asyncio.gather(*tasks, return_exceptions=True)
    await rt.registry.close()
    log.info("Stopped; separate durable account states remain on disk")


def setup_wizard(store: Store):
    print("PRIVATE TERMINAL SETUP — do not paste secrets into an AI chat.")
    print("owner_id is the BOT CONTROLLER, not the session account. Enter keeps an existing value.")
    token = getpass.getpass("BotFather token (hidden): ").strip()
    api_id = input("Telegram API ID (number): ").strip()
    api_hash = getpass.getpass("Telegram API hash (hidden): ").strip()
    owner_id = input("Bot controller Telegram ID (keep existing with Enter): ").strip()
    changes = {}
    if token: changes["bot_token"] = token
    if api_id:
        if not api_id.isdigit(): raise SafeError("API ID must be a number.")
        changes["api_id"] = int(api_id)
    if api_hash: changes["api_hash"] = api_hash
    if owner_id:
        if not owner_id.isdigit() or not int(owner_id): raise SafeError("Controller ID must be a positive number.")
        if int(store.data["owner_id"] or 0) not in (0, int(owner_id)):
            raise SafeError("The existing fixed controller ID was not replaced. Keep its value; target accounts are managed separately.")
        changes["owner_id"] = int(owner_id)
    store.update(**changes)
    if not int(store.data["owner_id"] or 0):
        raise SafeError("Set the bot controller ID through this private setup. It must not be inferred from a target session.")
    print("Controller setup saved. Run python bot.py, then use /addaccount and /session. No account reset was requested.")


def configure_from_environment(store: Store):
    changes = {}
    for env, key in (("TG_BOT_TOKEN", "bot_token"), ("TG_API_HASH", "api_hash"),
                     ("TG_API_ID", "api_id"), ("TG_OWNER_ID", "owner_id")):
        value = os.environ.get(env)
        if value:
            if key in ("api_id", "owner_id"):
                if not value.isdigit(): raise SafeError(f"{env} must be a number.")
                value = int(value)
            if key == "owner_id" and store.data["owner_id"] not in (0, value):
                raise SafeError("TG_OWNER_ID conflicts with the fixed controller ID; no controller was changed.")
            changes[key] = value
    if changes: store.update(**changes)


def main():
    parser = argparse.ArgumentParser(description="Owner-only multi-account official Telegram recovery helper")
    parser.add_argument("--setup", action="store_true", help="Private terminal configuration / token rotation")
    parser.add_argument("--init-config", action="store_true", help="Create blank configuration if absent")
    parser.add_argument("--check-config", action="store_true", help="Validate controller configuration, no reset")
    parser.add_argument("--run-once", action="store_true", help="Check ALL saved profiles once, for an hourly hosted task")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s UTC %(levelname)s %(name)s: %(message)s")
    logging.Formatter.converter = time.gmtime
    for name in ("httpx", "httpcore", "telegram", "telethon", "pyrogram"):
        logging.getLogger(name).setLevel(logging.WARNING)
    try:
        store = Store(ROOT)
        configure_from_environment(store)
        if args.init_config:
            print("Private blank configuration created; existing values preserved.")
            return
        with ProcessLock(ROOT / "bot.lock"):
            if args.setup:
                setup_wizard(store)
                return
            data = store.data
            if not re.fullmatch(r"\d+:[A-Za-z0-9_-]{25,}", str(data["bot_token"])):
                raise SafeError("A valid bot token is required. Run python bot.py --setup privately.")
            if not int(data["api_id"] or 0) or not re.fullmatch(r"[a-fA-F0-9]{32}", str(data["api_hash"])):
                raise SafeError("Valid API ID/hash are required. Run --setup privately.")
            if not int(data["owner_id"] or 0):
                raise SafeError("Set the fixed BOT CONTROLLER ID with --setup. It is independent of target-session IDs.")
            if args.check_config:
                print("Controller configuration structure valid. Account IDs are independent. No reset or password change was made.")
                print("Saved profile count:", len(store.data.get("profiles", [])))
                return
            rt = Runtime(store)
            if args.run_once:
                async def scheduled_once():
                    try:
                        await rt.registry.tick_all()
                        await rt.security.poll_all()
                        await rt.guard.poll_all()
                        await rt.otp_forward.poll_all()
                        if (rt.registry.has_notices() or rt.security.has_pending() or rt.guard.has_pending()
                                or rt.otp_forward.has_pending()):
                            from types import SimpleNamespace
                            from telegram import Bot
                            async with Bot(store.data["bot_token"]) as bot:
                                app = SimpleNamespace(bot=bot)
                                await rt.flush(app)
                                await rt.security.flush_all(app)
                                await rt.guard.flush_all(app)
                                await rt.otp_forward.flush_all(app)
                    finally:
                        await rt.registry.close()
                asyncio.run(scheduled_once())
                print("Scheduled check complete for all profiles. Idle profiles do not start resets.")
                return
            async def detect_library():
                try:
                    if rt.account_store.data["session_name"] or len(rt.sessions.candidates()) == 1:
                        await rt.sessions.ensure()
                        rt.registry.assert_unique()
                except Exception as error:
                    log.warning("Selected-profile startup check: %s", public_error(error))
                finally:
                    await rt.registry.close()
            asyncio.run(detect_library())
            asyncio.set_event_loop(asyncio.new_event_loop())
            app = (Application.builder().token(store.data["bot_token"]).concurrent_updates(False)
                   .connect_timeout(20).read_timeout(30).write_timeout(30)
                   .get_updates_connect_timeout(20).get_updates_read_timeout(40)
                   .post_init(on_startup).post_stop(on_stop).build())
            app.bot_data["runtime"] = rt
            for command, handler in (
                ("start", start_command), (["resetpassword", "reset", "reset_start"], reset_command),
                (["myids", "accounts"], accounts_command), ("timer", timer_command), ("alerts", alerts_command),
                ("protection", protection_command), ("lock", lock_command), ("unlock", unlock_command),
                ("email", email_command),
                ("addaccount", addaccount_command), ("verify", verify_command),
                ("removeaccount", removeaccount_command), ("setpassword", setpassword_command),
                ("universal", universal_command),
                ("status", status_command), ("check", check_command), ("cancel", cancel_command),
                ("help", help_command), ("session", session_command), ("spamcheck", spamcheck_command),
            ):
                app.add_handler(CommandHandler(command, handler))
            app.add_handler(CallbackQueryHandler(callback))
            app.add_handler(MessageHandler(filters.Document.ALL, document_input))
            app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_input))
            app.add_handler(MessageHandler(filters.COMMAND, unknown_command))
            app.add_error_handler(error_handler)
            app.run_polling(drop_pending_updates=False, allowed_updates=["message", "callback_query"], bootstrap_retries=3)
    except KeyboardInterrupt:
        print("Stopped. All saved profile states remain on disk.")
    except Exception as error:
        if args.run_once and isinstance(error, SafeError) and str(error).startswith("Another copy is already running"):
            print("The running owner-only bot already owns scheduled checks. No second process was started.")
            return
        print("STARTUP ERROR:", public_error(error))
        print("Error class:", type(error).__name__)
        raise SystemExit(1) from None


if __name__ == "__main__":
    main()
