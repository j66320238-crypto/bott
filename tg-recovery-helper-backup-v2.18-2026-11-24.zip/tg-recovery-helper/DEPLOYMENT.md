# Alwaysdata v2.8 operation

## Upgrading to v2.8 safely

v2.8 does not replace sessions, keys, or saved recovery jobs. A live session phone is accepted as verification, so the owner no longer retypes the number after upload. `/universal` stores one encrypted password used by later Reset and Enable 2FA clicks. Jobs already waiting keep the password they already saved.

When Telegram confirms the new 2FA password, the owner message is pinned and includes the account phone and Telegram ID, never the password. Lock ON still terminates new logins only. The session running this bot is never a termination target. A session younger than 24 hours cannot terminate other logins until Telegram allows it; that delay does not log the current session out.

Replace source/docs/tests only. Do not copy a blank `config.json` or a new `.secret.key`. Deployment does not start a reset, send an email, or apply a password.


Project directory:

```text
/home/tgidsellerindian/tg-recovery-helper
```


## Upgrading to v2.7 safely

v2.7 does not add config keys. Password setup no longer asks for a hint or a recovery email. The saved password is applied immediately when 2FA is already OFF. If 2FA is ON, Telegram's official timer is unchanged; when that timer ends, the saved password is applied with the email flag omitted. A pending unconfirmed recovery-email code is cancelled once and the password-only update is retried. Success is reported only after `account.getPassword` shows 2FA ON.

Replace source/docs/tests only. Do not copy a blank `config.json` or a new `.secret.key`. Deployment does not start a reset, send an email, or apply a password by itself.

## Upgrading to v2.6 safely

v2.6 adds login-email status and a guided LOGIN-email change. It adds two files (`login_email.py`, `tests/test_login_email.py`) and two default keys per profile (`email_info`, `login_email_change`).

1. Copy a private backup of the project directory first — including `config.json`, `.secret.key`, `accounts/` and the private sessions.
2. Replace only source/docs/tests; **never copy a blank `config.json` or a new key over the live ones.**
3. `.venv/bin/python -m unittest discover -s tests` must pass before restarting.
4. `.venv/bin/python manage.py restart`, then `.venv/bin/python manage.py status` and `logs`.
5. Existing profiles gain the two new keys with empty defaults on first read; recovery state, saved deadlines, sessions, protection locks and alert switches are untouched.

The login-email feature performs a read-only `account.getPassword` on refresh/startup, plus `sendVerifyEmailCode`/`verifyEmail` **only** after you explicitly confirm. Deployment itself sends no email request, no code and no login.

## Why the earlier prompt stopped replying

The temporary SSH runner reported `Connection reset by peer`, its remote process exited, and the bot lock was no longer held. The account was still verified and idle; no pending reset password had been saved. The input conversation existed only in memory in that earlier version.

v2.1 separates bot lifetime from the SSH connection and saves the conversation step. It also accepts direct owner session documents, detects their account/library and routes them without repeated Accept buttons.

## Start independently of SSH

```sh
cd /home/tgidsellerindian/tg-recovery-helper
.venv/bin/python manage.py start
```

The launcher uses disconnected stdin, a new process session, closed inherited SSH descriptors and a private `bot.log`. Closing the SSH client does not send the bot a terminal hangup.

Check/operate:

```sh
.venv/bin/python manage.py status
.venv/bin/python manage.py logs
.venv/bin/python manage.py stop
.venv/bin/python manage.py restart
```

PID/cwd/command verification prevents stopping an unrelated process. The application lock prevents a second local poller.

**This is a manual launcher, not an uptime supervisor.** Host reboot, resource limits, session revocation or network failure can still stop/delay work. It does not bypass the hosting plan's process policies. Use the official service or scheduled-task options for unattended work.

## Option A — managed bot service

Alwaysdata documents managed foreground services in **Advanced > Services**, available on paid plans. [Service documentation](https://help.alwaysdata.com/en/docs/web-hosting/services/)

- Working directory: `/home/tgidsellerindian/tg-recovery-helper`
- Command: `sh /home/tgidsellerindian/tg-recovery-helper/run.sh`
- Public HTTP port: none

Use foreground `run.sh` for the host supervisor, **not `manage.py start`**. Stop the manually detached copy before enabling the managed service. Do not poll the same token on two hosts.

## Option B — hourly saved-job fallback

In **Advanced > Scheduled tasks**, create an enabled command task every hour:

```sh
/home/tgidsellerindian/tg-recovery-helper/.venv/bin/python /home/tgidsellerindian/tg-recovery-helper/bot.py --run-once
```

The platform recommends dashboard-managed scheduled tasks. [1](https://help.alwaysdata.com/en/docs/web-hosting/tasks/)

This checks all previously confirmed jobs, performs one code-free service-chat check and one enabled protection/login check per valid profile, sends queued owner notices/category-only alerts when possible, then exits. Its first successful service-chat check establishes a baseline without replaying old messages. An hourly task cannot provide 30-second monitoring. It does not start resets for idle profiles or poll the chat UI. It yields if the normal bot holds the local lock. It only works after you actually enable the dashboard task.

No hosting service/task/account-wide cron/firewall rule is configured by this SSH code installation.

## New-login protection — operational safety

- Use **Protection lock** / `/protection` for all account statuses and per-ID ON/OFF buttons. `/unlock` and `/lock` apply to the selected account.
- Default ON for saved/new valid own accounts. OFF survives restart. The lock remains ON beyond seven days until manually disabled.
- First enable/re-enable trusts currently active authorizations. The current authorization and this trusted baseline are never auto-revoked. Review pre-existing devices manually in Telegram.
- Turn OFF before your own new login. Re-enable after signing in to trust sessions active then. If the controller chat is inaccessible, private console `.venv/bin/python manage.py emergency-unlock` safely stops the verified local bot, switches all locks OFF and restarts only if it was running. This is an authorized-console escape, not a Telegram command. OFF persists immediately; an in-progress request may still finish.
- Only a new, freshly revalidated, non-current, non-trusted authorization created after arming can reach the single-hash reset RPC. There is no logout-all call or arbitrary hash input.
- Healthy online checks are about every 30 seconds. The guard cannot prevent initial access, act offline, override Telegram restrictions, detect every short-lived session or reliably distinguish a copy using an existing authentication key.
- Telegram acknowledgment plus absence is required for a confirmed-termination notice. Timeout/False/errors are not success. Rate limits/session-age restrictions delay enforcement and produce a controlled owner attention notice when delivery works.
- `/alerts` also controls login notices, but switching notifications OFF does NOT disable revocation. Use the lock switch to allow a new device.
- Every profile has isolated baseline/seen/candidate state, control generation and category-only outbox; no IP, device name, message body, code or login link is stored/relayed by this feature. Keep the opaque authorization IDs/config private.
- The password-recovery engine, pending ciphertext and exact server deadlines are separate and unchanged. An hourly `--run-once` fallback cannot provide continuous/30-second protection.

## Code-free security alerts

- **Security alerts** / `/alerts` shows the master switch, account-specific status and Last check; all and individual ON/OFF controls need no code edits.
- Saved profiles and future valid imports default ON, subject to the master switch. Disabling all also pauses newly added profiles until enabled again.
- Only official Telegram service user `777000` is read. OTP-type/generic arrival category, account and IST time are sent only to the configured controller; actual codes, message bodies, links and media are excluded from storage/logs/notifications.
- Independent per-account workers check about every 30 seconds while the normal bot is online. The recovery scheduler remains hourly. Network/rate-limit delays and per-account locks may extend the check interval.
- First successful enable/re-enable skips existing history. Normal restarts retain cursors and catch up later arrivals if still retained on Telegram. OFF discards pending alerts; ON starts a fresh baseline.
- Reading history does not mark it read, request a code, send a user-session message, change a phone or modify reset state.
- Delivery is durable and normally deduplicated, not mathematically exactly-once: a crash after a successful send but before saving its acknowledgment can duplicate a category-only alert.
- A failed/revoked session is isolated and retried, with a controlled attention notice where delivery works. An unreadable monitor state needs private backup repair; it does not replace or reset the separate recovery job.

## My IDs and downtime

- Use **My IDs** or `/myids` (`/accounts` alias) for saved phone numbers, target IDs, job states and remaining times.
- Tap an account for its own dashboard/options. `/timer` opens the selected profile directly.
- **Refresh timer** recalculates a snapshot from the current clock and saved absolute deadline. It does not contact Telegram or initiate/reset/cancel a job. Refresh edits the screen in place when possible.
- **Live status** contacts the selected session for Telegram password/reset status. **Check saved job** runs the saved state machine only when its server/rate-limit dates permit it.
- Display deadlines are labeled IST and UTC. An eligibility cooldown is not shown as an already-started seven-day reset.
- Offline time counts. A bot that resumes a day later subtracts that elapsed day; it never adds a fresh seven days just because it restarted. If a deadline passed while no worker was running, action waits for startup/the next enabled scheduled check.
- A server cancellation or different official deadline takes precedence when reconciled. The local display cannot override Telegram.
- Viewing a different profile does not cancel/restart another account's confirmed waiting job.

## Owner flow

1. Send your own logged-in Telethon/Pyrogram SQLite session file directly. Filename/extension do not matter; the maximum is 5 MB.
2. The bot detects and adds/selects the account, then shows a short card. No Accept, phone or password prompt is required just to add it.
3. Repeat for other own accounts, or open **My IDs** (`/myids`) to browse numbers, timers and options.
4. Choose **Reset password** only when you want recovery. A new/changed phone is verified then; password confirmation/hint and final account-specific authorization follow.
5. An explicit `/resetpassword` that is waiting for a session can continue after a matching upload within ten minutes. Another profile, an expired/legacy intent or an already-waiting job does not auto-continue.

**Add my account** no longer creates a blank profile before a valid import. Actual database content is validated: a renamed file is fine, but a real archive, StringSession or logged-out/corrupt session is not accepted as a working SQLite session.

Re-uploading an account with an active reset selects it without replacing the active session, timer or pending password. Each reset still needs its own final confirmation; importing a file does not reset anything.

## Rotate the shared token privately

Stop the bot and temporarily disable scheduled tasks, then:

```sh
cd /home/tgidsellerindian/tg-recovery-helper
.venv/bin/python bot.py --setup
```

Use official @BotFather `/revoke`; enter replacement only in the hidden terminal prompt. Keep the controller ID unchanged. Restart the bot/task afterward. Do not paste replacement secrets into AI chats.

## Checks and private backups

```sh
.venv/bin/python -m unittest discover -s tests -v
```

The upgrade takes a private code/config/key/profile-state backup under `.backups/`. Session contents are not printed or copied to the assistant workspace. Existing profiles, verification, jobs and encryption key are preserved. No real password reset is sent during installation/testing.

The source ZIP excludes actual configuration, profiles, sessions, keys, logs and backups. Keep configured backups private.
