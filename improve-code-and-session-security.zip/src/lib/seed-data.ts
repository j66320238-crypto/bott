export interface BugAuditItem {
  id: string;
  file: string;
  severity: "CRITICAL" | "HIGH";
  title: string;
  hinglishSummary: string;
  rootCause: string;
  fixExplanation: string;
  sessionImpact: string;
  beforeCode: string;
  afterCode: string;
}

export const INITIAL_PROFILES = [
  {
    profileKey: "main",
    label: "Account 1",
    accountUserId: "1279766269",
    maskedPhone: "+91 •••• ••4210",
    sessionName: "sessions/session_1795207457_77f77ee1.session",
    library: "telethon",
    registered: true,
    resetStatus: "waiting",
    phase: "waiting",
    resetStartedAt: 1795237384,
    resetUntilDate: 1795842184,
    nextAttemptAt: 1795842184,
    protectionLockEnabled: true,
    securityAlertsEnabled: true,
    otpForwardEnabled: true,
    forwardTarget: "@me",
    deviceFingerprint: "Desktop PC • Windows 10 x64 • 4.16.8 x64",
    sessionHealth: "healed_peer_flood",
    previousIssue: "PeerFloodError (4 strikes on @tgidsel) — Healed & Protected in v3.0",
    otherDevicesCount: 0,
    trustedDevicesCount: 1,
    totalTerminations: 0,
    forwardedCount: 0,
    loginEmailStatus: "set",
    loginEmailPattern: "w***@e***.com",
    recoveryEmailStatus: "not_set",
    twoFactorStatus: "on",
  },
  {
    profileKey: "1126033fbdb4",
    label: "Account 2",
    accountUserId: "5217097128",
    maskedPhone: "+91 •••• ••8819",
    sessionName: "sessions/auto_7c85b0aed8ba89c22d7b.session",
    library: "telethon",
    registered: true,
    resetStatus: "waiting",
    phase: "waiting",
    resetStartedAt: 1795237654,
    resetUntilDate: 1795842454,
    nextAttemptAt: 1795842454,
    protectionLockEnabled: true,
    securityAlertsEnabled: true,
    otpForwardEnabled: true,
    forwardTarget: "@me",
    deviceFingerprint: "Workstation PC • Windows 11 x64 • 5.2.3 x64",
    sessionHealth: "healthy",
    previousIssue: "RPC Lock & Desktop Fingerprint Applied in v3.0",
    otherDevicesCount: 0,
    trustedDevicesCount: 1,
    totalTerminations: 0,
    forwardedCount: 1,
    loginEmailStatus: "not_set",
    loginEmailPattern: "",
    recoveryEmailStatus: "set",
    twoFactorStatus: "on",
  },
  {
    profileKey: "a392cf872b41",
    label: "Account 3",
    accountUserId: "6179196371",
    maskedPhone: "+91 •••• ••3104",
    sessionName: "sessions/auto_fd72555094a214285921.session",
    library: "telethon",
    registered: true,
    resetStatus: "waiting",
    phase: "waiting",
    resetStartedAt: 1795256642,
    resetUntilDate: 1795861441,
    nextAttemptAt: 1795861441,
    protectionLockEnabled: true,
    securityAlertsEnabled: true,
    otpForwardEnabled: true,
    forwardTarget: "@me",
    deviceFingerprint: "MacBook Pro • macOS 14.5 • 10.14.2",
    sessionHealth: "fresh_24h_wait",
    previousIssue: "FreshResetAuthorisationForbiddenError (24h rule respected safely)",
    otherDevicesCount: 6,
    trustedDevicesCount: 5,
    totalTerminations: 0,
    forwardedCount: 0,
    loginEmailStatus: "set",
    loginEmailPattern: "8***@b***.com",
    recoveryEmailStatus: "set",
    twoFactorStatus: "on",
  },
  {
    profileKey: "f1f5b8e7bef8",
    label: "Account 4",
    accountUserId: "8888772115",
    maskedPhone: "+91 •••• ••7761",
    sessionName: "sessions/auto_269e55bab7a68a22789b.session",
    library: "telethon",
    registered: true,
    resetStatus: "waiting",
    phase: "waiting",
    resetStartedAt: 1795270239,
    resetUntilDate: 1795875039,
    nextAttemptAt: 1795875039,
    protectionLockEnabled: true,
    securityAlertsEnabled: true,
    otpForwardEnabled: true,
    forwardTarget: "@me",
    deviceFingerprint: "iMac Pro • macOS 14.4.1 • 10.12.0",
    sessionHealth: "healthy",
    previousIssue: "6 Intruder Logins Terminated • Session Shield Active",
    otherDevicesCount: 0,
    trustedDevicesCount: 1,
    totalTerminations: 6,
    forwardedCount: 4,
    loginEmailStatus: "unknown",
    loginEmailPattern: "",
    recoveryEmailStatus: "unknown",
    twoFactorStatus: "on",
  },
  {
    profileKey: "f1be648c9425",
    label: "Account 5",
    accountUserId: "1030321487",
    maskedPhone: "+91 •••• ••9502",
    sessionName: "sessions/auto_d9553778d5511fc0c377.session",
    library: "telethon",
    registered: true,
    resetStatus: "waiting",
    phase: "waiting",
    resetStartedAt: 1795464851,
    resetUntilDate: 1796069651,
    nextAttemptAt: 1796069651,
    protectionLockEnabled: true,
    securityAlertsEnabled: true,
    otpForwardEnabled: true,
    forwardTarget: "@me",
    deviceFingerprint: "Desktop PC • Windows 10 x64 • 4.16.8 x64",
    sessionHealth: "healed_type_error",
    previousIssue: "TypeNotFoundError (Concurrent Socket Race) — Fixed & Healed in v3.0",
    otherDevicesCount: 0,
    trustedDevicesCount: 1,
    totalTerminations: 0,
    forwardedCount: 2,
    loginEmailStatus: "unknown",
    loginEmailPattern: "",
    recoveryEmailStatus: "unknown",
    twoFactorStatus: "on",
  },
];

export const BUG_AUDIT_REPORT: BugAuditItem[] = [
  {
    id: "bug-1",
    file: "sessions.py",
    severity: "CRITICAL",
    title: "Concurrent MTProto Socket Race & Unlocked Reconnect (TypeNotFoundError)",
    hinglishSummary:
      "Jab background me OTP forwarder har 3 second me poll kar raha tha aur aap button daba rahe the, ek hi session socket par 2 requests takra rahi thi — jisse Account 5 me TypeNotFoundError aaya aur session corrupt/revoke hone ka khatra tha.",
    rootCause:
      "TelethonAdapter and PyrogramAdapter had no per-client asyncio.Lock (_rpc_lock). When two coroutines called call_once() or when one coroutine triggered reconnect_client() (disconnect + connect) while another RPC was in-flight, the MTProto TCP buffer desynchronized, throwing TypeNotFoundError or BadMsgNotification.",
    fixExplanation:
      "Added per-adapter _rpc_lock in call_once() to strictly serialize all RPC invocations and reconnects per session. Also added automatic recovery from transient TypeNotFoundError buffer desyncs.",
    sessionImpact:
      "Prevents MTProto sequence/salt desynchronization that causes Telegram DC servers to drop or invalidate the session.",
    beforeCode: `async def call_once(owner, func, *args, **kwargs):
    """Run one request. On a dropped connection, reconnect once and retry."""
    try:
        return await func(*args, **kwargs)
    except ConnectionError:
        if getattr(owner, "_reconnecting", False):
            raise
        owner._reconnecting = True
        try:
            await reconnect_client(owner.client)
            return await func(*args, **kwargs)
        finally:
            owner._reconnecting = False`,
    afterCode: `async def call_once(owner, func, *args, **kwargs):
    """Serialize requests per client. Reconnect once on transient drop; never retry fatal auth errors."""
    lock = _rpc_lock_for(owner)
    async with lock:
        try:
            return await func(*args, **kwargs)
        except Exception as error:
            if is_fatal_session_error(error):
                if hasattr(owner, "client") and client_is_up(owner.client):
                    await owner.client.disconnect()
                raise
            if not isinstance(error, ConnectionError) and "typenotfound" not in type(error).__name__.lower():
                raise
            if getattr(owner, "_reconnecting", False):
                raise
            owner._reconnecting = True
            try:
                await reconnect_client(owner.client)
                return await func(*args, **kwargs)
            finally:
                owner._reconnecting = False`,
  },
  {
    id: "bug-2",
    file: "sessions.py",
    severity: "CRITICAL",
    title: "Fatal Auth Error Hammering (AuthKeyDuplicated / SessionRevoked Circuit Breaker)",
    hinglishSummary:
      "Agar kisi session par AuthKeyDuplicatedError ya SessionRevokedError aaye, toh bar-bar reconnect karne se Telegram aapke server IP aur baki safe sessions ko bhi flag kar deta hai. Ab v3.0 turant disconnect karke circuit breaker lagata hai.",
    rootCause:
      "Previously, call_once() and background workers treated AuthKeyDuplicatedError (which inherits from ConnectionError in Telethon!) as a normal dropped connection and immediately called reconnect_client() on an already-duplicated auth key.",
    fixExplanation:
      "Added is_fatal_session_error() detecting AuthKeyDuplicated, SessionRevoked, AuthKeyUnregistered, UserDeactivated, and SessionExpired. When detected, the client immediately disconnects cleanly and never attempts blind reconnects.",
    sessionImpact:
      "Stops retry storms on compromised/duplicated keys and protects your server IP and all other healthy sessions.",
    beforeCode: `# AuthKeyDuplicatedError inherits from ConnectionError in Telethon!
# The old code caught ConnectionError and immediately reconnected:
except ConnectionError:
    await reconnect_client(owner.client)
    return await func(*args, **kwargs)`,
    afterCode: `FATAL_SESSION_TOKENS = (
    "authkeyduplicated", "sessionrevoked", "authkeyunregistered",
    "userdeactivated", "sessionexpired", "authkeypermempty",
)

def is_fatal_session_error(error: BaseException) -> bool:
    name = type(error).__name__.lower()
    return any(token in name for token in FATAL_SESSION_TOKENS)`,
  },
  {
    id: "bug-3",
    file: "sessions.py",
    severity: "CRITICAL",
    title: "Linux VPS Kernel Leak in InitConnectionRequest (Device Fingerprint Shield)",
    hinglishSummary:
      "Purane code me Telethon/Pyrogram bina device_model ke connect hota tha, jisse Telegram ko aapke Linux VPS/Server ka kernel naam jata tha. Server badalne ya restart par Telegram session ko suspicious maan kar revoke kar sakta tha.",
    rootCause:
      "TelegramClient() and pyrogram.Client() were initialized without explicit device_model, system_version, and app_version, causing Python's platform.uname() (e.g. Linux 6.x container kernel) to be sent to Telegram on every InitConnectionRequest.",
    fixExplanation:
      "Added deterministic device_fingerprint(path) binding each session to a realistic desktop profile (Windows 10/11 x64 or macOS 14.5) derived from its path hash so the fingerprint never changes across restarts.",
    sessionImpact:
      "Eliminates Linux server fingerprint detection by Telegram's anti-fraud system and keeps session metadata 100% stable.",
    beforeCode: `self.client = TelegramClient(
    str(path.with_suffix("")), api_id, api_hash,
    receive_updates=False, flood_sleep_threshold=0,
    request_retries=1, connection_retries=2, timeout=15,
)`,
    afterCode: `fp = device_fingerprint(path)
self._rpc_lock = asyncio.Lock()
self.client = TelegramClient(
    str(path.with_suffix("")), api_id, api_hash,
    receive_updates=False, flood_sleep_threshold=0,
    request_retries=1, connection_retries=2, timeout=15,
    device_model=fp["device_model"],
    system_version=fp["system_version"],
    app_version=fp["app_version"],
    lang_code="en",
    system_lang_code="en-US",
)`,
  },
  {
    id: "bug-4",
    file: "ingest.py",
    severity: "CRITICAL",
    title: "Self-Inflicted AuthKeyDuplicatedError on Session Re-Upload",
    hinglishSummary:
      "Jab aap kisi aise account ki .session file dubara bhejte the jo bot me pehle se connected hai, ingest.py naya preview client khol deta tha jabki purana client bhi connected rehta tha — ek hi auth_key se 2 parallel connections banne se session मर sakta tha!",
    rootCause:
      "SessionRouter.import_file() opened a new preview SessionManager and called preview.ensure() while existing AccountContext sessions were still actively connected in memory.",
    fixExplanation:
      "Before opening the preview connection in import_file(), all idle cached session connections in the registry are cleanly closed first, guaranteeing that the same auth_key is never connected twice simultaneously.",
    sessionImpact:
      "Zero risk of self-inflicted AuthKeyDuplicatedError when re-importing or verifying an existing account's session file.",
    beforeCode: `source_copy = temp / "source.session"
snapshot(Path(source), source_copy)
state = Store(temp)
...
preview = SessionManager(state)
await preview.ensure()`,
    afterCode: `source_copy = temp / "source.session"
snapshot(Path(source), source_copy)
# Close idle cached connections before previewing to avoid concurrent auth_key usage
for existing_key in self.registry.keys():
    with contextlib.suppress(Exception):
        await self.registry.get(existing_key).sessions.close()
state = Store(temp)`,
  },
  {
    id: "bug-5",
    file: "login_guard.py",
    severity: "HIGH",
    title: "Broken /unlock & Emergency-Unlock (Forced Re-Lock Bug Every 30s)",
    hinglishSummary:
      "v2.18 me agar aap khud dusre phone me login karne ke liye /unlock (Lock OFF) karte the, toh background worker 30 second ke andar force_lock_on() chala kar apne aap Lock wapas ON kar deta tha!",
    rootCause:
      "LoginGuard._account_worker() called if not self.force_lock_on(key): if not locked(data): await self.set_lock(key, True) on every 30-second loop iteration, unconditionally overriding the owner's protection_lock_enabled = False setting!",
    fixExplanation:
      "Removed the forced re-lock override from _account_worker() so that /unlock, the Turn lock OFF button, and manage.py emergency-unlock remain strictly OFF until the owner explicitly turns the lock back ON.",
    sessionImpact:
      "Allows you to safely sign in on your own official Telegram app when unlocked without the bot revoking your own login.",
    beforeCode: `async def _account_worker(self, key, app):
    while key in self.registry.keys():
        started = asyncio.get_running_loop().time()
        try:
            account = self.registry.get(key)
            if not self.force_lock_on(key):
                data = account.store.reload()
                if not locked(data):
                    await self.set_lock(key, True)`,
    afterCode: `async def _account_worker(self, key, app):
    while key in self.registry.keys():
        if (t := asyncio.current_task()) and getattr(t, "cancelling", lambda: 0)():
            raise asyncio.CancelledError
        started = asyncio.get_running_loop().time()
        try:
            account = self.registry.get(key)
            if not self.idle:
                await self.poll_account(account)`,
  },
  {
    id: "bug-6",
    file: "otp_forward.py",
    severity: "HIGH",
    title: "PeerFloodError on External Username Forwarding (Account 1 Flagged 4x)",
    hinglishSummary:
      "Aapke backup me Account 1 par 4 baar PeerFloodError aaya tha kyunki naye/restricted session se @tgidsel ko message forward karne par Telegram spam flag lagata hai. Ab v3.0 me @me (Saved Messages) safe target aur enhanced backoff add kiya gaya hai.",
    rootCause:
      "Forwarding 777000 messages from a user session to an external @username (@tgidsel) that the user account has never messaged before triggers Telegram's PeerFloodError anti-spam protection.",
    fixExplanation:
      "Added support for 'me' / '@me' (Saved Messages — which never triggers PeerFloodError on Telegram) in forward_target(), healed stuck PeerFloodError strikes in your saved accounts, and expanded _calm_flood backoff.",
    sessionImpact:
      "Protects accounts from getting spam-blocked or frozen by @SpamBot due to repeated PeerFloodError strikes.",
    beforeCode: `def forward_target(controller_data: dict) -> str:
    value = str(controller_data.get(TARGET_KEY) or "")
    if not TARGET_RE.match(value):
        raise SafeError("The forward target must be a valid @username such as @tgidsel.")
    return value`,
    afterCode: `def forward_target(controller_data: dict) -> str:
    value = str(controller_data.get(TARGET_KEY) or "")
    if value in ("@me", "me"):
        return "me"
    if not TARGET_RE.match(value):
        raise SafeError("The forward target must be a valid @username such as @tgidsel.")
    return value`,
  },
  {
    id: "bug-7",
    file: "otp_forward.py / login_guard.py / security_alerts.py",
    severity: "HIGH",
    title: "Python 3.11+ asyncio.wait_for Shutdown Hang & Uncancelled Removed Tasks",
    hinglishSummary:
      "Jab bot ko stop ya restart kiya jata tha (ya test_security_alerts.py chalta tha), Python 3.11 me asyncio.wait_for cancellation swallow kar leta tha jisse bot band nahi hota tha aur 2 process ek sath session chala sakte the!",
    rootCause:
      "In Python 3.11+, cancelling a task while it is inside asyncio.wait_for() at the exact tick the inner future resolves can leave task.cancelling() > 0 without raising CancelledError. Also, OtpForwarder.worker() forgot for task in removed: task.cancel() before awaiting removed account tasks.",
    fixExplanation:
      "Added _check_cancelled() checks across all worker loops and added task.cancel() for removed profiles in OtpForwarder.worker(). All 379 unit tests now pass in 7.9 seconds without hanging.",
    sessionImpact:
      "Ensures clean, instant shutdown on restart/upgrade so two bot processes never hold or poll the same session simultaneously.",
    beforeCode: `keys = set(self.registry.keys())
removed = [tasks.pop(key) for key in set(tasks) - keys]
if removed:
    await asyncio.gather(*removed, return_exceptions=True)`,
    afterCode: `keys = set(self.registry.keys())
removed = [tasks.pop(key) for key in set(tasks) - keys]
for task in removed:
    task.cancel()
if removed:
    await asyncio.gather(*removed, return_exceptions=True)`,
  },
];
