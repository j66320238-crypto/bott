"""Local SQLite session detection and small, equivalent library adapters.

No interactive login, OTP request, logout, account deletion, or arbitrary bot
messaging is implemented. Bot-controller ID and session-account ID are separate.
Each registered account profile is pinned to its own verified session ID.
"""
from __future__ import annotations

import asyncio
import hashlib
import logging
import os
import re
import sqlite3
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote

from storage import SafeError, Store, private_mode
from security_alerts import SERVICE_USER_ID, ServiceEvent, classify_service_text
from login_guard import LoginSession, hash_key
from login_email import LoginEmailCode, LoginEmailReceipt

log = logging.getLogger(__name__)
MAX_SESSION_BYTES = 5 * 1024 * 1024


def client_is_up(client) -> bool:
    try:
        flag = client.is_connected
        if callable(flag):
            flag = flag()
        return bool(flag)
    except Exception:
        return False


async def reconnect_client(client):
    """Reconnect the same client. This is not a logout."""
    try:
        if client_is_up(client):
            await client.disconnect()
    except Exception:
        pass
    await client.connect()


FATAL_SESSION_TOKENS = (
    "authkeyduplicated", "sessionrevoked", "authkeyunregistered",
    "userdeactivated", "sessionexpired", "authkeypermempty",
)


def is_fatal_session_error(error: BaseException) -> bool:
    name = type(error).__name__.lower()
    return any(token in name for token in FATAL_SESSION_TOKENS)


DESKTOP_PROFILES = (
    {"device_model": "Desktop PC", "system_version": "Windows 10 x64", "app_version": "4.16.8 x64"},
    {"device_model": "Workstation PC", "system_version": "Windows 11 x64", "app_version": "5.2.3 x64"},
    {"device_model": "MacBook Pro", "system_version": "macOS 14.5", "app_version": "10.14.2"},
    {"device_model": "iMac Pro", "system_version": "macOS 14.4.1", "app_version": "10.12.0"},
)


def device_fingerprint(path: Path) -> dict[str, str]:
    """Deterministic desktop fingerprint per session path; hides Linux VPS kernel."""
    digest = hashlib.sha256(str(path).encode("utf-8")).digest()
    profile = DESKTOP_PROFILES[digest[0] % len(DESKTOP_PROFILES)]
    return dict(profile)


def _rpc_lock_for(owner) -> asyncio.Lock:
    lock = getattr(owner, "_rpc_lock", None)
    if lock is None:
        lock = asyncio.Lock()
        setattr(owner, "_rpc_lock", lock)
    return lock


async def call_once(owner, func, *args, **kwargs):
    """Serialize requests per client. Reconnect once on transient drop; never retry fatal auth errors."""
    lock = _rpc_lock_for(owner)
    async with lock:
        try:
            return await func(*args, **kwargs)
        except Exception as error:
            if is_fatal_session_error(error):
                try:
                    if hasattr(owner, "client") and client_is_up(owner.client):
                        await owner.client.disconnect()
                except Exception:
                    pass
                raise
            if not isinstance(error, ConnectionError) and "typenotfound" not in type(error).__name__.lower():
                raise
            if getattr(owner, "_reconnecting", False):
                raise
            owner._reconnecting = True
            try:
                await reconnect_client(owner.client)
                return await func(*args, **kwargs)
            finally:
                owner._reconnecting = False


@dataclass
class PasswordInfo:
    has_password: bool
    has_recovery: bool = False
    hint: str = ""
    pending_reset_date: int = 0
    login_email_pattern: str = ""
    login_email_supported: bool = False
    recovery_email_unconfirmed: bool = False


@dataclass
class ResetResult:
    kind: str  # ok | wait | cooldown
    date: int = 0


@dataclass(frozen=True)
class DeviceLabel:
    """Owner display only. Never a termination identifier and never stored."""
    app: str
    device: str
    country: str
    created_at: int
    active_at: int
    current: bool = False


def public_device_text(value, limit=42) -> str:
    text = " ".join(str(value or "").split())
    text = re.sub(r"https?://\S+", "", text, flags=re.I)
    text = re.sub(r"\b\d{1,3}(?:\.\d{1,3}){3}\b", "", text)
    text = re.sub(r"\b\d{5,}\b", "", text)
    text = "".join(ch for ch in text if ch.isalnum() or ch in " .,_+-()")
    text = " ".join(text.split())[:limit]
    return text or "Unknown"


def device_label_from(item) -> DeviceLabel:
    return DeviceLabel(
        public_device_text(getattr(item, "app_name", "")),
        public_device_text(getattr(item, "device_model", "")),
        public_device_text(getattr(item, "country", "")),
        timestamp(getattr(item, "date_created", 0)),
        timestamp(getattr(item, "date_active", 0)),
        bool(getattr(item, "current", False)),
    )


def timestamp(value) -> int:
    if isinstance(value, datetime):
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return int(value.timestamp())
    return int(value or 0)


def convert_reset(result) -> ResetResult:
    name = type(result).__name__
    if name == "ResetPasswordOk":
        return ResetResult("ok")
    if name == "ResetPasswordRequestedWait":
        return ResetResult("wait", timestamp(result.until_date))
    if name == "ResetPasswordFailedWait":
        return ResetResult("cooldown", timestamp(result.retry_date))
    raise SafeError("Telegram returned an unknown reset result. State was preserved; update the libraries before retrying.")



def email_unconfirmed(error: Exception) -> bool:
    return type(error).__name__ in ("EmailUnconfirmedError", "EmailUnconfirmed")


async def apply_without_email(submit, cancel) -> None:
    """Set 2FA without sending or confirming a recovery email.

    A pending unconfirmed recovery-email code can make Telegram reject the
    password update. That code is cancelled, then the same password-only
    update is retried once. No address and no emailed code are requested.
    """
    try:
        await submit()
        return
    except Exception as error:
        if not email_unconfirmed(error):
            raise
    try:
        await cancel()
    except Exception as cancel_error:
        log.warning("Pending recovery-email code was not cancelled (%s); retrying password set without email",
                    type(cancel_error).__name__)
    try:
        await submit()
    except Exception as error:
        if email_unconfirmed(error):
            raise SafeError(
                "Telegram still has an unconfirmed recovery-email step blocking this password. "
                "The password was NOT applied. No email address or code was requested. The saved password remains."
            ) from None
        raise


def phone_digits(value: str) -> str:
    return re.sub(r"\D", "", value or "")


def identity_from_user(user) -> tuple[int, str]:
    """Phone and ID reported by a live logged-in session, never by a filename."""
    uid = int(getattr(user, "id", 0) or 0)
    phone = phone_digits(getattr(user, "phone", "") or getattr(user, "phone_number", ""))
    if not uid or not 7 <= len(phone) <= 15:
        raise SafeError("This session did not provide its account phone number. Use a valid session of your own account.")
    return uid, "+" + phone


def account_identity(data: dict) -> str:
    digits = phone_digits(str(data.get("owner_phone") or data.get("detected_phone") or ""))
    uid = int(data.get("account_user_id") or data.get("detected_user_id") or 0)
    label = " ".join(str(data.get("label") or "Account").split())[:60] or "Account"
    return f"Account: {label}\nPhone: {'+' + digits if digits else 'not saved'}\nTelegram ID: {uid or 'unknown'}"




def public_error(error: Exception) -> str:
    """Only return controlled strings; exceptions can contain credentials/URLs."""
    if isinstance(error, SafeError):
        return str(error)
    name = type(error).__name__.lower()
    if "flood" in name or "slowmode" in name:
        return "Telegram rate-limited this request. The bot will respect Telegram's retry time."
    if any(w in name for w in ("authkey", "sessionrevoked", "sessionexpired", "unauthorized")):
        return "This session is expired or revoked. Use a valid session of your own account. No login code will be requested here."
    if "apiid" in name or "apihash" in name:
        return "Telegram rejected the API ID/hash. Correct the local configuration using --setup."
    if "sessiontoofresh" in name or "freshauth" in name or "freshresetauthoris" in name:
        return ("Telegram will not let a session younger than 24 hours terminate other logins. "
                "This bot session was not logged out. The lock stays ON and retries when Telegram allows it.")
    if "passwordmissing" in name:
        return "Telegram reports that no 2FA password is set. Use /status, then /setpassword if needed."
    if "resetrequestmissing" in name:
        return "Telegram reports no active password-reset request. Use /status to check the account."
    if any(w in name for w in ("youblockeduser", "userisblocked", "blockeduser")):
        return "This account has blocked that chat, usually @SpamBot. Open it in Telegram, tap Unblock, then try again. The session was not logged out."
    if isinstance(error, (TimeoutError, ConnectionError, OSError)) or any(
        word in name for word in ("timeout", "network", "connection", "servererror")
    ):
        return "The account connection dropped. The session was not logged out. Try the command again."
    if "sqlite" in type(error).__module__ or isinstance(error, sqlite3.DatabaseError):
        return "The session database is busy, damaged, or in an unsupported format. Close other programs using it and check the file."
    return "The operation could not be completed. Saved state was preserved. Check the console error class and /status."


def retry_seconds(error: Exception) -> int:
    for attr in ("seconds", "value", "retry_after"):
        value = getattr(error, attr, None)
        try:
            if value is not None and 0 < int(value) < 366 * 86400:
                return max(60, int(value))
        except (ValueError, TypeError):
            pass
    name = type(error).__name__.lower()
    if isinstance(error, (TimeoutError, ConnectionError, OSError)) or any(
        word in name for word in ("timeout", "connection", "network")
    ):
        return 120
    return 3600


class TelethonAdapter:
    library = "telethon"

    async def connect(self, path: Path, api_id: int, api_hash: str):
        from telethon import TelegramClient
        fp = device_fingerprint(path)
        self._rpc_lock = asyncio.Lock()
        self.client = TelegramClient(
            str(path.with_suffix("")), api_id, api_hash,
            receive_updates=False, flood_sleep_threshold=0,
            request_retries=1, connection_retries=2, timeout=15,
            device_model=fp["device_model"],
            system_version=fp["system_version"],
            app_version=fp["app_version"],
            lang_code="en",
            system_lang_code="en-US",
        )
        await self.client.connect()
        if not await self.client.is_user_authorized():
            raise SafeError("This Telethon session is not logged in. Provide a valid existing session of your own account.")
        return await self.client.get_me()

    async def info(self) -> PasswordInfo:
        from telethon import functions
        result = await call_once(self, self.client, functions.account.GetPasswordRequest())
        return PasswordInfo(
            bool(result.has_password), bool(result.has_recovery), result.hint or "",
            timestamp(getattr(result, "pending_reset_date", 0)),
            str(getattr(result, "login_email_pattern", "") or ""),
            True,
            bool(getattr(result, "email_unconfirmed_pattern", None)),
        )

    async def request_login_email_code(self, email: str) -> LoginEmailCode:
        from telethon import functions, types
        result = await self.client(functions.account.SendVerifyEmailCodeRequest(
            purpose=types.EmailVerifyPurposeLoginChange(), email=email))
        if type(result).__name__ != "SentEmailCode":
            raise SafeError("Telegram did not return the expected login-email code response.")
        return LoginEmailCode(str(getattr(result, "email_pattern", "") or ""), int(result.length))

    async def confirm_login_email_code(self, code: str, email: str) -> LoginEmailReceipt:
        from telethon import functions, types
        result = await self.client(functions.account.VerifyEmailRequest(
            purpose=types.EmailVerifyPurposeLoginChange(),
            verification=types.EmailVerificationCode(code=code)))
        if type(result).__name__ != "EmailVerified":
            raise SafeError("Telegram did not return the expected login-email confirmation.")
        return LoginEmailReceipt(True, "")

    async def reset(self) -> ResetResult:
        from telethon import functions
        return convert_reset(await self.client(functions.account.ResetPasswordRequest()))

    async def decline(self):
        from telethon import functions
        return await self.client(functions.account.DeclinePasswordResetRequest())

    async def set_password(self, password: str, hint: str):
        """Enable 2FA with the saved password only. The email flag is omitted."""
        from telethon import functions, password as pwd_mod, types

        hint = "" if hint is None else str(hint)
        if len(hint) > 80:
            raise SafeError("The saved hint is too long. The password was not sent.")

        async def submit():
            current = await self.client(functions.account.GetPasswordRequest())
            if getattr(current, "has_password", False):
                raise SafeError("2FA is already ON. The saved password was not written over an existing password.")
            algo = current.new_algo
            algo.salt1 += os.urandom(32)
            await self.client(functions.account.UpdatePasswordSettingsRequest(
                password=types.InputCheckPasswordEmpty(),
                new_settings=types.account.PasswordInputSettings(
                    new_algo=algo,
                    new_password_hash=pwd_mod.compute_digest(algo, password),
                    hint=hint,
                    email=None,
                ),
            ))

        async def cancel():
            await self.client(functions.account.CancelPasswordEmailRequest())

        await apply_without_email(submit, cancel)
        confirmed = await self.client(functions.account.GetPasswordRequest())
        if not getattr(confirmed, "has_password", False):
            raise SafeError("Telegram did not confirm the new 2FA password. It was not reported as set, and no email was requested.")
        return True

    async def spamcheck(self) -> str:
        sent = await call_once(self, self.client.send_message, "SpamBot", "/start")
        for _ in range(12):
            await asyncio.sleep(2)
            messages = await call_once(self, self.client.get_messages, "SpamBot", limit=10)
            replies = [m for m in messages if m.id > sent.id and not m.out and m.message]
            if replies:
                return "\n\n".join(m.message for m in reversed(replies))[:3300]
        raise SafeError("The official @SpamBot did not reply within 24 seconds. Try /spamcheck again later.")

    async def authorizations(self) -> list[LoginSession]:
        from telethon import functions
        result = await call_once(self, self.client, functions.account.GetAuthorizationsRequest())
        return [LoginSession(int(a.hash), timestamp(a.date_created), bool(a.current)) for a in result.authorizations]

    async def device_labels(self) -> list[DeviceLabel]:
        from telethon import functions
        result = await call_once(self, self.client, functions.account.GetAuthorizationsRequest())
        return [device_label_from(item) for item in result.authorizations]

    async def terminate_session(self, authorization_hash: int):
        from telethon import functions
        safe_hash = int(hash_key(authorization_hash))  # Refuse zero/current hash.
        return await self.client(functions.account.ResetAuthorizationRequest(hash=safe_hash))

    async def service_messages(self, offset_id=0, limit=50) -> list[ServiceEvent]:
        # The only monitored peer is Telegram's official service user.
        try:
            messages = await call_once(self, self.client.get_messages, SERVICE_USER_ID, limit=limit, offset_id=offset_id)
        except ValueError:
            from telethon.tl.types import InputPeerUser
            messages = await call_once(self, self.client.get_messages, InputPeerUser(SERVICE_USER_ID, 0), limit=limit, offset_id=offset_id)
        return [ServiceEvent(int(m.id), timestamp(m.date), classify_service_text(getattr(m, "message", None)),
                             bool(getattr(m, "out", False))) for m in messages
                if int(getattr(m, "chat_id", SERVICE_USER_ID) or 0) == SERVICE_USER_ID]

    async def forward_service_messages(self, target: str, message_ids: list[int]) -> int:
        """Forward official-service messages to the owner's target with this account."""
        ids = [int(i) for i in message_ids]
        if not ids:
            return 0
        try:
            result = await call_once(self, self.client.forward_messages, target, ids, from_peer=SERVICE_USER_ID)
        except ValueError:
            # First contact may precede any cache entry, matching service_messages.
            from telethon.tl.types import InputPeerUser
            result = await call_once(
                self, self.client.forward_messages, target, ids, from_peer=InputPeerUser(SERVICE_USER_ID, 0))
        return len(result) if isinstance(result, (list, tuple)) else (1 if result else 0)

    async def close(self):
        if hasattr(self, "client"):
            await self.client.disconnect()


class PyrogramAdapter:
    library = "pyrogram"

    async def connect(self, path: Path, api_id: int, api_hash: str):
        # Import inside a running loop: older Pyrogram expects an event loop.
        from pyrogram import Client
        fp = device_fingerprint(path)
        self._rpc_lock = asyncio.Lock()
        self.client = Client(
            path.stem, api_id=api_id, api_hash=api_hash,
            workdir=str(path.parent), no_updates=True, sleep_threshold=0,
            device_model=fp["device_model"],
            system_version=fp["system_version"],
            app_version=fp["app_version"],
            lang_code="en",
        )
        authorized = await self.client.connect()  # NEVER .start(): no interactive login
        if not authorized:
            raise SafeError("This Pyrogram session is not logged in. Provide a valid existing session of your own account.")
        return await self.client.get_me()

    async def info(self) -> PasswordInfo:
        from pyrogram import raw
        result = await call_once(self, self.client.invoke, raw.functions.account.GetPassword())
        return PasswordInfo(
            bool(result.has_password), bool(result.has_recovery), result.hint or "",
            timestamp(getattr(result, "pending_reset_date", 0)),
            str(getattr(result, "login_email_pattern", "") or ""),
            True,
            bool(getattr(result, "email_unconfirmed_pattern", None)),
        )

    async def request_login_email_code(self, email: str) -> LoginEmailCode:
        from pyrogram import raw
        result = await self.client.invoke(raw.functions.account.SendVerifyEmailCode(
            purpose=raw.types.EmailVerifyPurposeLoginChange(), email=email))
        if type(result).__name__ != "SentEmailCode":
            raise SafeError("Telegram did not return the expected login-email code response.")
        return LoginEmailCode(str(getattr(result, "email_pattern", "") or ""), int(result.length))

    async def confirm_login_email_code(self, code: str, email: str) -> LoginEmailReceipt:
        from pyrogram import raw
        result = await self.client.invoke(raw.functions.account.VerifyEmail(
            purpose=raw.types.EmailVerifyPurposeLoginChange(),
            verification=raw.types.EmailVerificationCode(code=code)))
        if type(result).__name__ != "EmailVerified":
            raise SafeError("Telegram did not return the expected login-email confirmation.")
        return LoginEmailReceipt(True, "")

    async def reset(self) -> ResetResult:
        from pyrogram import raw
        return convert_reset(await self.client.invoke(raw.functions.account.ResetPassword()))

    async def decline(self):
        from pyrogram import raw
        return await self.client.invoke(raw.functions.account.DeclinePasswordReset())

    async def set_password(self, password: str, hint: str):
        """Enable 2FA with the saved password only. The email flag is omitted."""
        from pyrogram import raw
        from pyrogram.utils import btoi, compute_password_hash, itob

        hint = "" if hint is None else str(hint)
        if len(hint) > 80:
            raise SafeError("The saved hint is too long. The password was not sent.")

        async def submit():
            current = await self.client.invoke(raw.functions.account.GetPassword())
            if getattr(current, "has_password", False):
                raise SafeError("2FA is already ON. The saved password was not written over an existing password.")
            algo = current.new_algo
            algo.salt1 += os.urandom(32)
            digest = btoi(compute_password_hash(algo, password))
            await self.client.invoke(raw.functions.account.UpdatePasswordSettings(
                password=raw.types.InputCheckPasswordEmpty(),
                new_settings=raw.types.account.PasswordInputSettings(
                    new_algo=algo,
                    new_password_hash=itob(pow(algo.g, digest, btoi(algo.p))),
                    hint=hint,
                    email=None,
                ),
            ))

        async def cancel():
            await self.client.invoke(raw.functions.account.CancelPasswordEmail())

        await apply_without_email(submit, cancel)
        confirmed = await self.client.invoke(raw.functions.account.GetPassword())
        if not getattr(confirmed, "has_password", False):
            raise SafeError("Telegram did not confirm the new 2FA password. It was not reported as set, and no email was requested.")
        return True

    async def spamcheck(self) -> str:
        sent = await call_once(self, self.client.send_message, "SpamBot", "/start")
        for _ in range(12):
            await asyncio.sleep(2)
            messages = [m async for m in self.client.get_chat_history("SpamBot", limit=10)]
            replies = [m for m in messages if m.id > sent.id and not m.outgoing and (m.text or m.caption)]
            if replies:
                return "\n\n".join((m.text or m.caption) for m in reversed(replies))[:3300]
        raise SafeError("The official @SpamBot did not reply within 24 seconds. Try again later.")

    async def authorizations(self) -> list[LoginSession]:
        from pyrogram import raw
        result = await call_once(self, self.client.invoke, raw.functions.account.GetAuthorizations())
        return [LoginSession(int(a.hash), timestamp(a.date_created), bool(a.current)) for a in result.authorizations]

    async def device_labels(self) -> list[DeviceLabel]:
        from pyrogram import raw
        result = await call_once(self, self.client.invoke, raw.functions.account.GetAuthorizations())
        return [device_label_from(item) for item in result.authorizations]

    async def terminate_session(self, authorization_hash: int):
        from pyrogram import raw
        safe_hash = int(hash_key(authorization_hash))
        return await self.client.invoke(raw.functions.account.ResetAuthorization(hash=safe_hash))

    async def service_messages(self, offset_id=0, limit=50) -> list[ServiceEvent]:
        events = []
        async for m in self.client.get_chat_history(SERVICE_USER_ID, offset_id=offset_id, limit=limit):
            chat = getattr(m, "chat", None)
            if chat is not None and int(chat.id) != SERVICE_USER_ID:
                continue
            events.append(ServiceEvent(int(m.id), timestamp(m.date),
                                       classify_service_text(getattr(m, "text", None) or getattr(m, "caption", None)),
                                       bool(getattr(m, "outgoing", False))))
        return events

    async def forward_service_messages(self, target: str, message_ids: list[int]) -> int:
        """Forward official-service messages to the owner's target with this account."""
        ids = [int(i) for i in message_ids]
        if not ids:
            return 0
        result = await self.client.forward_messages(target, SERVICE_USER_ID, ids)
        return len(result) if isinstance(result, (list, tuple)) else (1 if result else 0)

    async def close(self):
        if hasattr(self, "client") and self.client.is_connected:
            await self.client.disconnect()


class SessionManager:
    def __init__(self, store: Store, shared_root: Path | None = None):
        self.store = store
        self.root = store.root
        self.shared_root = Path(shared_root).resolve() if shared_root else None
        self.connect_lock = asyncio.Lock()
        self.adapter = None
        self.me = None
        for folder in ("sessions", ".runtime", ".incoming"):
            path = self.root / folder
            path.mkdir(exist_ok=True)
            private_mode(path, directory=True)

    def candidates(self) -> list[str]:
        # Detect session databases by content, not spelling/case/extension.
        roots = [(self.root, "")]
        if self.shared_root and self.shared_root != self.root:
            roots.append((self.shared_root, "@local/"))
        names = set()
        for base, prefix in roots:
            files = list(base.glob("*")) + list((base / "sessions").glob("*"))
            for path in files:
                if not path.is_file() or path.is_symlink():
                    continue
                name = prefix + str(path.relative_to(base))
                try:
                    self.checked_path(name)
                except (SafeError, OSError, ValueError):
                    continue
                names.add(name)
        return sorted(names)

    def checked_path(self, name: str) -> Path:
        if name.startswith("@local/"):
            if not self.shared_root:
                raise SafeError("The shared local-session folder is not configured.")
            base, relative = self.shared_root, name[7:]
        else:
            base, relative = self.root, name
        path = base / relative
        if path.is_symlink():
            raise SafeError("Session symbolic links are not accepted.")
        resolved = path.resolve()
        if resolved.parent not in (base, base / "sessions"):
            raise SafeError("Select a session database from this profile or the shared local sessions folder.")
        if not resolved.is_file() or not 16 <= resolved.stat().st_size <= MAX_SESSION_BYTES:
            raise SafeError("The session file is missing, empty, or larger than the 5 MB safety limit.")
        with resolved.open("rb") as handle:
            if handle.read(16) != b"SQLite format 3\x00":
                raise SafeError("This is not a supported SQLite .session file. StringSession text is not a .session database.")
        # Open read-only; never execute SQL supplied by an uploaded file.
        try:
            db = sqlite3.connect("file:" + quote(str(resolved)) + "?mode=ro", uri=True)
            try:
                tables = {row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
                if "sessions" not in tables:
                    raise SafeError("This SQLite file is not a Telethon or Pyrogram session.")
            finally:
                db.close()
        except sqlite3.DatabaseError:
            raise SafeError("The uploaded session database cannot be read safely.") from None
        private_mode(resolved)
        return resolved

    async def select(self, name: str) -> None:
        if self.store.reload()["reset_status"] == "waiting":
            raise SafeError("This profile has an active saved job. Use another profile for another account.")
        self.checked_path(name)
        await self.close()
        self.store.update(session_name=name, library="", registered=False, owner_phone="", detected_user_id=0, detected_phone="")

    def _runtime_copy(self, source: Path, library: str) -> Path:
        # Each adapter gets an independent copy. Opening a wrong format must not
        # mutate the owner's original database or break the fallback adapter.
        digest = hashlib.sha256(source.read_bytes()).hexdigest()[:20]
        name_digest = hashlib.sha256(str(source).encode()).hexdigest()[:10]
        folder = self.root / ".runtime" / (name_digest + "-" + digest) / library
        folder.mkdir(parents=True, exist_ok=True)
        private_mode(folder.parent, directory=True)
        private_mode(folder, directory=True)
        target = folder / "account.session"
        if not target.exists():
            src = sqlite3.connect("file:" + quote(str(source)) + "?mode=ro", uri=True, timeout=5.0)
            dst = sqlite3.connect(target, timeout=5.0)
            try:
                dst.execute("PRAGMA busy_timeout = 5000")
                src.backup(dst)
            finally:
                dst.close()
                src.close()
            private_mode(target)
        return target

    async def ensure(self):
        async with self.connect_lock:
            return await self._ensure_connected()

    async def _reuse_cached(self) -> bool:
        """Keep a live client. If it dropped, connect the same client again. Never log out."""
        adapter = self.adapter
        if adapter is None:
            return False
        client = getattr(adapter, "client", None)
        if client is None or not hasattr(client, "connect"):
            return True
        if client_is_up(client):
            return True
        try:
            await asyncio.wait_for(client.connect(), 30)
            return True
        except Exception as error:
            log.warning("Session reconnect failed (%s); no logout", type(error).__name__)
            return False

    async def _drop_cached(self):
        adapter = self.adapter
        self.adapter = None
        self.me = None
        close = getattr(adapter, "close", None)
        if close is None:
            return
        try:
            await close()
        except Exception:
            pass

    async def _ensure_connected(self):
        if self.adapter:
            if await self._reuse_cached():
                return self.adapter
            await self._drop_cached()
        data = self.store.reload()
        if not int(data["api_id"] or 0) or not re.fullmatch(r"[a-fA-F0-9]{32}", str(data["api_hash"])):
            raise SafeError("API credentials are missing or invalid. Run python bot.py --setup in your own terminal.")
        name = data["session_name"]
        if not name:
            choices = self.candidates()
            if len(choices) != 1:
                raise SafeError("No single session is selected. Use /session to select or upload your own .session file.")
            name = choices[0]
            self.store.update(session_name=name)
        source = self.checked_path(name)
        preferred = data.get("library")
        order = [preferred] if preferred in ("telethon", "pyrogram") else ["telethon", "pyrogram"]
        for index, library in enumerate(order):
            adapter = TelethonAdapter() if library == "telethon" else PyrogramAdapter()
            try:
                target = self._runtime_copy(source, library)
                me = await asyncio.wait_for(adapter.connect(target, int(data["api_id"]), data["api_hash"]), 60)
                if not me or getattr(me, "bot", False) or getattr(me, "is_bot", False):
                    raise SafeError("A logged-in human user session is required, not a bot session.")
                expected = int(self.store.data.get("account_user_id") or self.store.data.get("detected_user_id") or 0)
                if expected and int(me.id) != expected:
                    raise SafeError("The session account ID does not match this profile's verified account. Use /addaccount for a different account. No reset was requested.")
                # Never derive or overwrite the bot controller ID from a session.
                self.adapter, self.me = adapter, me
                actual_phone = phone_digits(getattr(me, "phone", "") or getattr(me, "phone_number", ""))
                self.store.update(library=library, detected_user_id=int(me.id),
                                  detected_phone="+" + actual_phone if actual_phone else "")
                return adapter
            except asyncio.CancelledError:
                try:
                    await adapter.close()
                except Exception:
                    pass
                raise
            except Exception as error:
                try:
                    await adapter.close()
                except Exception:
                    pass
                format_error = isinstance(error, sqlite3.DatabaseError) or (
                    isinstance(error, (ValueError, TypeError)) and any(
                        word in str(error).lower() for word in ("session", "column", "unpack", "database")
                    )
                )
                if not (format_error and index + 1 < len(order)):
                    if format_error:
                        raise SafeError("The session format does not match the selected library. Re-select it with /session, or export a valid SQLite session.") from None
                    raise
        raise SafeError("Neither session adapter could open the file.")

    def adopt_live_identity(self) -> bool:
        """Mark the profile verified from the connected session. No logout and no reset."""
        if not self.me:
            return False
        try:
            uid, phone = identity_from_user(self.me)
        except SafeError:
            return False
        data = self.store.reload()
        pinned = int(data.get("account_user_id") or 0)
        detected = int(data.get("detected_user_id") or 0)
        if (pinned and pinned != uid) or (detected and detected != uid):
            raise SafeError("This session account ID does not match this profile. Use /addaccount for a different account. No reset was requested.")
        self.store.update(detected_user_id=uid, account_user_id=uid, detected_phone=phone, owner_phone=phone, registered=True)
        return True

    async def verify_phone(self, entered: str) -> None:
        cleaned = re.sub(r"[\s()-]", "", entered.strip())
        if not re.fullmatch(r"\+[1-9]\d{6,14}", cleaned):
            raise SafeError("Enter a full phone number with country code, such as +919876543210.")
        await self.ensure()
        actual = phone_digits(getattr(self.me, "phone", "") or getattr(self.me, "phone_number", ""))
        if not actual or actual != phone_digits(cleaned):
            raise SafeError("Phone mismatch. This session does not match the phone number you entered. No reset was requested.")
        self.store.update(owner_phone="+" + actual, detected_phone="+" + actual, registered=True,
                          account_user_id=int(self.me.id), detected_user_id=int(self.me.id))

    async def close(self):
        if self.adapter:
            try:
                await self.adapter.close()
            finally:
                self.adapter = None
                self.me = None
