"""Owner-only new-authorization alerts and conservative, per-account revocation.

Existing authorizations at arming time are trusted; the current authorization
is NEVER a target. A non-current hash created since arming stays eligible while
it is still active, and becomes eligible again if it returns after a false
absence. Seeing a hash once is not proof that the device is gone. No login,
OTP request, logout-all, account deletion, password/reset change or bypass.

Durable state contains only IDs, timestamps, counters, flags and error classes.
Device descriptions, IPs, message bodies, codes and login links are discarded.
"""
from __future__ import annotations

import asyncio
import copy
import logging
import re
import time
from dataclasses import dataclass

from security_alerts import ENABLED_KEY, retry_delay, stamp
from storage import SafeError
from ui_state import pin_owner_message

LOCK_KEY = "protection_lock_enabled"
STATE_KEY = "protection_state"
GEN_KEY = "protection_generation"
INTERVAL = 30
DISCOVERY_INTERVAL = 5
RPC_TIMEOUT = 25
MAX_METADATA = 512
MAX_TERMINATIONS_PER_TICK = 3
COUNTERS = ("new", "revoked", "accepted", "gone", "allowed", "uncertain", "failed")
log = logging.getLogger(__name__)


@dataclass(frozen=True)
class LoginSession:
    authorization_hash: int
    created_at: int
    current: bool = False


class TerminationUnconfirmed(SafeError):
    pass


def number(value):
    if isinstance(value, bool) or not isinstance(value, int) or not 0 <= value < 2**63:
        raise SafeError("Invalid protection metadata; no session was terminated.")
    return value


def hash_key(value):
    if isinstance(value, bool) or not isinstance(value, (str, int)):
        raise SafeError("Invalid authorization identifier; no session was terminated.")
    try:
        integer = int(value)
    except ValueError:
        raise SafeError("Invalid authorization identifier; no session was terminated.") from None
    if not -(2**63) <= integer < 2**63 or not integer or str(integer) != str(value):
        raise SafeError("Invalid authorization identifier; no session was terminated.")
    return str(integer)


def locked(data):
    value = data.get(LOCK_KEY, True)
    if not isinstance(value, bool):
        raise SafeError("Invalid lock switch; automatic termination is paused.")
    return value


def guard_state(data):
    raw = data.get(STATE_KEY, {})
    state = {"initialized": False, "target_user_id": 0, "generation": 0, "armed_at": 0,
             "trusted": [], "known": [], "candidates": {}, "last_check": 0, "retry_at": 0,
             "error": "", "error_notified": "", "notify_retry_at": 0, "delivery_error": "", "outbox": {},
             "other_devices": 0,
             "total_new": 0, "total_termination_attempts": 0, "total_terminations_confirmed": 0, "total_unconfirmed_gone": 0}
    if not isinstance(raw, dict) or set(raw) - set(state):
        raise SafeError("Protection state needs private backup repair. No session was terminated.")
    state.update(copy.deepcopy(raw))
    if not isinstance(state["initialized"], bool):
        raise SafeError("Invalid protection baseline flag.")
    for key in ("target_user_id", "generation", "armed_at", "last_check", "retry_at", "notify_retry_at",
                "other_devices", "total_new", "total_termination_attempts", "total_terminations_confirmed", "total_unconfirmed_gone"):
        number(state[key])
    for key in ("error", "error_notified", "delivery_error"):
        _error_class(state[key])
    for key in ("trusted", "known"):
        if not isinstance(state[key], list) or len(state[key]) > MAX_METADATA:
            raise SafeError("Invalid protection session index.")
        state[key] = list(dict.fromkeys(hash_key(h) for h in state[key]))
    candidates = state["candidates"]
    if not isinstance(candidates, dict) or len(candidates) > MAX_METADATA:
        raise SafeError("Invalid pending protection index.")
    allowed = {"created_at", "attempts", "retry_at", "accepted", "accepted_notified", "failure_reported", "last_error"}
    for key, candidate in candidates.items():
        hash_key(key)
        if not isinstance(candidate, dict) or set(candidate) != allowed:
            raise SafeError("Invalid pending protection action.")
        for field in ("created_at", "attempts", "retry_at"):
            number(candidate[field])
        for field in ("accepted", "accepted_notified", "failure_reported"):
            if not isinstance(candidate[field], bool):
                raise SafeError("Invalid protection action flag.")
        _error_class(candidate["last_error"])
    if not isinstance(state["outbox"], dict) or set(state["outbox"]) - set(COUNTERS + ("latest_at",)):
        raise SafeError("Unexpected alert content rejected; only fixed counters may be saved.")
    for value in state["outbox"].values():
        number(value)
    return state


def _error_class(value):
    if not isinstance(value, str) or value and not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,79}", value):
        raise SafeError("Only an exception class, never exception text, may be saved.")


def checked_snapshot(sessions):
    if not isinstance(sessions, list) or len(sessions) > MAX_METADATA or not sessions:
        raise SafeError("Cannot verify the current session. No session was terminated.")
    current = []
    active = {}
    for session in sessions:
        if not isinstance(session, LoginSession) or not isinstance(session.current, bool):
            raise SafeError("Invalid authorization response. No session was terminated.")
        number(session.created_at)
        if type(session.authorization_hash) is not int or not -(2**63) <= session.authorization_hash < 2**63:
            raise SafeError("Invalid authorization hash; protection paused.")
        if session.current:
            current.append(session)
            if session.authorization_hash == 0:
                continue  # Telegram normally uses hash zero for this client.
        key = hash_key(session.authorization_hash)
        if key in active:
            raise SafeError("Duplicate authorization identifiers; protection paused.")
        active[key] = session
    if len(current) != 1:
        raise SafeError("Cannot uniquely verify this client's current session; protection paused.")
    return active, current[0]


def other_count(active) -> int:
    return sum(1 for item in active.values() if not item.current)


def other_devices_text(data) -> str:
    try:
        state = guard_state(data)
    except SafeError:
        return "Other devices: not available"
    if not state["last_check"]:
        return "Other devices: not checked yet"
    return "Other devices: " + str(state["other_devices"]) + " (bot session not counted)"


def guard_status(data):
    try:
        if not locked(data):
            return "OFF"
        state = guard_state(data)
        if not state["initialized"] or not state["armed_at"] or state["generation"] != data.get(GEN_KEY, 0):
            return "ON — initializing; not enforcing yet"
        if state["error"]:
            if "freshreset" in str(state["error"]).lower():
                return "ON — waiting until this session is 24h old; current session kept"
            return "ON — delayed; needs attention"
        return "ON — new logins are terminated; this session is kept"
    except SafeError:
        return "PAUSED — state needs attention"


def protection_screen(registry, controller, *, key=None, page=0):
    from telegram import InlineKeyboardButton as Button, InlineKeyboardMarkup as Markup
    keys = [registry.get(key).key] if key else registry.keys()
    pages = max(1, (len(keys) + 4) // 5)
    page = max(0, min(int(page), pages - 1))
    lines = ["ACCOUNT PROTECTION", "Default: lock ON for new valid accounts. It stays ON until you turn it OFF, including after the reset wait.",
             "Lock ON terminates new logins, including a device that is still active after an earlier attempt. This bot session is never terminated.",
             "Your OWN new login is also a target: turn the lock OFF before signing in elsewhere, then turn it ON again.",
             "This is detection/revocation, NOT a pre-login block. A session younger than 24 hours cannot terminate others until Telegram allows it.", ""]
    rows = []
    for account_key in keys[page * 5:page * 5 + 5]:
        try:
            account = registry.get(account_key)
            data = account.store.reload()
            state = guard_state(data)
            alerts = bool(controller.reload().get(ENABLED_KEY, True) and data.get(ENABLED_KEY, True))
            phone = re.sub(r"\D", "", str(data.get("owner_phone") or data.get("detected_phone") or ""))
            lines += [account.label()] + (["Phone: +" + phone] if 7 <= len(phone) <= 15 else [])
            lines += ["Lock: " + guard_status(data), other_devices_text(data),
                      "Login alerts: " + ("ON" if alerts else "OFF — /alerts"),
                      "Last check: " + stamp(state["last_check"]), "Pending new-session actions: " + str(len(state["candidates"])), ""]
            on = locked(data)
            rows.append([Button(("Turn lock OFF: " if on else "Turn lock ON: ") + str(data.get("label") or "Account")[:30],
                                callback_data=f"acct:{account_key}:guard_{'off' if on else 'on'}")])
            if key:
                rows.append([Button("Other devices", callback_data=f"acct:{account_key}:devices")])
        except SafeError:
            lines += ["Protection state needs attention; no automatic action is guessed.", ""]
            if key:
                rows.append([Button("Turn lock OFF safely", callback_data=f"acct:{account_key}:guard_off")])
    nav = []
    if page: nav.append(Button("Previous", callback_data=f"protection:page:{page - 1}"))
    if page + 1 < pages: nav.append(Button("Next", callback_data=f"protection:page:{page + 1}"))
    if nav: rows.append(nav)
    rows += [[Button("Refresh protection", callback_data=f"acct:{key}:guard" if key else f"protection:page:{page}"),
              Button("My IDs", callback_data="myids")], [Button("Alert switches", callback_data="alerts")]]
    lines += ["Turn the lock OFF BEFORE signing in on another device. OFF stops future attempts; an attempt already in progress may finish.",
              "Turning ON again trusts the sessions active at that time. Turning alerts OFF does not turn the lock OFF."]
    return "\n".join(lines), Markup(rows)


class LoginGuard:
    def __init__(self, registry, controller, clock=time.time):
        self.registry, self.controller, self.clock = registry, controller, clock
        self.idle = True  # No authorization request on the timer. Refresh or a new official message asks once.

    def notices_enabled(self, data):
        return bool(self.controller.reload().get(ENABLED_KEY, True) and data.get(ENABLED_KEY, True))

    def _save(self, account, state):
        account.store.update(**{STATE_KEY: guard_state({STATE_KEY: state})})

    def _queue(self, account, state, kind, at=None):
        total = {"new": "total_new", "revoked": "total_terminations_confirmed", "gone": "total_unconfirmed_gone"}.get(kind)
        if total: state[total] += 1
        if self.notices_enabled(account.store.reload()):
            state["outbox"][kind] = state["outbox"].get(kind, 0) + 1
            state["outbox"]["latest_at"] = max(state["outbox"].get("latest_at", 0), int(at or self.clock()))

    def _defer(self, account, error, *, delivery=False, current_created_at=0):
        state = guard_state(account.store.reload())
        delay = retry_delay(error)
        if "freshreset" in type(error).__name__.lower():
            delay = max(60, current_created_at + 86400 - int(self.clock()) + 5) if current_created_at else 3600
        state["notify_retry_at" if delivery else "retry_at"] = int(self.clock()) + delay
        state["delivery_error" if delivery else "error"] = type(error).__name__[:80]
        self._save(account, state)
        log.warning("Protection %s deferred (%s); no identifiers or exception values logged",
                    "delivery" if delivery else "check", type(error).__name__)

    async def _adapter(self, account):
        target = int(account.store.reload().get("account_user_id") or account.store.data.get("detected_user_id") or 0)
        adapter = await account.sessions.ensure()
        if not target or not account.sessions.me or int(account.sessions.me.id) != target:
            raise SafeError("Protection session ID does not match its saved account.")
        return adapter, target

    async def _read(self, adapter):
        sessions = await asyncio.wait_for(adapter.authorizations(), RPC_TIMEOUT)
        return checked_snapshot(sessions)

    async def refresh_devices(self, account) -> int:
        """One read-only device count. No termination and no logout."""
        async with account.engine.lock:
            adapter, _target = await self._adapter(account)
            active, _current = await self._read(adapter)
            state = guard_state(account.store.reload())
            count = other_count(active)
            state["other_devices"] = count
            state["last_check"] = int(self.clock())
            self._save(account, state)
            return count

    async def device_report(self, account) -> str:
        """Owner-only live device list. Hashes, IPs and codes are not included or saved."""
        async with account.engine.lock:
            adapter, _target = await self._adapter(account)
            labels = await asyncio.wait_for(adapter.device_labels(), RPC_TIMEOUT)
            others = [item for item in labels if not item.current]
            armed = 0
            fresh = False
            retry_at = 0
            try:
                state = guard_state(account.store.reload())
                armed = state["armed_at"]
                fresh = "freshreset" in str(state["error"]).lower() and state["retry_at"] > int(self.clock())
                retry_at = state["retry_at"]
                state["other_devices"] = len(others)
                state["last_check"] = int(self.clock())
                self._save(account, state)
            except SafeError:
                pass
        lines = [account.label(), "Other devices: " + str(len(others)), "This bot session is not counted.", ""]
        if not others:
            lines.append("No other device is logged in right now.")
        for index, item in enumerate(others[:12], 1):
            lines.append(str(index) + ". " + item.app + " — " + item.device)
            if item.country and item.country != "Unknown":
                lines.append("   " + item.country)
            lines.append("   Login: " + stamp(item.created_at))
            if item.active_at:
                lines.append("   Last active: " + stamp(item.active_at))
            if armed and item.created_at >= armed:
                lines.append("   New login after lock ON")
                if fresh:
                    lines.append("   Telegram blocks removal until this bot session is 24 hours old. Next try: " + stamp(retry_at))
            elif armed:
                lines.append("   Already logged in when the lock was turned on")
        if len(others) > 12:
            lines.append("Showing 12 of " + str(len(others)) + ".")
        lines += ["", "Lock ON ends a new device session. It cannot stop the login code from being sent.",
                  "Turn the lock OFF before your own new login, then turn it ON again."]
        return "\n".join(lines)

    def _baseline(self, old, active, target, generation, armed_at):
        state = guard_state({})
        state.update(initialized=True, target_user_id=target, generation=generation, armed_at=armed_at,
                     trusted=list(active), known=list(active), last_check=int(self.clock()),
                     other_devices=other_count(active),
                     outbox=old["outbox"], notify_retry_at=old["notify_retry_at"], delivery_error=old["delivery_error"])
        for counter in ("total_new", "total_termination_attempts", "total_terminations_confirmed", "total_unconfirmed_gone"):
            state[counter] = old[counter]
        return state

    def force_lock_on(self, key) -> bool:
        """Turn an OFF lock back on without trusting devices that arrived while it was off."""
        account = self.registry.get(key)
        data = account.store.reload()
        if locked(data):
            return False
        state = guard_state(data)
        generation = number(data.get(GEN_KEY, 0))
        if state["initialized"] and state["armed_at"] and state["target_user_id"]:
            state["generation"] = generation
            account.store.update(**{LOCK_KEY: True, STATE_KEY: state})
            return True
        return False

    async def set_lock(self, key, enabled):
        account = self.registry.get(key)
        if not enabled:
            # No network/engine-lock wait: stop future sends even during a slow poll.
            data = account.store.reload()
            generation = data.get(GEN_KEY, 0)
            generation = generation if isinstance(generation, int) and not isinstance(generation, bool) and generation >= 0 else 0
            account.store.update(**{LOCK_KEY: False, GEN_KEY: generation + 1})
            return
        async with account.engine.lock:
            data = account.store.reload()
            old = guard_state(data)
            generation = number(data.get(GEN_KEY, 0))
            if locked(data) and old["initialized"] and old["armed_at"] and old["generation"] == generation:
                return  # Never re-trust an intruder via repeated ON taps.
            if old["retry_at"] > int(self.clock()):
                raise SafeError("Protection retry delay is active until " + stamp(old["retry_at"]) + ". No delay was bypassed.")
            started = int(self.clock())
            adapter, target = await self._adapter(account)
            active, _ = await self._read(adapter)  # Arming only; never terminate here.
            if account.store.reload().get(GEN_KEY, 0) != generation:
                raise SafeError("Lock setting changed while enabling. It was not turned back ON.")
            state = self._baseline(old, active, target, generation + 1, started)
            account.store.update(**{LOCK_KEY: True, GEN_KEY: generation + 1, STATE_KEY: state})

    def _can_enforce(self, account, state):
        if account.key not in self.registry.keys():
            return False
        data = account.store.reload()
        target = int(data.get("account_user_id") or data.get("detected_user_id") or 0)
        return bool(locked(data) and state["initialized"] and state["armed_at"] and state["target_user_id"] == target
                    and state["generation"] == number(data.get(GEN_KEY, 0))
                    and account.sessions.me and int(account.sessions.me.id) == target)

    def _sync_gone(self, account, state, active):
        for key in list(state["candidates"]):
            candidate = state["candidates"][key]
            if key in state["trusted"] or key in active and active[key].current:
                del state["candidates"][key]
            elif key not in active:
                self._queue(account, state, "revoked" if candidate["accepted"] else "gone")
                del state["candidates"][key]

    async def poll_account(self, account):
        async with account.engine.lock:
            data = account.store.reload()
            target = int(data.get("account_user_id") or data.get("detected_user_id") or 0)
            if not target or not data.get("session_name"):
                return
            state = guard_state(data)
            generation = number(data.get(GEN_KEY, 0))
            now = int(self.clock())
            fresh_wait = state["retry_at"] > now and "freshreset" in str(state["error"]).lower()
            if state["retry_at"] > now and not fresh_wait:
                return
            try:
                adapter, target = await self._adapter(account)
                active, current = await self._read(adapter)
                if state["initialized"] and state["target_user_id"] != target:
                    raise SafeError("Protection baseline belongs to another account. No session was terminated.")
                if not state["initialized"]:
                    state = self._baseline(state, active, target, generation, now if locked(data) else 0)
                    self._save(account, state)
                    return  # All pre-existing sessions stay trusted.
                if not self._can_enforce(account, state):
                    # OFF means allow sessions, but login notices still operate.
                    if locked(account.store.reload()):
                        raise SafeError("Protection baseline/generation needs review; no action was guessed.")
                    state.update(armed_at=0, generation=number(account.store.data.get(GEN_KEY, 0)), candidates={}, trusted=list(active))
                else:
                    self._sync_gone(account, state, active)
                state["other_devices"] = other_count(active)
                for key, session in active.items():
                    if session.current:
                        continue
                    first = key not in state["known"]
                    if first:
                        state["known"].append(key)
                        self._queue(account, state, "new", session.created_at)
                    enforcing = self._can_enforce(account, state)
                    eligible = bool(enforcing and key not in state["trusted"] and session.created_at
                                    and session.created_at >= state["armed_at"])
                    if first and not eligible:
                        self._queue(account, state, "allowed" if not enforcing else "uncertain", session.created_at)
                    if not eligible:
                        continue
                    # A hash already seen is not finished while that device is still logged in.
                    if key not in state["candidates"]:
                        if not first:
                            self._queue(account, state, "new", session.created_at)
                        state["candidates"][key] = {"created_at": session.created_at, "attempts": 0, "retry_at": 0,
                                                    "accepted": False, "accepted_notified": False,
                                                    "failure_reported": False, "last_error": ""}
                    else:
                        state["candidates"][key]["created_at"] = session.created_at
                keep = set(active) | set(state["trusted"]) | set(state["candidates"])
                important = [k for k in state["known"] if k in keep]
                if len(important) > MAX_METADATA:
                    raise SafeError("Protection metadata capacity reached; no action was guessed.")
                recent = [k for k in state["known"] if k not in keep]
                room = MAX_METADATA - len(important)
                state["known"] = (recent[-room:] if room else []) + important
                if fresh_wait:
                    # Keep watching devices and downtime logins, but do not call terminate
                    # again until Telegram's 24-hour limit has passed.
                    state["last_check"] = int(self.clock())
                    if not self.notices_enabled(account.store.reload()): state["outbox"] = {}
                    self._save(account, state)
                    return
                state.update(last_check=int(self.clock()), retry_at=0, error="", error_notified="")
                if not self.notices_enabled(account.store.reload()): state["outbox"] = {}
                self._save(account, state)  # Record discovery/outbox BEFORE any mutation RPC.
                attempts = 0
                for key in list(state["candidates"]):
                    if key not in state["candidates"]: continue
                    candidate = state["candidates"][key]
                    if candidate["retry_at"] > int(self.clock()) or attempts >= MAX_TERMINATIONS_PER_TICK:
                        continue
                    if not self._can_enforce(account, state): break
                    fresh, _ = await self._read(adapter)
                    session = fresh.get(key)
                    if not session:
                        self._sync_gone(account, state, fresh)
                        self._save(account, state)
                        continue
                    if session.current or key in state["trusted"] or not session.created_at or session.created_at < state["armed_at"]:
                        del state["candidates"][key]
                        self._queue(account, state, "uncertain")
                        self._save(account, state)
                        continue
                    candidate["created_at"] = session.created_at
                    candidate["attempts"] += 1
                    candidate["retry_at"] = int(self.clock()) + 15
                    self._save(account, state)  # A crash/timeout cannot erase the pending action.
                    if not self._can_enforce(account, state): break  # Last gate, AFTER the awaited read.
                    attempts += 1
                    state["total_termination_attempts"] += 1
                    self._save(account, state)
                    try:
                        result = await asyncio.wait_for(adapter.terminate_session(int(key)), RPC_TIMEOUT)
                        if result is not True:
                            raise TerminationUnconfirmed("Telegram did not confirm session revocation.")
                        candidate.update(accepted=True, last_error="")
                        self._save(account, state)
                    except asyncio.CancelledError:
                        raise
                    except Exception as error:
                        candidate["last_error"] = type(error).__name__[:80]
                        if not candidate["failure_reported"]:
                            self._queue(account, state, "failed")
                            candidate["failure_reported"] = True
                        self._save(account, state)
                        self._defer(account, error, current_created_at=current.created_at)
                        return  # Respect flood/fresh-session limits across the whole account.
                if attempts and self._can_enforce(account, state):
                    fresh, _ = await self._read(adapter)
                    self._sync_gone(account, state, fresh)
                    state["other_devices"] = other_count(fresh)
                for candidate in state["candidates"].values():
                    if candidate["accepted"] and not candidate["accepted_notified"]:
                        self._queue(account, state, "accepted")
                        candidate["accepted_notified"] = True
                self._save(account, state)
            except asyncio.CancelledError:
                raise
            except Exception as error:
                self._defer(account, error)

    async def _poll_key(self, key):
        try:
            await self.poll_account(self.registry.get(key))
        except asyncio.CancelledError:
            raise
        except Exception as error:
            log.warning("Protection account isolated (%s); no values logged", type(error).__name__)

    async def poll_all(self):
        await asyncio.gather(*(self._poll_key(key) for key in self.registry.keys()))

    def has_pending(self):
        for key in self.registry.keys():
            try:
                data = self.registry.get(key).store.reload()
                state = guard_state(data)
                if self.notices_enabled(data) and (any(state["outbox"].get(k, 0) for k in COUNTERS) or state["error"] != state["error_notified"]):
                    return True
            except Exception:
                continue
        return False

    async def flush_account(self, account, app):
        from telegram import InlineKeyboardButton as Button, InlineKeyboardMarkup as Markup
        async with account.engine.lock:
            data = account.store.reload()
            state = guard_state(data)
            if not self.notices_enabled(data):
                if state["outbox"]:
                    state["outbox"] = {}
                    self._save(account, state)
                return
            if state["notify_retry_at"] > int(self.clock()): return
            pending = state["outbox"]
            attention = bool(state["error"] and state["error"] != state["error_notified"])
            if not any(pending.get(k, 0) for k in COUNTERS) and not attention: return
            lines = ["ACCOUNT PROTECTION UPDATE", account.label()]
            phone = re.sub(r"\D", "", str(data.get("owner_phone") or data.get("detected_phone") or ""))
            if 7 <= len(phone) <= 15: lines.append("Phone: +" + phone)
            labels = {"new": "New login/session detected", "revoked": "New session termination confirmed",
                      "accepted": "Termination accepted; inactivity not yet confirmed",
                      "gone": "New session no longer active; termination not confirmed",
                      "allowed": "Allowed because lock was OFF", "uncertain": "Older/unverified session; NOT auto-terminated",
                      "failed": "Termination not confirmed; needs attention"}
            lines += [labels[k] + (": " + str(pending[k]) if pending[k] > 1 else "") for k in COUNTERS if pending.get(k)]
            lines += ["Lock: " + guard_status(data), other_devices_text(data),
                      "Time: " + stamp(pending.get("latest_at") or state["last_check"])]
            if attention:
                if "freshreset" in str(state["error"]).lower():
                    lines.append("Telegram will not let a session younger than 24 hours terminate other logins. This bot session was not logged out. The lock stays ON.")
                else:
                    lines.append("Check/action delayed (" + state["error"] + "). Enforcement is not guaranteed while delayed.")
                lines.append("Retry no earlier than: " + stamp(state["retry_at"]))
            lines.append("No code, message text, IP, device description or login link is included.")
            keyboard = Markup([[Button("This account's protection", callback_data=f"acct:{account.key}:guard"),
                                Button("Other devices", callback_data=f"acct:{account.key}:devices")],
                               [Button("My IDs", callback_data="myids")]])
            try:
                sent = await app.bot.send_message(int(self.controller.reload()["owner_id"]), "\n".join(lines),
                                           reply_markup=keyboard, disable_web_page_preview=True)
                state.update(outbox={}, error_notified=state["error"], notify_retry_at=0, delivery_error="")
                self._save(account, state)
                if pending.get("revoked"):
                    await pin_owner_message(app.bot, int(self.controller.reload()["owner_id"]), sent)
            except asyncio.CancelledError:
                raise
            except Exception as error:
                self._defer(account, error, delivery=True)

    async def flush_all(self, app):
        for key in self.registry.keys():
            try: await self.flush_account(self.registry.get(key), app)
            except asyncio.CancelledError: raise
            except Exception as error:
                log.warning("Protection delivery isolated (%s); no values logged", type(error).__name__)

    async def _account_worker(self, key, app):
        while key in self.registry.keys():
            task = asyncio.current_task()
            if task is not None and getattr(task, "cancelling", lambda: 0)():
                raise asyncio.CancelledError
            started = asyncio.get_running_loop().time()
            try:
                account = self.registry.get(key)
                if not self.idle:
                    await self.poll_account(account)
                if task is not None and getattr(task, "cancelling", lambda: 0)():
                    raise asyncio.CancelledError
                await self.flush_account(account, app)
                if task is not None and getattr(task, "cancelling", lambda: 0)():
                    raise asyncio.CancelledError
            except asyncio.CancelledError: raise
            except Exception as error:
                if task is not None and getattr(task, "cancelling", lambda: 0)():
                    raise asyncio.CancelledError
                log.warning("Protection worker isolated (%s); no values logged", type(error).__name__)
            await asyncio.sleep(max(1, INTERVAL - (asyncio.get_running_loop().time() - started)))

    async def worker(self, app):
        tasks = {}
        try:
            while True:
                try:
                    keys = set(self.registry.keys())
                    removed = [tasks.pop(key) for key in set(tasks) - keys]
                    for task in removed: task.cancel()
                    if removed: await asyncio.gather(*removed, return_exceptions=True)
                    for key in keys:
                        if key not in tasks or tasks[key].done():
                            if key in tasks and not tasks[key].cancelled(): tasks[key].exception()
                            tasks[key] = asyncio.create_task(self._account_worker(key, app), name="login-protection-account")
                except asyncio.CancelledError: raise
                except Exception as error:
                    log.warning("Protection supervisor isolated (%s)", type(error).__name__)
                await asyncio.sleep(DISCOVERY_INTERVAL)
        finally:
            for task in tasks.values(): task.cancel()
            await asyncio.gather(*tasks.values(), return_exceptions=True)
