"""Official Telegram service-chat forwarding using each account's own session.

While an account's protection lock is ON, every newly seen incoming message
from the official service user (777000) is queued by message ID and forwarded
by that account's logged-in session to the saved @target. The bot controller
never forwards: it only tracks metadata and notifies the owner about limits,
queue overflow or failures.

Durable state contains only message IDs, timestamps, counters, flags and
controlled error classes. Message text, codes, links and media never enter
this module's state or its logs. Flood errors respect Telegram's own wait,
pause the queue and notify the owner once per error class. No session is
logged out and no Telegram limit is bypassed.
"""
from __future__ import annotations

import asyncio
import copy
import logging
import re
import time

from login_guard import locked
from security_alerts import retry_delay, stamp
from storage import SafeError

STATE_KEY = "otp_forward_state"
ENABLED_KEY = "otp_forward_enabled"
TARGET_KEY = "forward_target"
INTERVAL = 3  # Near-instant detection: a new service message is seen within ~3s.
DISCOVERY_INTERVAL = 5
RPC_TIMEOUT = 25
FAST_PAGE = 10  # Steady-state check reads only the newest few messages.
PAGE_SIZE = 50
PAGES_PER_TICK = 4
BATCH = 20  # One forward call carries up to 20 IDs — no trickle, no gaps.
MAX_PENDING = 100
MAX_SCAN_IDS = 500
TARGET_RE = re.compile(r"@[A-Za-z][A-Za-z0-9_]{4,31}\Z")
ERROR_CLASS = re.compile(r"[A-Za-z_][A-Za-z0-9_]{0,79}\Z")
log = logging.getLogger(__name__)
_repeat_log = {}


def number(value) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or not 0 <= value < 2**63:
        raise SafeError("OTP-forward metadata is invalid. No message was forwarded.")
    return value


def message_id(value) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or not 0 < value < 2**63:
        raise SafeError("OTP-forward message ID is invalid. No message was forwarded.")
    return value


def forward_state(data: dict) -> dict:
    raw = data.get(STATE_KEY, {})
    allowed = {"initialized", "cursor", "scan", "pending", "last_check", "retry_at",
               "fwd_retry_at", "flood_strikes",
               "error", "error_notified", "notify_retry_at", "delivery_error",
               "forwarded", "dropped", "dropped_notified"}
    if not isinstance(raw, dict) or set(raw) - allowed:
        raise SafeError("OTP-forward state is invalid. Restore its private backup.")
    state = {"initialized": False, "cursor": 0, "scan": {}, "pending": [], "last_check": 0,
             "retry_at": 0, "fwd_retry_at": 0, "flood_strikes": 0,
             "error": "", "error_notified": "", "notify_retry_at": 0,
             "delivery_error": "", "forwarded": 0, "dropped": 0, "dropped_notified": 0}
    state.update(copy.deepcopy(raw))
    if not isinstance(state["initialized"], bool):
        raise SafeError("Invalid OTP-forward baseline flag.")
    for key in ("cursor", "last_check", "retry_at", "fwd_retry_at", "flood_strikes",
                "notify_retry_at", "forwarded", "dropped", "dropped_notified"):
        state[key] = number(state[key])
    for key in ("error", "error_notified", "delivery_error"):
        value = state[key]
        if not isinstance(value, str) or (value and not ERROR_CLASS.match(value)):
            raise SafeError("Invalid OTP-forward error metadata.")
    scan = state["scan"]
    if not isinstance(scan, dict) or set(scan) - {"offset", "high", "ids"}:
        raise SafeError("OTP-forward scan metadata is invalid.")
    for key in ("offset", "high"):
        if key in scan:
            scan[key] = number(scan[key])
    ids = scan.get("ids", [])
    if not isinstance(ids, list) or len(ids) > MAX_SCAN_IDS:
        raise SafeError("OTP-forward scan queue is invalid.")
    scan["ids"] = [message_id(v) for v in ids]
    pending = state["pending"]
    if not isinstance(pending, list) or len(pending) > MAX_PENDING:
        raise SafeError("OTP-forward pending queue is invalid.")
    state["pending"] = [message_id(v) for v in pending]
    return state


def _check_cancelled() -> None:
    task = asyncio.current_task()
    if task is not None and getattr(task, "cancelling", lambda: 0)():
        raise asyncio.CancelledError


def forward_target(controller_data: dict) -> str:
    value = str(controller_data.get(TARGET_KEY) or "")
    if value in ("@me", "me"):
        return "me"
    if not TARGET_RE.match(value):
        raise SafeError("The forward target must be a valid @username such as @tgidsel.")
    return value


class OtpForwarder:
    def __init__(self, registry, controller, clock=time.time):
        self.registry, self.controller, self.clock = registry, controller, clock
        self.on_login = None

    def enabled(self, data=None) -> bool:
        return bool(self.controller.reload().get(ENABLED_KEY, True) and
                    (data is None or data.get(ENABLED_KEY, True)))

    def _save(self, account, state):
        account.store.update(**{STATE_KEY: forward_state({STATE_KEY: state})})

    @staticmethod
    def _calm_flood(error) -> bool:
        """A flood or fatal session class Telegram gives no timer for (e.g. PeerFloodError)."""
        has_wait = any(getattr(error, key, None) is not None
                       for key in ("seconds", "value", "retry_after"))
        name = type(error).__name__.lower()
        return not has_wait and any(k in name for k in ("flood", "authkeyduplicated", "sessionrevoked", "userdeactivated"))

    def _defer(self, account, error, *, delivery=False, forward=False):
        state = forward_state(account.store.reload())
        now = int(self.clock())
        if delivery:
            state["notify_retry_at"] = now + retry_delay(error)
            state["delivery_error"] = type(error).__name__[:80]
        else:
            delay = retry_delay(error)
            if self._calm_flood(error):
                # Leave a flood-limited ID alone: each repeat waits twice as
                # long (15m → 30m → 1h → … → 6h) instead of hammering Telegram.
                strikes = min(number(state.get("flood_strikes", 0)) + 1, 24)
                state["flood_strikes"] = strikes
                delay = min(900 * (2 ** (strikes - 1)), 21600)
            state["fwd_retry_at" if forward else "retry_at"] = now + delay
            state["error"] = type(error).__name__[:80]
            state["last_check"] = now
        self._save(account, state)
        signature = (getattr(account, "key", ""), state.get("error", ""), bool(delivery))
        now = time.time()
        if now - _repeat_log.get(signature, 0) >= 900:
            log.warning("OTP-forward %s deferred (%s); no text or values logged",
                        "delivery" if delivery else "check", type(error).__name__)
            _repeat_log[signature] = now

    async def poll_account(self, account):
        async with account.engine.lock:
            data = account.store.reload()
            target = int(data.get("account_user_id") or data.get("detected_user_id") or 0)
            if not self.enabled(data) or not target or not data.get("session_name"):
                return
            state = forward_state(data)
            now = int(self.clock())
            if state["retry_at"] > now:
                return
            try:
                lock_on = locked(data)
                adapter = await account.sessions.ensure()
                if not account.sessions.me or int(account.sessions.me.id) != target:
                    raise SafeError("OTP-forward session ID does not match this account.")
                if not state["initialized"]:
                    page = await asyncio.wait_for(adapter.service_messages(limit=1), RPC_TIMEOUT)
                    state.update(initialized=True,
                                 cursor=max((e.message_id for e in page), default=0),
                                 scan={}, pending=[], last_check=now, retry_at=0,
                                 error="", error_notified="")
                    self._save(account, state)
                    return  # Baseline only; never replay pre-enable history.
                scan = state["scan"]
                for page_index in range(PAGES_PER_TICK):
                    offset = scan.get("offset", 0)
                    limit = FAST_PAGE if page_index == 0 and not offset else PAGE_SIZE
                    page = await asyncio.wait_for(
                        adapter.service_messages(offset_id=offset, limit=limit), RPC_TIMEOUT)
                    unique = {e.message_id: e for e in page
                              if e.message_id > 0 and (not offset or e.message_id < offset)}
                    if page and not unique:
                        raise SafeError("OTP-forward history did not advance. No cursor was guessed.")
                    events = list(unique.values())
                    if not scan.get("high"):
                        scan["high"] = max((e.message_id for e in events), default=state["cursor"])
                    collected = scan.setdefault("ids", [])
                    for e in events:
                        if state["cursor"] < e.message_id <= scan["high"] and not e.outgoing:
                            if e.message_id not in collected and len(collected) < MAX_SCAN_IDS:
                                collected.append(e.message_id)
                    done = (not page or len(page) < limit
                            or any(e.message_id <= state["cursor"] for e in events))
                    if done:
                        new_ids = sorted(set(collected))
                        if lock_on and new_ids:
                            merged = list(state["pending"])
                            for mid in new_ids:
                                if mid not in merged:
                                    merged.append(mid)
                            if len(merged) > MAX_PENDING:
                                state["dropped"] += len(merged) - MAX_PENDING
                                merged = merged[-MAX_PENDING:]
                            state["pending"] = merged
                        # A healthy read may clear a reported error, but the notified
                        # class stays: a still-failing flush must not re-notify every cycle.
                        if state["error"] and state["error"] == state["error_notified"]:
                            state["error"] = ""
                        state.update(cursor=max(state["cursor"], scan.get("high", 0)),
                                     scan={}, last_check=now, retry_at=0)
                        self._save(account, state)  # Cursor AND queue durable before delivery.
                        return bool(lock_on and new_ids)
                    scan["offset"] = min(e.message_id for e in events)
                    if state["error"] and state["error"] == state["error_notified"]:
                        state["error"] = ""
                    state.update(scan=scan, last_check=now, retry_at=0)
                    self._save(account, state)  # Restart resumes a long backlog page-by-page.
            except asyncio.CancelledError:
                raise
            except Exception as error:
                self._defer(account, error)

    async def _poll_key(self, key):
        try:
            await self.poll_account(self.registry.get(key))
        except asyncio.CancelledError:
            raise
        except Exception as error:
            log.warning("OTP-forward account isolated (%s); no values logged", type(error).__name__)

    async def poll_all(self):
        if self.enabled():
            await asyncio.gather(*(self._poll_key(key) for key in self.registry.keys()))

    def has_pending(self) -> bool:
        if not self.enabled():
            return False
        for key in self.registry.keys():
            try:
                data = self.registry.get(key).store.reload()
                state = forward_state(data)
                if self.enabled(data) and (state["pending"] or
                                           (state["error"] and state["error"] != state["error_notified"]) or
                                           state["dropped"] != state["dropped_notified"]):
                    return True
            except Exception:
                continue
        return False

    @staticmethod
    def _heal(state):
        """Confirmed progress closes the incident without masking the next one.

        An already-reported error clears completely; an unreported one is kept
        so the owner still hears about it after the send.
        """
        if state["error"] and state["error"] == state["error_notified"]:
            state["error"] = state["error_notified"] = ""
        elif not state["error"]:
            state["error_notified"] = ""
        state["flood_strikes"] = 0  # Real progress: the ID is no longer limited.

    def _sent(self, account, state, ids, now):
        """Confirmed forward: remove exactly these IDs, in order, with no gaps."""
        sent = set(ids)
        state["pending"] = [i for i in state["pending"] if i not in sent]
        state["forwarded"] += len(ids)
        self._heal(state)
        state.update(last_check=now, retry_at=0, fwd_retry_at=0)
        self._save(account, state)  # Queue shrinks only after a confirmed send.

    def _drop(self, account, state, ids, now):
        """Telegram no longer has these messages; count them and keep moving."""
        gone = set(ids)
        state["pending"] = [i for i in state["pending"] if i not in gone]
        state["dropped"] += len(ids)
        self._heal(state)
        state.update(last_check=now, retry_at=0, fwd_retry_at=0)
        self._save(account, state)

    @staticmethod
    def _missing(name: str) -> bool:
        return any(token in name for token in
                   ("MessageIdInvalid", "MsgIdInvalid", "MessageIdsEmpty"))

    async def _drain(self, account, adapter, username, state, now):
        """Forward every pending ID immediately, oldest first, without gaps.

        Normal path: one forward call carries the whole queue. Only a
        deleted-message error splits the work so one dead ID cannot block
        or drop its healthy neighbours. Any other error pauses the queue.
        """
        while state["pending"] and state["fwd_retry_at"] <= now:
            batch = state["pending"][:BATCH]
            try:
                await asyncio.wait_for(
                    adapter.forward_service_messages(username, batch), RPC_TIMEOUT)
            except asyncio.CancelledError:
                raise
            except Exception as error:
                if batch and self._missing(type(error).__name__):
                    if len(batch) == 1:
                        self._drop(account, state, batch, now)
                        continue
                    for mid in list(batch):  # Retry one by one; keep the healthy IDs.
                        try:
                            await asyncio.wait_for(
                                adapter.forward_service_messages(username, [mid]), RPC_TIMEOUT)
                        except asyncio.CancelledError:
                            raise
                        except Exception as inner:
                            if self._missing(type(inner).__name__):
                                self._drop(account, state, [mid], now)
                                continue
                            self._defer(account, inner, forward=True)
                            return
                        self._sent(account, state, [mid], now)
                    continue
                self._defer(account, error, forward=True)
                return
            self._sent(account, state, batch, now)

    async def flush_account(self, account, app):
        from telegram import InlineKeyboardButton as Button, InlineKeyboardMarkup as Markup
        async with account.engine.lock:
            data = account.store.reload()
            if not self.enabled(data):
                return
            state = forward_state(data)
            now = int(self.clock())
            if state["pending"] and state["fwd_retry_at"] <= now:
                try:
                    if locked(data):
                        target = int(data.get("account_user_id") or data.get("detected_user_id") or 0)
                        adapter = await account.sessions.ensure()
                        if not account.sessions.me or int(account.sessions.me.id) != target:
                            raise SafeError("OTP-forward session ID does not match this account.")
                        username = forward_target(self.controller.reload())
                        await self._drain(account, adapter, username, state, now)
                        state = forward_state(account.store.reload())
                except asyncio.CancelledError:
                    raise
                except Exception as error:
                    self._defer(account, error, forward=True)
                    state = forward_state(account.store.reload())
            if state["notify_retry_at"] > int(self.clock()):
                return
            attention = bool((state["error"] and state["error"] != state["error_notified"]) or
                             state["dropped"] != state["dropped_notified"])
            if not attention:
                return
            lines = ["OTP FORWARDING UPDATE", account.label()]
            phone = re.sub(r"\D", "", str(data.get("owner_phone") or data.get("detected_phone") or ""))
            if 7 <= len(phone) <= 15:
                lines.append("Phone: +" + phone)
            if state["error"] and state["error"] != state["error_notified"]:
                if "flood" in state["error"].lower() or "wait" in state["error"].lower():
                    lines.append("Paused by a Telegram limit (" + state["error"] + ").")
                else:
                    lines.append("Forwarding paused (" + state["error"] + ").")
                later = max(state["retry_at"], state["fwd_retry_at"])
                if later > int(self.clock()):
                    lines.append("Retry no earlier than: " + stamp(later))
            if state["dropped"] != state["dropped_notified"]:
                lines.append("Messages dropped after the queue limit: " + str(state["dropped"]))
            lines.append("Official messages waiting: " + str(len(state["pending"])))
            lines.append("Forwarded total: " + str(state["forwarded"]))
            lines.append("No message text, codes or links are stored or shown.")
            keyboard = Markup([[Button("Open this account", callback_data="account:" + account.key),
                                Button("My IDs", callback_data="myids")]])
            try:
                await app.bot.send_message(int(self.controller.reload()["owner_id"]), "\n".join(lines),
                                           reply_markup=keyboard, disable_web_page_preview=True)
                state.update(error_notified=state["error"], dropped_notified=state["dropped"],
                             notify_retry_at=0, delivery_error="")
                self._save(account, state)
            except asyncio.CancelledError:
                raise
            except Exception as error:
                self._defer(account, error, delivery=True)

    async def flush_all(self, app):
        for key in self.registry.keys():
            try:
                await self.flush_account(self.registry.get(key), app)
            except asyncio.CancelledError:
                raise
            except Exception as error:
                log.warning("OTP-forward delivery isolated (%s)", type(error).__name__)

    async def _account_worker(self, key, app):
        while key in self.registry.keys():
            _check_cancelled()
            started = asyncio.get_running_loop().time()
            try:
                account = self.registry.get(key)
                seen = await self.poll_account(account)
                _check_cancelled()
                await self.flush_account(account, app)
                _check_cancelled()
                if seen and self.on_login:
                    await self.on_login(account)
                _check_cancelled()
            except asyncio.CancelledError:
                raise
            except Exception as error:
                _check_cancelled()
                log.warning("OTP-forward account worker deferred (%s); no values logged",
                            type(error).__name__)
            # A slow/revoked account cannot delay another account's loop.
            elapsed = asyncio.get_running_loop().time() - started
            await asyncio.sleep(max(1, INTERVAL - elapsed))

    async def worker(self, app):
        tasks = {}
        try:
            while True:
                _check_cancelled()
                try:
                    keys = set(self.registry.keys())
                    removed = [tasks.pop(key) for key in set(tasks) - keys]
                    for task in removed:
                        task.cancel()
                    if removed:
                        await asyncio.gather(*removed, return_exceptions=True)
                    for key in keys:
                        if key not in tasks or tasks[key].done():
                            if key in tasks and not tasks[key].cancelled():
                                tasks[key].exception()  # Retrieve an isolated failure, never its text.
                            tasks[key] = asyncio.create_task(self._account_worker(key, app),
                                                             name="otp-forward-account")
                except asyncio.CancelledError:
                    raise
                except Exception as error:
                    _check_cancelled()
                    log.warning("OTP-forward supervisor deferred (%s); no values logged",
                                type(error).__name__)
                await asyncio.sleep(DISCOVERY_INTERVAL)  # Discover new imports without changing recovery scheduling.
        finally:
            for task in tasks.values():
                task.cancel()
            await asyncio.gather(*tasks.values(), return_exceptions=True)
